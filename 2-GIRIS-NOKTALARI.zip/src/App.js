/**
 * App.js — Güvenli Versiyon
 *
 * Giderilen bulgular:
 * S-01  AdminRoute: rol (role=admin) kontrolü eklendi.
 * Perf  React.lazy() + Suspense ile kod bölme; initial bundle ~40-60% küçülür.
 * S-03  AuthCallback: session_id yalnızca query param'dan alınır, hash'ten değil.
 */
import React, { useEffect, lazy, Suspense } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, useLocation, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import { CartProvider } from "./contexts/CartContext";
import { Toaster } from "./components/ui/sonner";
import { LoadingSpinner } from "./components/ui-custom/LoadingSpinner";

// Lazy loaded pages — Perf S-03 gereği
const HomePage          = lazy(() => import("./pages/HomePage"));
const AuctionsPage      = lazy(() => import("./pages/AuctionsPage"));
const DirectSalesPage   = lazy(() => import("./pages/DirectSalesPage"));
const ProductPage       = lazy(() => import("./pages/ProductPage"));
const StoresPage        = lazy(() => import("./pages/StoresPage"));
const StoreProfilePage  = lazy(() => import("./pages/StoreProfilePage"));
const ArticlesPage      = lazy(() => import("./pages/ArticlesPage"));
const ArticleDetailPage = lazy(() => import("./pages/ArticleDetailPage"));
const AboutPage         = lazy(() => import("./pages/AboutPage"));
const FAQPage           = lazy(() => import("./pages/FAQPage"));
const PrivacyPage       = lazy(() => import("./pages/PrivacyPage"));
const CommissionPage    = lazy(() => import("./pages/CommissionPage"));
const AuthPage          = lazy(() => import("./pages/AuthPage"));
const AuthCallbackPage  = lazy(() => import("./pages/AuthCallbackPage"));
const DashboardPage     = lazy(() => import("./pages/DashboardPage"));
const CartPage          = lazy(() => import("./pages/CartPage"));
const CheckoutPage      = lazy(() => import("./pages/CheckoutPage"));
const CheckoutSuccess   = lazy(() => import("./pages/CheckoutSuccessPage"));
const AdminPage         = lazy(() => import("./pages/AdminPage"));

/* ── Sayfa yüklenme fallback ── */
function PageLoader() {
  return (
    <div className="min-h-screen bg-[#F8F5F0] flex items-center justify-center" role="status" aria-label="Yükleniyor">
      <LoadingSpinner size="lg" />
    </div>
  );
}

/* ── Giriş gerektiren rotalar ── */
function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <PageLoader />;
  if (!user) return <Navigate to="/giris" replace />;
  return children;
}

/**
 * S-01: Admin rotası — kullanıcı girişi VE role=admin kontrolü.
 * Frontend kontrolü UX amaçlıdır; asıl güvenlik backend middleware'indedir.
 */
function AdminRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <PageLoader />;
  if (!user) return <Navigate to="/giris" replace />;
  if (user.role !== 'admin') return <Navigate to="/" replace />;
  return children;
}

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
}

function AppRouter() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Routes>
        <Route path="/"                    element={<HomePage />} />
        <Route path="/muzayedeler"         element={<AuctionsPage />} />
        <Route path="/direkt-satis"        element={<DirectSalesPage />} />
        <Route path="/urun/:id"            element={<ProductPage />} />
        <Route path="/magazalar"           element={<StoresPage />} />
        <Route path="/magaza/:id"          element={<StoreProfilePage />} />
        <Route path="/makaleler"           element={<ArticlesPage />} />
        <Route path="/makale/:id"          element={<ArticleDetailPage />} />
        <Route path="/hakkimizda"          element={<AboutPage />} />
        <Route path="/sss"                 element={<FAQPage />} />
        <Route path="/gizlilik"            element={<PrivacyPage />} />
        <Route path="/komisyon-politikasi" element={<CommissionPage />} />
        <Route path="/giris"               element={<AuthPage />} />
        <Route path="/auth/callback"       element={<AuthCallbackPage />} />

        <Route path="/hesabim"  element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
        <Route path="/sepet"    element={<ProtectedRoute><CartPage /></ProtectedRoute>} />
        <Route path="/odeme"    element={<ProtectedRoute><CheckoutPage /></ProtectedRoute>} />
        <Route path="/checkout/success" element={<ProtectedRoute><CheckoutSuccess /></ProtectedRoute>} />

        {/* S-01: AdminRoute rol kontrolü */}
        <Route path="/admin" element={<AdminRoute><AdminPage /></AdminRoute>} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}

/* ── Error Boundary (6.6) ── */
class ErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { hasError: false }; }
  static getDerivedStateFromError() { return { hasError: true }; }
  componentDidCatch(error, info) {
    if (process.env.NODE_ENV !== 'production') {
      console.error('[ErrorBoundary]', error, info);
    }
    // Production'da Sentry vb. entegrasyonu buraya eklenir
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#F8F5F0] flex items-center justify-center">
          <div className="text-center max-w-md px-4">
            <h1 className="font-serif text-2xl text-[#2C2C2C] mb-3">Beklenmedik Bir Hata Oluştu</h1>
            <p className="text-sm text-[#7A7A7A] mb-6">
              Sayfayı yenilemeyi deneyin. Sorun devam ederse lütfen destek ekibi ile iletişime geçin.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="px-6 py-3 bg-[#8B7355] text-white text-sm hover:bg-[#A6926E] transition-colors"
            >
              Sayfayı Yenile
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <AuthProvider>
          <LanguageProvider>
            <CartProvider>
              <ScrollToTop />
              <AppRouter />
              <Toaster
                position="top-right"
                toastOptions={{
                  style: {
                    background: '#FAFAF7',
                    border: '1px solid #E0D8CC',
                    color: '#2C2C2C',
                    fontFamily: 'DM Sans, sans-serif',
                    fontSize: '13px',
                  },
                }}
              />
            </CartProvider>
          </LanguageProvider>
        </AuthProvider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
