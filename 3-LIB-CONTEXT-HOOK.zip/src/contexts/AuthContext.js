/**
 * AuthContext — Güvenli Versiyon
 *
 * Giderilen bulgular:
 * S-02  Token localStorage'da – tokenService soyutlaması ile tek merkezden yönetilir.
 * S-03  OAuth session_id URL hash'inden alınıyordu → yalnızca query param'dan alınır.
 * S-04  api() her çağrıda yeni instance döndürüyordu → merkezi apiClient kullanılıyor.
 * S-07  Zayıf parola politikası → güçlü doğrulama eklendi.
 */
import React, { createContext, useContext, useState, useEffect } from 'react';
import { apiClient, tokenService } from '../lib/apiClient';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser]       = useState(null);
  const [loading, setLoading] = useState(true);

  // 401 sinyalini dinle (apiClient interceptor'dan gelir)
  useEffect(() => {
    const handleUnauthorized = () => {
      tokenService.clearToken();
      setUser(null);
    };
    window.addEventListener('auth:unauthorized', handleUnauthorized);
    return () => window.removeEventListener('auth:unauthorized', handleUnauthorized);
  }, []);

  // Oturum kontrolü
  useEffect(() => {
    const checkAuth = async () => {
      if (!tokenService.getToken()) { setLoading(false); return; }
      try {
        const res = await apiClient.get('/api/auth/me');
        setUser(res.data);
      } catch (err) {
        if (process.env.NODE_ENV !== 'production') {
          console.warn('[Auth] Session check failed:', err.message);
        }
        tokenService.clearToken();
        setUser(null);
      } finally {
        setLoading(false);
      }
    };
    checkAuth();
  }, []);

  const login = async (email, password) => {
    const { data } = await apiClient.post('/api/auth/login', { email, password });
    tokenService.setToken(data.token);
    setUser(data.user);
    return data.user;
  };

  // S-07: güçlü parola kontrolü
  const register = async (name, email, password, phone) => {
    validatePassword(password);
    const { data } = await apiClient.post('/api/auth/register', { name, email, password, phone });
    tokenService.setToken(data.token);
    setUser(data.user);
    return data.user;
  };

  // S-03: OAuth callback güvenli hale getirildi
  // session_id yalnızca URL query parametresinden kabul edilir, hash'ten asla
  const handleOAuthCallback = async (sessionId) => {
    if (!sessionId || !isValidSessionId(sessionId)) {
      throw new Error('Geçersiz veya eksik oturum kimliği.');
    }
    const { data } = await apiClient.get(
      `/api/auth/session?session_id=${encodeURIComponent(sessionId)}`
    );
    tokenService.setToken(data.token);
    setUser(data.user);
    return data.user;
  };

  const logout = async () => {
    try { await apiClient.post('/api/auth/logout'); } catch (err) {
      // Logout API hatası kritik değil; token ve state temizleniyor
      if (process.env.NODE_ENV !== 'production') {
        console.warn('[Auth] Logout API error (non-critical):', err.message);
      }
    }
    tokenService.clearToken();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user,
      loading,
      login,
      register,
      logout,
      handleOAuthCallback,
      api: () => apiClient, // geriye dönük uyumluluk
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth, AuthProvider içinde kullanılmalıdır.');
  return ctx;
}

// S-07: Güçlü parola politikası
export function validatePassword(password) {
  const rules = [
    { test: (p) => p.length >= 8,           msg: 'En az 8 karakter olmalıdır.' },
    { test: (p) => /[A-Z]/.test(p),         msg: 'En az bir büyük harf içermelidir.' },
    { test: (p) => /[0-9]/.test(p),         msg: 'En az bir rakam içermelidir.' },
    { test: (p) => /[^A-Za-z0-9]/.test(p), msg: 'En az bir özel karakter içermelidir.' },
  ];
  const failed = rules.filter((r) => !r.test(password));
  if (failed.length) {
    throw new Error(failed.map((r) => r.msg).join(' '));
  }
}

// S-03: session_id format doğrulaması
function isValidSessionId(sessionId) {
  return /^[a-zA-Z0-9\-_]{8,256}$/.test(sessionId);
}

export default AuthContext;
