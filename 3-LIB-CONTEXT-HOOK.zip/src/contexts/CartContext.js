/**
 * CartContext — Güvenli Versiyon
 *
 * 3.4  Race condition: logout sonrası refreshCart çağrısı cancelled flag ile engellendi.
 * 3.1  getTotal() iş mantığı ayrı bir pure fonksiyon olarak korundu.
 * 5.2  Sessiz catch → hata loglama eklendi.
 * S-04  apiClient direkt kullanılıyor, her render'da yeni instance yok.
 */
import React, { createContext, useContext, useState, useCallback, useEffect, useRef } from 'react';
import { apiClient } from '../lib/apiClient';
import { useAuth } from './AuthContext';

const CartContext = createContext(null);

export const useCart = () => {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart, CartProvider içinde kullanılmalıdır.');
  return ctx;
};

export const CartProvider = ({ children }) => {
  const [items, setItems]           = useState([]);
  const [cartCount, setCartCount]   = useState(0);
  const { user }                    = useAuth();
  const cancelledRef                = useRef(false);

  const refreshCart = useCallback(async () => {
    if (!user) {
      setItems([]);
      setCartCount(0);
      return;
    }
    try {
      const res = await apiClient.get('/api/cart');
      if (cancelledRef.current) return; // race condition koruması
      const cartItems = res.data.items || [];
      setItems(cartItems);
      setCartCount(cartItems.length);
    } catch (err) {
      if (cancelledRef.current) return;
      if (process.env.NODE_ENV !== 'production') console.error('[CartContext] refreshCart error:', err);
      setItems([]);
      setCartCount(0);
    }
  }, [user]);

  useEffect(() => {
    cancelledRef.current = false;
    refreshCart();
    return () => { cancelledRef.current = true; }; // unmount / user change koruması
  }, [refreshCart]);

  const addToCart = async (productId) => {
    try {
      await apiClient.post('/api/cart', { product_id: productId, quantity: 1 });
      await refreshCart();
    } catch (err) {
      if (process.env.NODE_ENV !== 'production') console.error('[CartContext] addToCart error:', err);
      // toast import yerine CustomEvent ile bildirim — bağımlılıktan bağımsız
      window.dispatchEvent(new CustomEvent('cart:error', { detail: { message: err.message || 'Ürün sepete eklenemedi.' } }));
      throw err; // Çağıran bileşenin de yakalayabilmesi için rethrow
    }
  };

  const removeFromCart = async (productId) => {
    try {
      await apiClient.delete(`/api/cart/${productId}`);
      await refreshCart();
    } catch (err) {
      if (process.env.NODE_ENV !== 'production') console.error('[CartContext] removeFromCart error:', err);
      window.dispatchEvent(new CustomEvent('cart:error', { detail: { message: err.message || 'Ürün sepetten kaldırılamadı.' } }));
      throw err;
    }
  };

  // 3.1: Pure fonksiyon — context dışında da test edilebilir
  const getTotal = () => calculateCartTotal(items);

  return (
    <CartContext.Provider value={{ items, cartCount, refreshCart, addToCart, removeFromCart, getTotal }}>
      {children}
    </CartContext.Provider>
  );
};

// 3.1: SRP — iş mantığı bileşenden ayrıldı
export function calculateCartTotal(items) {
  return items.reduce((sum, item) => sum + (item.product?.price || 0) * (item.quantity || 1), 0);
}
