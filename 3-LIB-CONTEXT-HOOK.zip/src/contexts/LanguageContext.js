import React, { createContext, useContext, useState, useCallback } from 'react';

const translations = {
  tr: {
    nav: {
      home: "Ana Sayfa", auctions: "Müzayedeler", directSales: "Direkt Satış",
      articles: "Makaleler", stores: "Mağazalar", about: "Hakkımızda",
      faq: "SSS", privacy: "Gizlilik", commission: "Komisyon Politikası",
      cart: "Sepet", login: "Giriş Yap", register: "Kayıt Ol",
      dashboard: "Hesabım", admin: "Yönetim", logout: "Çıkış Yap",
      search: "Ara", language: "Dil"
    },
    hero: {
      title: "Nadir. Zamansız. Sizin.",
      subtitle: "Yatırım değerindeki koleksiyon parçaları ve nadir varlıkların premium pazaryeri.",
      cta: "Koleksiyonu Keşfedin",
      ctaAuction: "Canlı Müzayedeler"
    },
    sections: {
      featured: "Öne Çıkan Koleksiyon",
      liveAuctions: "Canlı Müzayedeler",
      categories: "Kategoriler",
      trust: "Neden ANTICCA",
      newsletter: "Haberdar Olun",
      newArrivals: "Yeni Gelenler",
      featuredStores: "Öne Çıkan Mağazalar",
      latestArticles: "Son Makaleler",
      directSales: "Direkt Satış"
    },
    product: {
      addToCart: "Sepete Ekle", buyNow: "Hemen Satın Al",
      placeBid: "Teklif Ver", currentBid: "Mevcut Teklif",
      startingPrice: "Başlangıç Fiyatı", price: "Fiyat",
      timeLeft: "Kalan Süre", bidHistory: "Teklif Geçmişi",
      description: "Açıklama", details: "Detaylar",
      provenance: "Köken", condition: "Durum",
      authenticity: "Orijinallik Garantisi",
      shipping: "Güvenli Kargo",
      category: "Kategori", watchlist: "İstek Listesine Ekle",
      share: "Paylaş", sold: "Satıldı",
      reserveNotMet: "Rezerv Karşılanmadı",
      highestBidder: "En yüksek teklif sizin",
      outbid: "Teklifiniz geçildi",
      minimumBid: "Minimum Teklif", yourBid: "Teklifiniz",
      bids: "teklif", noBids: "Henüz teklif yok",
      auctionEnded: "Müzayede Sona Erdi",
      auctionLive: "Canlı", endsIn: "Bitiş",
      investmentInsight: "Yatırım Perspektifi",
      conditionReport: "Durum Raporu",
      certification: "Sertifikalar",
      securePurchase: "Güvenli Alışveriş",
      storeOwner: "Bu ürün şu mağazaya aittir",
      similarProducts: "Benzer Ürünler",
      viewsCount: "görüntülenme"
    },
    auth: {
      signIn: "Giriş Yap", signUp: "Hesap Oluştur",
      email: "E-posta", password: "Şifre",
      name: "Ad Soyad", phone: "Telefon",
      forgotPassword: "Şifremi Unuttum",
      noAccount: "Hesabınız yok mu?",
      hasAccount: "Zaten hesabınız var mı?",
      google: "Google ile Devam Et", or: "veya",
      welcome: "ANTICCA'ya Hoş Geldiniz",
      joinText: "Dünyanın en seçkin koleksiyon pazaryerine katılın"
    },
    dashboard: {
      myBids: "Tekliflerim", myOrders: "Siparişlerim",
      wishlist: "İstek Listem", settings: "Ayarlar",
      noBids: "Henüz teklif vermediniz",
      noOrders: "Henüz siparişiniz yok",
      noWishlist: "İstek listeniz boş"
    },
    cart: {
      title: "Sepetim", empty: "Sepetiniz boş",
      total: "Toplam", checkout: "Ödemeye Geç",
      remove: "Kaldır", continueShopping: "Alışverişe Devam Et"
    },
    checkout: {
      title: "Ödeme", stripe: "Kredi Kartı (Stripe)",
      bankTransfer: "Banka Havalesi",
      processing: "İşleniyor...",
      success: "Ödeme Başarılı",
      successMessage: "Siparişiniz başarıyla oluşturuldu.",
      backToHome: "Ana Sayfaya Dön"
    },
    footer: {
      description: "Yatırım değerindeki koleksiyon parçaları ve nadir varlıkların premium pazaryeri.",
      quickLinks: "Hızlı Erişim",
      legal: "Yasal",
      contact: "İletişim",
      newsletter: "Bülten",
      newsletterText: "En son koleksiyon haberlerinden haberdar olun.",
      subscribe: "Abone Ol",
      allRights: "Tüm hakları saklıdır."
    },
    about: {
      title: "Hakkımızda",
      brandStory: "Marka Hikayesi",
      mission: "Misyonumuz",
      vision: "Vizyonumuz",
      values: "Değerlerimiz",
      trust: "Güven Yaklaşımımız"
    },
    faq: { title: "Sıkça Sorulan Sorular" },
    privacy: { title: "Gizlilik Politikası" },
    commissionPage: { title: "Komisyon Politikası" },
    stores: {
      title: "Mağazalar",
      verified: "Doğrulanmış",
      products: "ürün",
      viewStore: "Mağazayı Gör",
      activeListings: "Aktif İlanlar",
      auctionItems: "Müzayede Ürünleri",
      pastSales: "Geçmiş Satışlar",
      contactStore: "İletişim"
    },
    articles: {
      title: "Makaleler",
      readMore: "Devamını Oku",
      by: "Yazar",
      category: "Kategori",
      allCategories: "Tüm Kategoriler"
    },
    common: {
      loading: "Yükleniyor...",
      error: "Bir hata oluştu",
      noResults: "Sonuç bulunamadı",
      viewAll: "Tümünü Gör",
      back: "Geri",
      save: "Kaydet",
      cancel: "İptal",
      delete: "Sil",
      edit: "Düzenle",
      create: "Oluştur",
      filter: "Filtre",
      sort: "Sırala",
      all: "Tümü"
    },
    trust: {
      auth: "Uzman Doğrulama",
      authDesc: "Her ürün alanında uzman ekibimiz tarafından titizlikle incelenir.",
      secure: "Güvenli İşlem",
      secureDesc: "256-bit şifreleme ve sigortalı kargo ile tam koruma.",
      global: "Küresel Erişim",
      globalDesc: "Dünyanın dört bir yanından koleksiyoncular ve yatırımcılar.",
      provenance: "Belgelenmiş Köken",
      provenanceDesc: "Her parçanın geçmişi detaylı şekilde belgelenmiştir."
    },
    categories: {
      watches: "Saatler", art: "Sanat", jewelry: "Mücevher",
      coins: "Sikkeler", antiques: "Antikalar", cars: "Klasik Otomobiller",
      wine: "Şarap", collectibles: "Koleksiyonluk"
    }
  },
  en: {
    nav: {
      home: "Home", auctions: "Auctions", directSales: "Direct Sales",
      articles: "Articles", stores: "Stores", about: "About",
      faq: "FAQ", privacy: "Privacy", commission: "Commission Policy",
      cart: "Cart", login: "Sign In", register: "Join",
      dashboard: "My Account", admin: "Admin", logout: "Sign Out",
      search: "Search", language: "Language"
    },
    hero: {
      title: "Rare. Timeless. Yours.",
      subtitle: "The premier marketplace for investment-grade collectibles and rare assets.",
      cta: "Explore Collection",
      ctaAuction: "Live Auctions"
    },
    sections: {
      featured: "Featured Collection", liveAuctions: "Live Auctions",
      categories: "Categories", trust: "Why ANTICCA",
      newsletter: "Stay Informed", newArrivals: "New Arrivals",
      featuredStores: "Featured Stores", latestArticles: "Latest Articles",
      directSales: "Direct Sales"
    },
    product: {
      addToCart: "Add to Cart", buyNow: "Buy Now",
      placeBid: "Place Bid", currentBid: "Current Bid",
      startingPrice: "Starting Price", price: "Price",
      timeLeft: "Time Left", bidHistory: "Bid History",
      description: "Description", details: "Details",
      provenance: "Provenance", condition: "Condition",
      authenticity: "Authenticity Guaranteed",
      shipping: "Secure Shipping",
      category: "Category", watchlist: "Add to Wishlist",
      share: "Share", sold: "Sold",
      reserveNotMet: "Reserve Not Met",
      highestBidder: "You are the highest bidder",
      outbid: "You have been outbid",
      minimumBid: "Minimum Bid", yourBid: "Your Bid",
      bids: "bids", noBids: "No bids yet",
      auctionEnded: "Auction Ended",
      auctionLive: "Live", endsIn: "Ends in",
      investmentInsight: "Investment Insight",
      conditionReport: "Condition Report",
      certification: "Certifications",
      securePurchase: "Secure Purchase",
      storeOwner: "This product belongs to",
      similarProducts: "Similar Products",
      viewsCount: "views"
    },
    auth: {
      signIn: "Sign In", signUp: "Create Account",
      email: "Email", password: "Password",
      name: "Full Name", phone: "Phone",
      forgotPassword: "Forgot Password?",
      noAccount: "Don't have an account?",
      hasAccount: "Already have an account?",
      google: "Continue with Google", or: "or",
      welcome: "Welcome to ANTICCA",
      joinText: "Join the world's most exclusive collectibles marketplace"
    },
    dashboard: {
      myBids: "My Bids", myOrders: "My Orders",
      wishlist: "My Wishlist", settings: "Settings",
      noBids: "No bids yet",
      noOrders: "No orders yet",
      noWishlist: "Your wishlist is empty"
    },
    cart: {
      title: "My Cart", empty: "Your cart is empty",
      total: "Total", checkout: "Proceed to Checkout",
      remove: "Remove", continueShopping: "Continue Shopping"
    },
    checkout: {
      title: "Checkout", stripe: "Credit Card (Stripe)",
      bankTransfer: "Bank Transfer",
      processing: "Processing...",
      success: "Payment Successful",
      successMessage: "Your order has been successfully created.",
      backToHome: "Back to Home"
    },
    footer: {
      description: "The premier marketplace for investment-grade collectibles and rare assets.",
      quickLinks: "Quick Links", legal: "Legal",
      contact: "Contact", newsletter: "Newsletter",
      newsletterText: "Stay updated with the latest collection news.",
      subscribe: "Subscribe", allRights: "All rights reserved."
    },
    about: {
      title: "About Us", brandStory: "Brand Story",
      mission: "Our Mission", vision: "Our Vision",
      values: "Our Values", trust: "Our Trust Approach"
    },
    faq: { title: "Frequently Asked Questions" },
    privacy: { title: "Privacy Policy" },
    commissionPage: { title: "Commission Policy" },
    stores: {
      title: "Stores", verified: "Verified",
      products: "products", viewStore: "View Store",
      activeListings: "Active Listings", auctionItems: "Auction Items",
      pastSales: "Past Sales", contactStore: "Contact"
    },
    articles: {
      title: "Articles", readMore: "Read More",
      by: "By", category: "Category", allCategories: "All Categories"
    },
    common: {
      loading: "Loading...", error: "An error occurred",
      noResults: "No results found", viewAll: "View All",
      back: "Back", save: "Save", cancel: "Cancel",
      delete: "Delete", edit: "Edit", create: "Create",
      filter: "Filter", sort: "Sort", all: "All"
    },
    trust: {
      auth: "Expert Authentication",
      authDesc: "Every item is meticulously verified by our expert team.",
      secure: "Secure Transaction",
      secureDesc: "256-bit encryption and insured shipping for full protection.",
      global: "Global Reach",
      globalDesc: "Collectors and investors from around the world.",
      provenance: "Documented Provenance",
      provenanceDesc: "Every piece's history is thoroughly documented."
    },
    categories: {
      watches: "Watches", art: "Art", jewelry: "Jewelry",
      coins: "Coins", antiques: "Antiques", cars: "Classic Cars",
      wine: "Wine", collectibles: "Collectibles"
    }
  },
  it: {
    nav: {
      home: "Home", auctions: "Aste", directSales: "Vendita Diretta",
      articles: "Articoli", stores: "Negozi", about: "Chi Siamo",
      faq: "FAQ", privacy: "Privacy", commission: "Commissioni",
      cart: "Carrello", login: "Accedi", register: "Registrati",
      dashboard: "Il Mio Account", admin: "Admin", logout: "Esci",
      search: "Cerca", language: "Lingua"
    },
    hero: {
      title: "Raro. Senza Tempo. Tuo.",
      subtitle: "Il marketplace premium per collezionabili di valore e beni rari.",
      cta: "Esplora la Collezione",
      ctaAuction: "Aste in Corso"
    },
    sections: {
      featured: "Collezione in Evidenza", liveAuctions: "Aste in Corso",
      categories: "Categorie", trust: "Perche ANTICCA",
      newsletter: "Resta Informato", newArrivals: "Nuovi Arrivi",
      featuredStores: "Negozi in Evidenza", latestArticles: "Ultimi Articoli",
      directSales: "Vendita Diretta"
    },
    product: {
      addToCart: "Aggiungi al Carrello", buyNow: "Acquista Ora",
      placeBid: "Fai un'Offerta", currentBid: "Offerta Attuale",
      startingPrice: "Prezzo Iniziale", price: "Prezzo",
      timeLeft: "Tempo Rimasto", bidHistory: "Storico Offerte",
      description: "Descrizione", details: "Dettagli",
      provenance: "Provenienza", condition: "Condizione",
      authenticity: "Autenticita Garantita",
      shipping: "Spedizione Sicura",
      category: "Categoria", watchlist: "Aggiungi ai Preferiti",
      share: "Condividi", sold: "Venduto",
      reserveNotMet: "Riserva Non Raggiunta",
      highestBidder: "Sei il miglior offerente",
      outbid: "Sei stato superato",
      minimumBid: "Offerta Minima", yourBid: "La Tua Offerta",
      bids: "offerte", noBids: "Nessuna offerta",
      auctionEnded: "Asta Terminata",
      auctionLive: "In Corso", endsIn: "Termina tra",
      investmentInsight: "Prospettiva di Investimento",
      conditionReport: "Rapporto Condizioni",
      certification: "Certificazioni",
      securePurchase: "Acquisto Sicuro",
      storeOwner: "Questo prodotto appartiene a",
      similarProducts: "Prodotti Simili",
      viewsCount: "visualizzazioni"
    },
    auth: {
      signIn: "Accedi", signUp: "Crea Account",
      email: "Email", password: "Password",
      name: "Nome Completo", phone: "Telefono",
      forgotPassword: "Password Dimenticata?",
      noAccount: "Non hai un account?",
      hasAccount: "Hai gia un account?",
      google: "Continua con Google", or: "oppure",
      welcome: "Benvenuto su ANTICCA",
      joinText: "Unisciti al marketplace di collezionabili piu esclusivo"
    },
    dashboard: {
      myBids: "Le Mie Offerte", myOrders: "I Miei Ordini",
      wishlist: "I Miei Preferiti", settings: "Impostazioni",
      noBids: "Nessuna offerta", noOrders: "Nessun ordine",
      noWishlist: "I preferiti sono vuoti"
    },
    cart: {
      title: "Il Mio Carrello", empty: "Il carrello e vuoto",
      total: "Totale", checkout: "Procedi al Pagamento",
      remove: "Rimuovi", continueShopping: "Continua lo Shopping"
    },
    checkout: {
      title: "Pagamento", stripe: "Carta di Credito (Stripe)",
      bankTransfer: "Bonifico Bancario",
      processing: "Elaborazione...",
      success: "Pagamento Riuscito",
      successMessage: "Il tuo ordine e stato creato con successo.",
      backToHome: "Torna alla Home"
    },
    footer: {
      description: "Il marketplace premium per collezionabili di valore e beni rari.",
      quickLinks: "Link Rapidi", legal: "Legale",
      contact: "Contatto", newsletter: "Newsletter",
      newsletterText: "Resta aggiornato sulle ultime novita.",
      subscribe: "Iscriviti", allRights: "Tutti i diritti riservati."
    },
    about: {
      title: "Chi Siamo", brandStory: "La Nostra Storia",
      mission: "La Nostra Missione", vision: "La Nostra Visione",
      values: "I Nostri Valori", trust: "Il Nostro Approccio alla Fiducia"
    },
    faq: { title: "Domande Frequenti" },
    privacy: { title: "Privacy Policy" },
    commissionPage: { title: "Politica delle Commissioni" },
    stores: {
      title: "Negozi", verified: "Verificato",
      products: "prodotti", viewStore: "Vedi Negozio",
      activeListings: "Annunci Attivi", auctionItems: "Articoli all'Asta",
      pastSales: "Vendite Passate", contactStore: "Contatto"
    },
    articles: {
      title: "Articoli", readMore: "Leggi di Piu",
      by: "Di", category: "Categoria", allCategories: "Tutte le Categorie"
    },
    common: {
      loading: "Caricamento...", error: "Si e verificato un errore",
      noResults: "Nessun risultato", viewAll: "Vedi Tutti",
      back: "Indietro", save: "Salva", cancel: "Annulla",
      delete: "Elimina", edit: "Modifica", create: "Crea",
      filter: "Filtra", sort: "Ordina", all: "Tutti"
    },
    trust: {
      auth: "Autenticazione Esperta",
      authDesc: "Ogni articolo e verificato dal nostro team di esperti.",
      secure: "Transazione Sicura",
      secureDesc: "Crittografia a 256 bit e spedizione assicurata.",
      global: "Portata Globale",
      globalDesc: "Collezionisti e investitori da tutto il mondo.",
      provenance: "Provenienza Documentata",
      provenanceDesc: "La storia di ogni pezzo e documentata."
    },
    categories: {
      watches: "Orologi", art: "Arte", jewelry: "Gioielli",
      coins: "Monete", antiques: "Antiquariato", cars: "Auto Classiche",
      wine: "Vino", collectibles: "Collezionabili"
    }
  }
};

const LanguageContext = createContext();

export function LanguageProvider({ children }) {
  const [language, setLanguage] = useState('tr');

  const t = useCallback((path) => {
    const keys = path.split('.');
    let result = translations[language];
    for (const key of keys) {
      if (result && result[key] !== undefined) {
        result = result[key];
      } else {
        let fallback = translations['tr'];
        for (const k of keys) {
          if (fallback && fallback[k] !== undefined) fallback = fallback[k];
          else return path;
        }
        return fallback;
      }
    }
    return result;
  }, [language]);

  const tObj = useCallback((obj) => {
    if (!obj) return '';
    if (typeof obj === 'string') return obj;
    return obj[language] || obj['tr'] || obj['en'] || Object.values(obj)[0] || '';
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, tObj }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used within LanguageProvider');
  return context;
}

export default LanguageContext;
