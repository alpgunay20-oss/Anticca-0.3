/**
 * useAdminData — Admin veri çekme hook'u
 *
 * 3.1 SRP: AdminPage'deki veri çekme mantığı ayrı bir hook'a taşındı.
 * 5.2 Hata yönetimi: catch blokları artık anlamlı error state döndürür.
 * 4.1 Performans: 4 istek paralel başlatılır (Promise.all korundu).
 */
import { useState, useEffect } from 'react';
import { apiClient } from '../lib/apiClient';

export function useAdminData() {
  const [state, setState] = useState({
    stats: null,
    products: [],
    users: [],
    orders: [],
    loading: true,
    error: null,
  });

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      setState(s => ({ ...s, loading: true, error: null }));
      try {
        const [statsRes, productsRes, usersRes, ordersRes] = await Promise.all([
          apiClient.get('/api/admin/stats'),
          apiClient.get('/api/products?limit=100'),
          apiClient.get('/api/admin/users'),
          apiClient.get('/api/admin/orders'),
        ]);

        if (cancelled) return;

        setState({
          stats:    statsRes.data,
          products: productsRes.data.products || [],
          users:    usersRes.data.users || [],
          orders:   ordersRes.data.orders || [],
          loading:  false,
          error:    null,
        });
      } catch (err) {
        if (cancelled) return;
        setState(s => ({
          ...s,
          loading: false,
          error: err.message || 'Veriler yüklenirken bir hata oluştu.',
        }));
      }
    };

    load();
    return () => { cancelled = true; };
  }, []);

  return state;
}
