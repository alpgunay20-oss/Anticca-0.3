import React, { useState, useEffect, useCallback } from 'react';
import { apiClient } from '../lib/apiClient';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProductCard from '../components/ProductCard';
import { ProductGridSkeleton } from '../components/ui-custom/LoadingSpinner';
import { useLanguage } from '../contexts/LanguageContext';
import { Search, X, SlidersHorizontal } from 'lucide-react';


export default function DirectSalesPage() {
  const { t } = useLanguage();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [category, setCategory] = useState('');
  const [sort, setSort] = useState('newest');
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    apiClient.get('/api/categories').then(r => setCategories(r.data || [])).catch(err => { if (process.env.NODE_ENV !== 'production') console.warn('[Categories]', err.message); });
  }, []);

  const doLoad = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ is_auction: 'false', sort, limit: '60' });
      if (category) params.append('category', category);
      if (search) params.append('search', search);
      const res = await apiClient.get(`/api/products?${params}`);
      setProducts(res.data.products || []);
    } catch (e) { console.error(e); }
    setLoading(false);
  }, [category, sort, search]);

  useEffect(() => { doLoad(); }, [doLoad]);

  useEffect(() => {
    const timer = setTimeout(() => setSearch(searchInput), 400);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const clearFilters = () => { setSearchInput(''); setSearch(''); setCategory(''); setSort('newest'); };
  const hasFilters = search || category || sort !== 'newest';

  return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />

      <div className="bg-[#F2EDE4] border-b border-[#E0D8CC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
          <p className="section-eyebrow">{t('sections.directSales')}</p>
          <h1 className="font-serif text-[36px] lg:text-[48px] text-[#2C2C2C]">{t('nav.directSales')}</h1>
          <div className="divider-bronze mt-3" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-10 pb-8 border-b border-[#E0D8CC]" role="search">
          <div className="relative flex-1 min-w-[200px] max-w-xs">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7A7A7A] pointer-events-none" aria-hidden="true" />
            <label htmlFor="direct-search" className="sr-only">{t('nav.search')}</label>
            <input
              id="direct-search"
              type="search"
              value={searchInput}
              onChange={e => setSearchInput(e.target.value)}
              placeholder={`${t('nav.search')}...`}
              className="input-base pl-10 pr-4"
            />
          </div>
          <label htmlFor="direct-category" className="sr-only">Kategori</label>
          <select id="direct-category" value={category} onChange={e => setCategory(e.target.value)} className="input-base w-auto pr-8 cursor-pointer">
            <option value="">{t('common.all')}</option>
            {categories.map(c => (
              <option key={c.category_id} value={c.category_id}>
                {t(`categories.${c.category_id}`) || c.name?.tr || c.category_id}
              </option>
            ))}
          </select>
          <label htmlFor="direct-sort" className="sr-only">Sırala</label>
          <select id="direct-sort" value={sort} onChange={e => setSort(e.target.value)} className="input-base w-auto pr-8 cursor-pointer">
            <option value="newest">{t('sections.newArrivals')}</option>
            <option value="price_asc">{t('product.price')} ↑</option>
            <option value="price_desc">{t('product.price')} ↓</option>
          </select>
          {hasFilters && (
            <button onClick={clearFilters} className="flex items-center gap-1.5 btn-ghost text-[12px]" aria-label="Filtreleri Temizle">
              <X className="w-3.5 h-3.5" aria-hidden="true" />
              Temizle
            </button>
          )}
          {!loading && (
            <span className="ml-auto self-center text-[12px] text-[#7A7A7A]">
              <strong className="text-[#2C2C2C] font-semibold">{products.length}</strong> sonuç
            </span>
          )}
        </div>

        {loading ? (
          <ProductGridSkeleton count={8} />
        ) : products.length === 0 ? (
          <div className="text-center py-24">
            <SlidersHorizontal className="w-10 h-10 text-[#D4CCBF] mx-auto mb-4" aria-hidden="true" />
            <p className="text-[#7A7A7A] mb-2">{t('common.noResults')}</p>
            {hasFilters && (
              <button onClick={clearFilters} className="text-[#8B7355] text-[13px] hover:underline mt-1">
                Filtreleri temizle
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 lg:gap-6">
            {products.map(p => <ProductCard key={p.product_id} product={p} />)}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
