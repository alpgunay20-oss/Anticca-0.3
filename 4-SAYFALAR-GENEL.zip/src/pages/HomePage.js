import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { apiClient } from '../lib/apiClient';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProductCard from '../components/ProductCard';
import { ProductGridSkeleton } from '../components/ui-custom/LoadingSpinner';
import { useLanguage } from '../contexts/LanguageContext';
import { ArrowRight, Shield, Globe, Award, FileText } from 'lucide-react';


function SectionHeader({ eyebrow, title, link, linkLabel }) {
  return (
    <div className="flex items-end justify-between mb-10 lg:mb-12">
      <div>
        <p className="section-eyebrow">{eyebrow}</p>
        <h2 className="font-serif text-[30px] lg:text-[36px] text-[#2C2C2C]">{title}</h2>
        <div className="divider-bronze" />
      </div>
      {link && (
        <Link
          to={link}
          className="hidden sm:flex items-center gap-1.5 text-[12px] font-semibold uppercase tracking-[0.1em] text-[#8B7355] hover:text-[#6B5842] transition-colors group"
        >
          {linkLabel}
          <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
        </Link>
      )}
    </div>
  );
}

export default function HomePage() {
  const { t, tObj } = useLanguage();
  const [featured, setFeatured] = useState([]);
  const [auctions, setAuctions] = useState([]);
  const [stores, setStores] = useState([]);
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const [featRes, auctRes, storeRes, artRes] = await Promise.all([
          apiClient.get('/api/products?featured=true&limit=4'),
          apiClient.get('/api/auctions?limit=4'),
          apiClient.get('/api/stores'),
          apiClient.get('/api/articles?limit=3'),
        ]);
        if (cancelled) return;
        setFeatured(featRes.data.products || []);
        setAuctions(auctRes.data.auctions || []);
        setStores(storeRes.data.stores || []);
        setArticles(artRes.data.articles || []);
      } catch (e) {
        if (cancelled) return;
        if (process.env.NODE_ENV !== 'production') console.warn('[HomePage]', e.message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    load();
    return () => { cancelled = true; };
  }, []);

  const trustItems = [
    { icon: <Award className="w-6 h-6" aria-hidden="true" />, title: t('trust.auth'), desc: t('trust.authDesc') },
    { icon: <Shield className="w-6 h-6" aria-hidden="true" />, title: t('trust.secure'), desc: t('trust.secureDesc') },
    { icon: <Globe className="w-6 h-6" aria-hidden="true" />, title: t('trust.global'), desc: t('trust.globalDesc') },
    { icon: <FileText className="w-6 h-6" aria-hidden="true" />, title: t('trust.provenance'), desc: t('trust.provenanceDesc') },
  ];

  return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />

      {/* ── Hero ── */}
      <section className="relative h-[78vh] min-h-[520px] max-h-[860px] flex items-center justify-center overflow-hidden" aria-label="Ana Kapak">
        {/* Background image */}
        <div className="absolute inset-0">
          <img
            src="https://images.pexels.com/photos/3004909/pexels-photo-3004909.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=1400"
            alt=""
            role="presentation"
            className="w-full h-full object-cover scale-[1.02]"
            style={{ objectPosition: 'center 40%' }}
          />
          {/* Multi-layer gradient for depth */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#1A1A1A]/75 via-[#2C2C2C]/40 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A]/30 via-transparent to-transparent" />
        </div>

        {/* Decorative vertical rule */}
        <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-transparent via-[#8B7355]/50 to-transparent hidden lg:block" />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-2xl animate-fadeInUp">
            <p className="section-eyebrow text-[#A6926E] mb-4 opacity-90">ANTICCA — Premium Collectibles</p>
            <h1 className="font-serif text-[42px] sm:text-[54px] lg:text-[68px] text-white leading-[1.08] mb-6 tracking-tight">
              {t('hero.title')}
            </h1>
            <p className="text-[15px] lg:text-[17px] text-white/75 mb-10 leading-relaxed max-w-lg font-light">
              {t('hero.subtitle')}
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/muzayedeler" className="btn-primary">
                {t('hero.ctaAuction')}
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </Link>
              <Link
                to="/direkt-satis"
                className="inline-flex items-center gap-2 px-7 py-3 border-2 border-white/40 text-white text-[11px] font-semibold uppercase tracking-[0.1em] hover:bg-white/10 hover:border-white/60 transition-all duration-200"
              >
                {t('hero.cta')}
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-fadeIn delay-400 opacity-0" aria-hidden="true">
          <span className="text-[9px] uppercase tracking-[0.3em] text-white/50">Keşfet</span>
          <div className="w-px h-10 bg-gradient-to-b from-white/30 to-transparent" />
        </div>
      </section>

      {/* ── Featured Collection ── */}
      <section className="py-20 lg:py-24" aria-labelledby="featured-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <SectionHeader
            eyebrow="ANTICCA"
            title={t('sections.featured')}
            link="/direkt-satis"
            linkLabel={t('common.viewAll')}
          />
          {loading ? (
            <ProductGridSkeleton count={4} />
          ) : featured.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 lg:gap-6">
              {featured.map((p, i) => (
                <div key={p.product_id} className={`animate-fadeInUp delay-${(i % 4 + 1) * 100 > 400 ? '400' : (i % 4 + 1) * 100}`}>
                  <ProductCard product={p} />
                </div>
              ))}
            </div>
          ) : null}
        </div>
      </section>

      {/* ── Live Auctions ── */}
      {(loading || auctions.length > 0) && (
        <section className="py-20 lg:py-24 bg-[#F2EDE4]" aria-labelledby="auctions-heading">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionHeader
              eyebrow={t('product.auctionLive')}
              title={t('sections.liveAuctions')}
              link="/muzayedeler"
              linkLabel={t('common.viewAll')}
            />
            {loading ? (
              <ProductGridSkeleton count={4} />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 lg:gap-6">
                {auctions.map((p, i) => (
                  <div key={p.product_id} className={`animate-fadeInUp delay-${(i % 4 + 1) * 100 > 400 ? '400' : (i % 4 + 1) * 100}`}>
                    <ProductCard product={p} />
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      )}

      {/* ── Trust Section ── */}
      <section className="py-20 lg:py-24" aria-labelledby="trust-heading">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <p className="section-eyebrow">ANTICCA</p>
            <h2 id="trust-heading" className="font-serif text-[30px] lg:text-[36px] text-[#2C2C2C]">
              {t('sections.trust')}
            </h2>
            <div className="divider-bronze w-12 mx-auto mt-4" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {trustItems.map((item, i) => (
              <div
                key={i}
                className="text-center p-8 border border-[#E0D8CC] bg-white hover:border-[#8B7355]/30 hover:shadow-[0_8px_30px_rgba(44,44,44,0.06)] transition-all duration-300 animate-fadeInUp"
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                <div className="inline-flex items-center justify-center w-12 h-12 text-[#8B7355] mb-5 border border-[#E0D8CC]">
                  {item.icon}
                </div>
                <h3 className="font-serif text-[18px] text-[#2C2C2C] mb-3">{item.title}</h3>
                <p className="text-[13px] text-[#7A7A7A] leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Stores ── */}
      {(loading || stores.length > 0) && (
        <section className="py-20 lg:py-24 bg-[#F2EDE4]" aria-labelledby="stores-heading">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionHeader
              eyebrow={t('sections.featuredStores')}
              title={t('nav.stores')}
              link="/magazalar"
              linkLabel={t('common.viewAll')}
            />
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[1,2,3].map(i => (
                  <div key={i} className="bg-white border border-[#E0D8CC] p-6">
                    <div className="flex gap-4">
                      <div className="skeleton w-14 h-14 shrink-0" />
                      <div className="flex-1 space-y-2">
                        <div className="skeleton h-4 w-3/4 rounded" />
                        <div className="skeleton h-3 w-full rounded" />
                        <div className="skeleton h-3 w-1/2 rounded" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {stores.slice(0, 3).map(store => (
                  <Link
                    key={store.store_id}
                    to={`/magaza/${store.store_id}`}
                    className="group block bg-white border border-[#E0D8CC] p-6 hover:shadow-[0_8px_30px_rgba(44,44,44,0.08)] hover:border-[#8B7355]/25 transition-all duration-300"
                    aria-label={`${store.name} mağazasını görüntüle`}
                  >
                    <div className="flex items-start gap-4">
                      {store.logo ? (
                        <img
                          src={store.logo}
                          alt={store.name}
                          className="w-14 h-14 object-cover shrink-0 border border-[#E0D8CC]"
                          loading="lazy"
                        />
                      ) : (
                        <div className="w-14 h-14 bg-[#F2EDE4] flex items-center justify-center font-serif text-xl text-[#8B7355] shrink-0 border border-[#E0D8CC]">
                          {store.name?.[0]}
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-serif text-[17px] text-[#2C2C2C] group-hover:text-[#8B7355] transition-colors leading-tight">
                            {store.name}
                          </h3>
                          {store.verified && (
                            <span className="text-[8px] uppercase tracking-wider bg-[#8B7355]/10 text-[#8B7355] px-2 py-0.5 font-semibold shrink-0">
                              {t('stores.verified')}
                            </span>
                          )}
                        </div>
                        <p className="text-[13px] text-[#7A7A7A] mt-1 line-clamp-2 leading-relaxed">
                          {tObj(store.description)}
                        </p>
                        {store.product_count !== undefined && (
                          <p className="text-[11px] text-[#8B7355] mt-2 font-medium">
                            {store.product_count} {t('stores.products')}
                          </p>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </section>
      )}

      {/* ── Articles ── */}
      {(loading || articles.length > 0) && (
        <section className="py-20 lg:py-24" aria-labelledby="articles-heading">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <SectionHeader
              eyebrow={t('sections.latestArticles')}
              title={t('nav.articles')}
              link="/makaleler"
              linkLabel={t('common.viewAll')}
            />
            {loading ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {[1,2,3].map(i => (
                  <div key={i} className="space-y-3">
                    <div className="skeleton aspect-[16/10] rounded" />
                    <div className="skeleton h-2.5 w-16 rounded" />
                    <div className="skeleton h-5 w-full rounded" />
                    <div className="skeleton h-4 w-full rounded" />
                    <div className="skeleton h-4 w-2/3 rounded" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {articles.map((article, i) => (
                  <Link
                    key={article.article_id}
                    to={`/makale/${article.article_id}`}
                    className="group block animate-fadeInUp"
                    style={{ animationDelay: `${i * 0.12}s` }}
                    aria-label={tObj(article.title)}
                  >
                    {article.featured_image && (
                      <div className="aspect-[16/10] overflow-hidden mb-4 bg-[#F2EDE4]">
                        <img
                          src={article.featured_image}
                          alt={tObj(article.title)}
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.05]"
                          loading="lazy"
                          decoding="async"
                        />
                      </div>
                    )}
                    <p className="text-[9px] uppercase tracking-[0.2em] text-[#8B7355] mb-1.5 font-semibold">
                      {article.category}
                    </p>
                    <h3 className="font-serif text-[19px] text-[#2C2C2C] mb-2 group-hover:text-[#8B7355] transition-colors leading-snug line-clamp-2">
                      {tObj(article.title)}
                    </h3>
                    <p className="text-[13px] text-[#7A7A7A] line-clamp-2 leading-relaxed">
                      {tObj(article.excerpt)}
                    </p>
                    <p className="text-[11px] text-[#7A7A7A] mt-3">
                      {article.author} &middot; {new Date(article.created_at).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' })}
                    </p>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </section>
      )}

      {/* ── CTA Banner ── */}
      <section className="py-20 bg-[#2C2C2C]" aria-label="Çağrı Hareketi">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <p className="section-eyebrow text-[#A6926E] mb-4">ANTICCA</p>
          <h2 className="font-serif text-[32px] lg:text-[42px] text-white mb-6 leading-tight">
            Koleksiyonunuzu <span className="text-[#A6926E]">Bugün</span> Başlatın
          </h2>
          <p className="text-[14px] text-[#9A9088] mb-10 leading-relaxed max-w-lg mx-auto">
            Dünya genelindeki yatırımcılar ve koleksiyoncularla aynı platformda yer alın.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link to="/giris" className="btn-primary">
              Ücretsiz Kaydol
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </Link>
            <Link to="/hakkimizda" className="inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.1em] text-[#A6926E] hover:text-white transition-colors">
              Daha Fazla Öğren
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
