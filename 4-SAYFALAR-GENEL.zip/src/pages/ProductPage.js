import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { apiClient } from '../lib/apiClient';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProductCard from '../components/ProductCard';
import { LoadingSpinner } from '../components/ui-custom/LoadingSpinner';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import {
  Clock, Heart, ShoppingBag, Shield, Award, FileText,
  Eye, ChevronLeft, ChevronRight, TrendingUp, CheckCircle,
  Store, ArrowLeft, ZoomIn
} from 'lucide-react';
import { toast } from 'sonner';


function formatTimeLeft(endDate) {
  if (!endDate) return '';
  const diff = new Date(endDate) - Date.now();
  if (diff <= 0) return 'Bitti';
  const d = Math.floor(diff / 86400000);
  const h = Math.floor((diff % 86400000) / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  if (d > 0) return `${d}g ${h}s ${m}dk`;
  return `${h}s ${m}dk ${s}sn`;
}

const FALLBACK = 'https://images.pexels.com/photos/3004909/pexels-photo-3004909.jpeg?auto=compress&cs=tinysrgb&w=800';

export default function ProductPage() {
  const { id } = useParams();
  const { t, tObj } = useLanguage();
  const { user, api } = useAuth();
  const { addToCart } = useCart();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [similar, setSimilar] = useState([]);
  const [imgIdx, setImgIdx] = useState(0);
  const [bidAmount, setBidAmount] = useState('');
  const [bidding, setBidding] = useState(false);
  const [addingCart, setAddingCart] = useState(false);
  const [timeLeft, setTimeLeft] = useState('');
  const [tab, setTab] = useState('description');
  const [zoomed, setZoomed] = useState(false);
  const [wishlistLoading, setWishlistLoading] = useState(false);

  const loadProduct = useCallback(async () => {
    try {
      const [prodRes, simRes] = await Promise.all([
        apiClient.get(`/api/products/${id}`),
        apiClient.get(`/api/products/${id}/similar`).catch(() => ({ data: { products: [] } })),
      ]);
      setProduct(prodRes.data);
      setSimilar(simRes.data.products || []);
    } catch (e) { console.error(e); }
    setLoading(false);
  }, [id]);

  useEffect(() => { setLoading(true); setImgIdx(0); loadProduct(); }, [loadProduct]);

  useEffect(() => {
    if (!product?.is_auction || !product?.auction_end) return;
    setTimeLeft(formatTimeLeft(product.auction_end));
    const interval = setInterval(() => setTimeLeft(formatTimeLeft(product.auction_end)), 1000);
    return () => clearInterval(interval);
  }, [product]);

  // Keyboard navigation for image gallery
  useEffect(() => {
    const handler = (e) => {
      if (!product?.images?.length) return;
      if (e.key === 'ArrowLeft') setImgIdx(i => i > 0 ? i - 1 : product.images.length - 1);
      if (e.key === 'ArrowRight') setImgIdx(i => i < product.images.length - 1 ? i + 1 : 0);
      if (e.key === 'Escape') setZoomed(false);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [product]);

  const handleBid = async () => {
    if (!user) { toast.error('Lütfen giriş yapın'); return; }
    const amount = parseFloat(bidAmount);
    if (!amount || isNaN(amount)) { toast.error('Geçerli bir tutar girin'); return; }
    setBidding(true);
    try {
      await api().post(`/api/auctions/${id}/bid`, { amount });
      toast.success('Teklifiniz başarıyla verildi');
      setBidAmount('');
      loadProduct();
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Teklif verilemedi');
    }
    setBidding(false);
  };

  const handleAddToCart = async () => {
    if (!user) { toast.error('Lütfen giriş yapın'); return; }
    setAddingCart(true);
    try {
      await addToCart(product.product_id);
      toast.success('Sepete eklendi');
    } catch (err) { if (process.env.NODE_ENV !== 'production') console.warn('[Product addToCart]', err.message); toast.error('Sepete eklenemedi'); }
    setAddingCart(false);
  };

  const handleWishlist = async () => {
    if (!user) { toast.error('Lütfen giriş yapın'); return; }
    setWishlistLoading(true);
    try {
      const res = await api().post(`/api/wishlist/${id}`);
      toast.success(res.data.action === 'added' ? 'İstek listesine eklendi' : 'İstek listesinden çıkarıldı');
    } catch (err) { if (process.env.NODE_ENV !== 'production') console.warn('[Product bid]', err.message); toast.error('İşlem başarısız'); }
    setWishlistLoading(false);
  };

  if (loading) return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />
      <div className="flex justify-center items-center py-40">
        <LoadingSpinner size="lg" />
      </div>
    </div>
  );

  if (!product) return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />
      <div className="text-center py-40">
        <p className="text-[#7A7A7A]">{t('common.noResults')}</p>
        <Link to="/" className="mt-4 inline-block text-[#8B7355] hover:underline">{t('checkout.backToHome')}</Link>
      </div>
    </div>
  );

  const images = product.images?.length ? product.images : [FALLBACK];
  const currentBid = product.current_bid || product.starting_bid || 0;
  const minBid = currentBid + (product.min_increment || Math.max(currentBid * 0.02, 100));
  const isEnding = product.is_auction && product.auction_end && (new Date(product.auction_end) - Date.now()) < 3600000;

  const TABS = [
    { key: 'description', label: t('product.description') },
    { key: 'provenance',  label: t('product.provenance') },
    { key: 'condition',   label: t('product.conditionReport') },
    { key: 'investment',  label: t('product.investmentInsight') },
  ];

  return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />

      {/* Breadcrumb */}
      <nav className="border-b border-[#E0D8CC] bg-white" aria-label="Breadcrumb">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center gap-2 text-[12px]">
          <Link to="/" className="text-[#7A7A7A] hover:text-[#8B7355] transition-colors">Ana Sayfa</Link>
          <span className="text-[#D4CCBF]">/</span>
          <Link
            to={product.is_auction ? '/muzayedeler' : '/direkt-satis'}
            className="text-[#7A7A7A] hover:text-[#8B7355] transition-colors"
          >
            {product.is_auction ? t('nav.auctions') : t('nav.directSales')}
          </Link>
          <span className="text-[#D4CCBF]">/</span>
          <span className="text-[#2C2C2C] truncate max-w-[200px]">{tObj(product.title)}</span>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16">

          {/* ── Gallery ── */}
          <div>
            {/* Main image */}
            <div
              className="relative aspect-square bg-[#F2EDE4] border border-[#E0D8CC] overflow-hidden group cursor-zoom-in"
              onClick={() => setZoomed(true)}
              role="button"
              tabIndex={0}
              aria-label="Resmi büyüt"
              onKeyDown={e => e.key === 'Enter' && setZoomed(true)}
            >
              <img
                src={images[imgIdx]}
                alt={tObj(product.title)}
                className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-105"
              />

              {/* Zoom hint */}
              <div className="absolute bottom-3 right-3 w-8 h-8 bg-white/80 border border-[#E0D8CC] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <ZoomIn className="w-4 h-4 text-[#8B7355]" aria-hidden="true" />
              </div>

              {/* Nav arrows */}
              {images.length > 1 && (
                <>
                  <button
                    onClick={e => { e.stopPropagation(); setImgIdx(i => i > 0 ? i - 1 : images.length - 1); }}
                    className="absolute left-2 top-1/2 -translate-y-1/2 w-9 h-9 bg-white/85 border border-[#E0D8CC] flex items-center justify-center hover:bg-white transition-colors opacity-0 group-hover:opacity-100"
                    aria-label="Önceki resim"
                  >
                    <ChevronLeft className="w-4 h-4 text-[#2C2C2C]" aria-hidden="true" />
                  </button>
                  <button
                    onClick={e => { e.stopPropagation(); setImgIdx(i => i < images.length - 1 ? i + 1 : 0); }}
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-9 h-9 bg-white/85 border border-[#E0D8CC] flex items-center justify-center hover:bg-white transition-colors opacity-0 group-hover:opacity-100"
                    aria-label="Sonraki resim"
                  >
                    <ChevronRight className="w-4 h-4 text-[#2C2C2C]" aria-hidden="true" />
                  </button>
                </>
              )}

              {/* Live badge */}
              {product.is_auction && (
                <div className="absolute top-4 left-4">
                  <div className="live-badge">
                    <span className="live-dot" aria-hidden="true" />
                    <span className="text-[9px] uppercase tracking-[0.15em] text-[#8B7355] font-semibold">
                      {t('product.auctionLive')}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Thumbnails */}
            {images.length > 1 && (
              <div className="flex gap-2 mt-3 overflow-x-auto pb-1" role="list" aria-label="Resim galerileri">
                {images.map((img, i) => (
                  <button
                    key={i}
                    role="listitem"
                    onClick={() => setImgIdx(i)}
                    className={`w-[68px] h-[68px] shrink-0 border-2 overflow-hidden transition-all ${
                      i === imgIdx ? 'border-[#8B7355]' : 'border-[#E0D8CC] hover:border-[#8B7355]/50'
                    }`}
                    aria-label={`Resim ${i + 1}`}
                    aria-current={i === imgIdx}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* ── Details ── */}
          <div>
            <p className="section-eyebrow mb-2">
              {t(`categories.${product.category}`) || product.category}
            </p>
            <h1 className="font-serif text-[30px] lg:text-[38px] text-[#2C2C2C] leading-tight mb-4">
              {tObj(product.title)}
            </h1>

            {/* Store info */}
            {product.store && (
              <div className="flex items-center gap-2.5 mb-6 px-4 py-3 bg-[#F2EDE4] border border-[#E0D8CC]">
                <Store className="w-4 h-4 text-[#8B7355] shrink-0" aria-hidden="true" />
                <span className="text-[12px] text-[#4A4A4A]">{t('product.storeOwner')}:</span>
                <Link
                  to={`/magaza/${product.store.store_id}`}
                  className="text-[13px] text-[#8B7355] hover:text-[#6B5842] font-medium transition-colors"
                >
                  {product.store.name}
                </Link>
                {product.store.verified && (
                  <CheckCircle className="w-3.5 h-3.5 text-[#8B7355] shrink-0" aria-label="Doğrulanmış satıcı" />
                )}
              </div>
            )}

            {/* Auction section */}
            {product.is_auction ? (
              <div className="border border-[#E0D8CC] bg-white p-6 mb-6">
                {/* Timer */}
                <div className={`flex items-center gap-2.5 mb-5 pb-5 border-b border-[#F0EBE3] ${isEnding ? 'text-amber-600' : ''}`}>
                  <Clock className="w-5 h-5 shrink-0" aria-hidden="true" />
                  <div>
                    <p className="text-[9px] uppercase tracking-[0.15em] text-[#7A7A7A] mb-0.5">Kalan Süre</p>
                    <p className="font-mono-data text-[22px] text-[#2C2C2C] leading-none tabular-nums">
                      {timeLeft || '—'}
                    </p>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-4 mb-5">
                  <div className="bg-[#F8F5F0] p-3">
                    <p className="text-[9px] uppercase tracking-[0.15em] text-[#7A7A7A] mb-1 font-medium">
                      {t('product.currentBid')}
                    </p>
                    <p className="font-mono-data text-[24px] text-[#2C2C2C] leading-none">${currentBid.toLocaleString()}</p>
                  </div>
                  <div className="bg-[#F8F5F0] p-3">
                    <p className="text-[9px] uppercase tracking-[0.15em] text-[#7A7A7A] mb-1 font-medium">
                      {t('product.bids')}
                    </p>
                    <p className="font-mono-data text-[24px] text-[#2C2C2C] leading-none">{product.bid_count || 0}</p>
                  </div>
                </div>

                {/* Bid input */}
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[14px] text-[#7A7A7A] pointer-events-none">$</span>
                    <label htmlFor="bid-amount" className="sr-only">Teklif miktarı</label>
                    <input
                      id="bid-amount"
                      type="number"
                      value={bidAmount}
                      onChange={e => setBidAmount(e.target.value)}
                      placeholder={`Min ${minBid.toLocaleString()}`}
                      className="input-base pl-7 font-mono-data"
                      min={minBid}
                      step="any"
                    />
                  </div>
                  <button
                    onClick={handleBid}
                    disabled={bidding}
                    className="btn-primary shrink-0 px-5"
                    aria-label="Teklif ver"
                  >
                    {bidding ? (
                      <span className="flex items-center gap-2">
                        <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        ...
                      </span>
                    ) : t('product.placeBid')}
                  </button>
                </div>

                {/* Bid history */}
                {product.bids?.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-[#F0EBE3]">
                    <p className="text-[9px] uppercase tracking-[0.15em] text-[#7A7A7A] mb-3 font-medium">
                      {t('product.bidHistory')}
                    </p>
                    <div className="space-y-1.5 max-h-36 overflow-y-auto">
                      {product.bids.slice(0, 10).map((bid, i) => (
                        <div key={i} className="flex justify-between items-center text-[12px] py-1.5 border-b border-[#F8F5F0] last:border-0">
                          <span className="text-[#4A4A4A]">{bid.user_name}</span>
                          <span className="font-mono-data text-[#2C2C2C] font-medium">${bid.amount?.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="mb-6">
                <p className="text-[9px] uppercase tracking-[0.15em] text-[#7A7A7A] mb-1.5 font-medium">{t('product.price')}</p>
                <p className="font-mono-data text-[36px] text-[#2C2C2C] leading-none mb-5">
                  ${product.price?.toLocaleString('en-US')}
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={handleAddToCart}
                    disabled={addingCart}
                    className="btn-primary flex-1"
                    aria-label="Sepete ekle"
                  >
                    {addingCart ? (
                      <span className="flex items-center gap-2">
                        <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        ...
                      </span>
                    ) : (
                      <>
                        <ShoppingBag className="w-4 h-4" aria-hidden="true" />
                        {t('product.addToCart')}
                      </>
                    )}
                  </button>
                  <button
                    onClick={handleWishlist}
                    disabled={wishlistLoading}
                    className="btn-ghost px-4"
                    aria-label="İstek listesine ekle"
                  >
                    <Heart className="w-4 h-4" aria-hidden="true" />
                  </button>
                </div>
              </div>
            )}

            {/* View count */}
            {product.view_count > 0 && (
              <div className="flex items-center gap-1.5 text-[11px] text-[#7A7A7A] mb-6">
                <Eye className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{product.view_count.toLocaleString()} {t('product.viewsCount')}</span>
              </div>
            )}

            {/* Trust Badges */}
            <div className="grid grid-cols-3 gap-2.5 mb-6">
              {[
                { icon: <Shield className="w-4 h-4" aria-hidden="true" />, label: t('product.authenticity') },
                { icon: <Award className="w-4 h-4" aria-hidden="true" />,  label: t('product.shipping') },
                { icon: <FileText className="w-4 h-4" aria-hidden="true" />, label: t('product.securePurchase') },
              ].map((badge, i) => (
                <div key={i} className="flex flex-col items-center gap-1.5 p-3 border border-[#E0D8CC] bg-white text-center">
                  <span className="text-[#8B7355]">{badge.icon}</span>
                  <span className="text-[9px] uppercase tracking-wider text-[#7A7A7A] leading-tight font-medium">{badge.label}</span>
                </div>
              ))}
            </div>

            {/* Tabs */}
            <div
              className="border-b border-[#E0D8CC] mb-5 overflow-x-auto"
              role="tablist"
              aria-label="Ürün detayları"
            >
              <div className="flex gap-0 min-w-max">
                {TABS.map(tb => (
                  <button
                    key={tb.key}
                    role="tab"
                    aria-selected={tab === tb.key}
                    onClick={() => setTab(tb.key)}
                    className={`px-4 pb-3 pt-1 text-[12px] whitespace-nowrap font-medium transition-colors ${
                      tab === tb.key
                        ? 'text-[#8B7355] border-b-2 border-[#8B7355]'
                        : 'text-[#7A7A7A] hover:text-[#4A4A4A] border-b-2 border-transparent'
                    }`}
                  >
                    {tb.label}
                  </button>
                ))}
              </div>
            </div>

            <div
              role="tabpanel"
              className="prose-anticca min-h-[100px] animate-fadeIn"
              key={tab}
            >
              {tab === 'description' && (
                <p>{tObj(product.description) || '—'}</p>
              )}
              {tab === 'provenance' && (
                <p>{tObj(product.provenance) || '—'}</p>
              )}
              {tab === 'condition' && (
                <p>{tObj(product.condition_report) || product.condition || '—'}</p>
              )}
              {tab === 'investment' && (
                <div className="flex items-start gap-3">
                  <TrendingUp className="w-4 h-4 text-[#8B7355] mt-0.5 shrink-0" aria-hidden="true" />
                  <p>{tObj(product.investment_perspective) || '—'}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Similar Products */}
        {similar.length > 0 && (
          <section className="mt-20 lg:mt-24 pt-12 border-t border-[#E0D8CC]" aria-labelledby="similar-heading">
            <h2 id="similar-heading" className="font-serif text-[26px] text-[#2C2C2C] mb-8">
              {t('product.similarProducts')}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 lg:gap-6">
              {similar.slice(0, 4).map(p => <ProductCard key={p.product_id} product={p} />)}
            </div>
          </section>
        )}
      </main>

      {/* Zoom modal */}
      {zoomed && (
        <div
          className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center cursor-zoom-out animate-fadeIn"
          onClick={() => setZoomed(false)}
          role="dialog"
          aria-label="Resim yakınlaştırma"
          aria-modal="true"
        >
          <button
            className="absolute top-4 right-4 w-10 h-10 bg-white/10 border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-colors"
            onClick={() => setZoomed(false)}
            aria-label="Kapat"
          >
            ✕
          </button>
          <img
            src={images[imgIdx]}
            alt={tObj(product.title)}
            className="max-w-[90vw] max-h-[90vh] object-contain animate-zoomIn"
            onClick={e => e.stopPropagation()}
          />
          {images.length > 1 && (
            <>
              <button
                onClick={e => { e.stopPropagation(); setImgIdx(i => i > 0 ? i - 1 : images.length - 1); }}
                className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/10 border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-colors"
                aria-label="Önceki"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={e => { e.stopPropagation(); setImgIdx(i => i < images.length - 1 ? i + 1 : 0); }}
                className="absolute right-14 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/10 border border-white/20 flex items-center justify-center text-white hover:bg-white/20 transition-colors"
                aria-label="Sonraki"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </>
          )}
        </div>
      )}

      <Footer />
    </div>
  );
}
