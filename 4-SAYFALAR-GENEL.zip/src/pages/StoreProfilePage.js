import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { apiClient } from '../lib/apiClient';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ProductCard from '../components/ProductCard';
import { useLanguage } from '../contexts/LanguageContext';
import { CheckCircle, MapPin, Mail, Phone, Globe, ArrowLeft } from 'lucide-react';
import { LoadingSpinner, ProductGridSkeleton } from '../components/ui-custom/LoadingSpinner';


export default function StoreProfilePage() {
  const { id } = useParams();
  const { t, tObj } = useLanguage();
  const [store, setStore] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');

  useEffect(() => {
    let cancelled = false;
    apiClient.get(`/api/stores/${id}`)
      .then(r => { if (!cancelled) setStore(r.data); })
      .catch(err => { if (process.env.NODE_ENV !== 'production') console.warn('[StoreProfile]', err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [id]);

  if (loading) return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />
      <div className="flex justify-center items-center py-40"><LoadingSpinner size="lg" /></div>
    </div>
  );

  if (!store) return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />
      <div className="text-center py-40">
        <p className="text-[#7A7A7A]">{t('common.noResults')}</p>
        <Link to="/magazalar" className="mt-4 inline-block text-[#8B7355] hover:underline">{t('common.back')}</Link>
      </div>
    </div>
  );

  const tabs = [
    { key: 'all',      label: t('stores.activeListings'),  products: store.products },
    { key: 'auctions', label: t('stores.auctionItems'),     products: store.auction_products },
    { key: 'direct',   label: t('nav.directSales'),          products: store.direct_products },
  ];
  const displayProducts = tabs.find(tb => tb.key === activeTab)?.products || [];

  return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />

      {/* Back */}
      <nav className="border-b border-[#E0D8CC] bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <Link
            to="/magazalar"
            className="inline-flex items-center gap-2 text-[12px] text-[#8B7355] hover:text-[#6B5842] transition-colors font-medium uppercase tracking-wider"
          >
            <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
            {t('stores.title')}
          </Link>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Store Header */}
        <div className="bg-white border border-[#E0D8CC] p-8 mb-10">
          <div className="flex flex-col sm:flex-row items-start gap-6">
            {store.logo ? (
              <img
                src={store.logo}
                alt={store.name}
                className="w-20 h-20 object-cover border border-[#E0D8CC]"
              />
            ) : (
              <div className="w-20 h-20 bg-[#F2EDE4] flex items-center justify-center font-serif text-3xl text-[#8B7355] border border-[#E0D8CC]">
                {store.name?.[0]}
              </div>
            )}
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-3 mb-3">
                <h1 className="font-serif text-[28px] lg:text-[34px] text-[#2C2C2C]">{store.name}</h1>
                {store.verified && (
                  <span className="flex items-center gap-1.5 text-[9px] uppercase tracking-wider bg-[#8B7355]/10 text-[#8B7355] px-3 py-1 font-semibold border border-[#8B7355]/20">
                    <CheckCircle className="w-3 h-3" aria-hidden="true" />
                    {t('stores.verified')}
                  </span>
                )}
              </div>
              <p className="text-[14px] text-[#4A4A4A] leading-relaxed mb-5 max-w-2xl">
                {tObj(store.description)}
              </p>
              <div className="flex flex-wrap gap-5 text-[12px] text-[#7A7A7A]">
                {store.address && (
                  <span className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-[#8B7355]" aria-hidden="true" />
                    {store.address}
                  </span>
                )}
                {store.contact_email && (
                  <a href={`mailto:${store.contact_email}`} className="flex items-center gap-1.5 hover:text-[#8B7355] transition-colors">
                    <Mail className="w-3.5 h-3.5 text-[#8B7355]" aria-hidden="true" />
                    {store.contact_email}
                  </a>
                )}
                {store.phone && (
                  <a href={`tel:${store.phone}`} className="flex items-center gap-1.5 hover:text-[#8B7355] transition-colors">
                    <Phone className="w-3.5 h-3.5 text-[#8B7355]" aria-hidden="true" />
                    {store.phone}
                  </a>
                )}
                {store.website && (
                  <a href={store.website} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 hover:text-[#8B7355] transition-colors">
                    <Globe className="w-3.5 h-3.5 text-[#8B7355]" aria-hidden="true" />
                    Website
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* Stats */}
          {(store.product_count || store.auction_count || store.past_sales_count) && (
            <div className="flex flex-wrap gap-8 mt-6 pt-6 border-t border-[#F0EBE3]">
              {store.product_count !== undefined && (
                <div>
                  <p className="font-mono-data text-[22px] text-[#2C2C2C]">{store.product_count}</p>
                  <p className="text-[10px] uppercase tracking-wider text-[#7A7A7A] font-medium mt-0.5">{t('stores.activeListings')}</p>
                </div>
              )}
              {store.auction_count > 0 && (
                <div>
                  <p className="font-mono-data text-[22px] text-[#2C2C2C]">{store.auction_count}</p>
                  <p className="text-[10px] uppercase tracking-wider text-[#7A7A7A] font-medium mt-0.5">{t('stores.auctionItems')}</p>
                </div>
              )}
              {store.past_sales_count > 0 && (
                <div>
                  <p className="font-mono-data text-[22px] text-[#2C2C2C]">{store.past_sales_count}</p>
                  <p className="text-[10px] uppercase tracking-wider text-[#7A7A7A] font-medium mt-0.5">{t('stores.pastSales')}</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Tabs */}
        <div className="border-b border-[#E0D8CC] mb-8" role="tablist" aria-label="Mağaza sekmeleri">
          <div className="flex gap-0">
            {tabs.map(tb => (
              <button
                key={tb.key}
                role="tab"
                aria-selected={activeTab === tb.key}
                onClick={() => setActiveTab(tb.key)}
                className={`px-5 pb-3 pt-1 text-[13px] font-medium transition-colors border-b-2 ${
                  activeTab === tb.key
                    ? 'text-[#8B7355] border-[#8B7355]'
                    : 'text-[#7A7A7A] hover:text-[#4A4A4A] border-transparent'
                }`}
              >
                {tb.label}
                {tb.products?.length > 0 && (
                  <span className="ml-1.5 text-[10px] text-[#7A7A7A]">({tb.products.length})</span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Products */}
        {!displayProducts?.length ? (
          <div className="text-center py-16">
            <p className="text-[#7A7A7A]">{t('common.noResults')}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 lg:gap-6" role="tabpanel">
            {displayProducts.map(p => <ProductCard key={p.product_id} product={p} />)}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
