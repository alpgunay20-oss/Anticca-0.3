import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { apiClient } from '../lib/apiClient';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '../contexts/LanguageContext';
import { CheckCircle, ArrowRight, Search } from 'lucide-react';
import { LoadingSpinner } from '../components/ui-custom/LoadingSpinner';


export default function StoresPage() {
  const { t, tObj } = useLanguage();
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    let cancelled = false;
    apiClient.get('/api/stores')
      .then(r => { if (!cancelled) setStores(r.data.stores || []); })
      .catch(err => { if (process.env.NODE_ENV !== 'production') console.warn('[Stores]', err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []);

  const filtered = stores.filter(s =>
    !search || s.name?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />

      <div className="bg-[#F2EDE4] border-b border-[#E0D8CC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
          <p className="section-eyebrow">ANTICCA</p>
          <h1 className="font-serif text-[36px] lg:text-[48px] text-[#2C2C2C]">{t('stores.title')}</h1>
          <div className="divider-bronze mt-3" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Search */}
        <div className="relative max-w-sm mb-8">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7A7A7A] pointer-events-none" aria-hidden="true" />
          <label htmlFor="store-search" className="sr-only">Mağaza ara</label>
          <input
            id="store-search"
            type="search"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Mağaza ara..."
            className="input-base pl-10"
          />
        </div>

        {loading ? (
          <div className="flex justify-center py-20"><LoadingSpinner size="lg" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-[#7A7A7A]">{t('common.noResults')}</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map(store => (
              <Link
                key={store.store_id}
                to={`/magaza/${store.store_id}`}
                className="group block bg-white border border-[#E0D8CC] overflow-hidden hover:shadow-[0_8px_30px_rgba(44,44,44,0.08)] hover:border-[#8B7355]/25 transition-all duration-300"
                aria-label={`${store.name} mağazasını görüntüle`}
              >
                <div className="p-6">
                  <div className="flex items-start gap-4 mb-4">
                    {store.logo ? (
                      <img
                        src={store.logo}
                        alt={store.name}
                        className="w-16 h-16 object-cover shrink-0 border border-[#E0D8CC]"
                        loading="lazy"
                      />
                    ) : (
                      <div className="w-16 h-16 bg-[#F2EDE4] flex items-center justify-center font-serif text-[22px] text-[#8B7355] shrink-0 border border-[#E0D8CC]">
                        {store.name?.[0]}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <h3 className="font-serif text-[18px] text-[#2C2C2C] group-hover:text-[#8B7355] transition-colors leading-tight">
                          {store.name}
                        </h3>
                        {store.verified && (
                          <div className="flex items-center gap-1">
                            <CheckCircle className="w-4 h-4 text-[#8B7355] shrink-0" aria-label="Doğrulanmış mağaza" />
                            <span className="text-[9px] uppercase tracking-wider text-[#8B7355] font-semibold">{t('stores.verified')}</span>
                          </div>
                        )}
                      </div>
                      {store.address && (
                        <p className="text-[11px] text-[#7A7A7A]">{store.address}</p>
                      )}
                    </div>
                  </div>

                  <p className="text-[13px] text-[#4A4A4A] leading-relaxed line-clamp-2 mb-5">
                    {tObj(store.description)}
                  </p>

                  <div className="flex items-center justify-between pt-4 border-t border-[#F0EBE3]">
                    <div className="flex gap-4 text-[11px] text-[#7A7A7A]">
                      <span><strong className="text-[#2C2C2C] font-semibold font-mono-data">{store.product_count || 0}</strong> {t('stores.products')}</span>
                      {store.auction_count > 0 && (
                        <span><strong className="text-[#2C2C2C] font-semibold font-mono-data">{store.auction_count}</strong> müzayede</span>
                      )}
                    </div>
                    <ArrowRight className="w-4 h-4 text-[#8B7355] group-hover:translate-x-1.5 transition-transform duration-200" aria-hidden="true" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
