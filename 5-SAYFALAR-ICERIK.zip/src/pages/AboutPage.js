import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '../contexts/LanguageContext';
import { Shield, Target, Eye, Heart, Award } from 'lucide-react';

export default function AboutPage() {
  const { t } = useLanguage();

  const sections = [
    {
      id: 'story',
      title: t('about.brandStory'),
      content: {
        tr: 'ANTICCA, degerli koleksiyon parcalarinin ve nadir varliklarin guvenilir bir platformda bulusmasi vizyonuyla 2024 yilinda kurulmustur. Istanbul merkezli olarak faaliyet gosteren platformumuz, Turkiye ve uluslararasi piyasalardaki koleksiyonculari, yatirimcilari ve sanatseverleri bir araya getirmektedir. Her parcamiz, uzman ekibimiz tarafindan titizlikle dogrulanir ve belgelenir.',
        en: 'ANTICCA was founded in 2024 with the vision of bringing valuable collectibles and rare assets together on a trusted platform. Operating from Istanbul, our platform connects collectors, investors, and art enthusiasts across Turkey and international markets.',
        it: 'ANTICCA e stata fondata nel 2024 con la visione di riunire oggetti da collezione e beni rari su una piattaforma affidabile.'
      }
    },
    {
      id: 'mission',
      title: t('about.mission'),
      icon: <Target className="w-6 h-6" />,
      content: {
        tr: 'Misyonumuz, degerli koleksiyon parcalarinin alisverisini guvenli, seffaf ve erisilebiIir kilmaktir. Her islemde en yuksek standartlari uygulayarak, alicilarin ve saticilarin birbirine guvenebilecegi bir ekosistem olusturuyoruz. Uzman dogrulama, sigortalI kargo ve profesyonel musteri hizmetleri ile koleksiyonculuk deneyimini yeni bir seviyeye tasiyoruz.',
        en: 'Our mission is to make the trading of valuable collectibles safe, transparent, and accessible. We create an ecosystem of trust between buyers and sellers.',
        it: 'La nostra missione e rendere il commercio di oggetti da collezione sicuro, trasparente e accessibile.'
      }
    },
    {
      id: 'vision',
      title: t('about.vision'),
      icon: <Eye className="w-6 h-6" />,
      content: {
        tr: 'Vizyonumuz, dunyanin onde gelen koleksiyon ve nadir varlik pazaryeri olmak, Turkiye\'nin bu alandaki potansiyelini kuresel arenaya tasimaktir. Teknoloji ve geleneksel uzmanligin birlesimi ile koleksiyonculugun gelecegini sekillendirmeyi hedefliyoruz.',
        en: 'Our vision is to become the world\'s leading collectibles and rare asset marketplace, carrying Turkey\'s potential in this field to the global arena.',
        it: 'La nostra visione e diventare il marketplace leader mondiale per collezionabili e beni rari.'
      }
    },
    {
      id: 'values',
      title: t('about.values'),
      icon: <Heart className="w-6 h-6" />,
      content: {
        tr: 'Guvenilirlik, seffaflik, uzmanlik ve tutku. Bu dort deger, ANTICCA\'nin temelini olusturur. Her kararimiZda bu degerleri on planda tutarak, koleksiyonculuk dunyasinda yeni standartlar belirliyoruz. Musterilerimizin guveni bizim icin en degerli varligimizdir.',
        en: 'Reliability, transparency, expertise, and passion. These four values form the foundation of ANTICCA.',
        it: 'Affidabilita, trasparenza, competenza e passione. Questi quattro valori formano le fondamenta di ANTICCA.'
      }
    },
    {
      id: 'trust',
      title: t('about.trust'),
      icon: <Award className="w-6 h-6" />,
      content: {
        tr: 'ANTICCA\'da guven, her islemin merkezindedir. Tum urunler bagimsiz uzmanlar tarafindan dogrulanir. Orijinallik sertifikalari, detayli durum raporlari ve belgelenmis provenance bilgileri her urun icin standart olarak sunulur. 256-bit SSL sifreleme, sigortali kargo ve profesyonel emanet hizmeti ile alisveris guvenligi saglanir.',
        en: 'At ANTICCA, trust is at the center of every transaction. All products are verified by independent experts.',
        it: 'In ANTICCA, la fiducia e al centro di ogni transazione. Tutti i prodotti sono verificati da esperti indipendenti.'
      }
    }
  ];

  return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />

      {/* Hero */}
      <div className="relative h-[40vh] min-h-[300px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img src="https://images.pexels.com/photos/2372944/pexels-photo-2372944.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="About" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-[#2C2C2C]/60" />
        </div>
        <div className="relative z-10 text-center">
          <h1 className="font-serif text-4xl sm:text-5xl text-white">{t('about.title')}</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16">
        {sections.map((section, i) => (
          <div key={section.id} className={`${i > 0 ? 'mt-16 pt-16 border-t border-[#E0D8CC]' : ''}`}>
            <div className="flex items-center gap-3 mb-6">
              {section.icon && <span className="text-[#8B7355]">{section.icon}</span>}
              <h2 className="font-serif text-2xl text-[#2C2C2C]">{section.title}</h2>
            </div>
            <p className="text-base text-[#4A4A4A] leading-[1.8]">
              {typeof section.content === 'object' ? (section.content['tr'] || section.content['en']) : section.content}
            </p>
          </div>
        ))}
      </div>

      {/* Stats */}
      <div className="bg-[#F5F1EB] py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { value: '500+', label: 'Dogrulanmis Urun' },
              { value: '50+', label: 'Partner Magaza' },
              { value: '10K+', label: 'Koleksiyoncu' },
              { value: '15+', label: 'Ulke' }
            ].map((stat, i) => (
              <div key={i}>
                <p className="font-serif text-3xl text-[#8B7355]">{stat.value}</p>
                <p className="text-xs uppercase tracking-wider text-[#7A7A7A] mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
