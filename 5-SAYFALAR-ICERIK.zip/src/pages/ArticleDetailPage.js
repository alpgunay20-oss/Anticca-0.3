import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { apiClient } from '../lib/apiClient';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '../contexts/LanguageContext';
import { LoadingSpinner } from '../components/ui-custom/LoadingSpinner';
import { ArrowLeft, Calendar, User } from 'lucide-react';


export default function ArticleDetailPage() {
  const { id } = useParams();
  const { t, tObj } = useLanguage();
  const [article, setArticle] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    apiClient.get(`/api/articles/${id}`)
      .then(r => { if (!cancelled) setArticle(r.data); })
      .catch(err => { if (process.env.NODE_ENV !== 'production') console.warn('[ArticleDetail]', err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [id]);

  if (loading) return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />
      <div className="flex justify-center items-center py-40"><LoadingSpinner size="lg" /></div>
    </div>
  );

  if (!article) return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />
      <div className="text-center py-40">
        <p className="text-[#7A7A7A]">{t('common.noResults')}</p>
        <Link to="/makaleler" className="mt-4 inline-block text-[#8B7355] hover:underline">{t('common.back')}</Link>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />

      {/* Hero image */}
      {article.featured_image && (
        <div className="w-full aspect-[21/8] overflow-hidden max-h-[500px] bg-[#F2EDE4]">
          <img
            src={article.featured_image}
            alt={tObj(article.title)}
            className="w-full h-full object-cover"
          />
        </div>
      )}

      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        {/* Back */}
        <Link
          to="/makaleler"
          className="inline-flex items-center gap-2 text-[12px] text-[#8B7355] hover:text-[#6B5842] transition-colors mb-8 font-medium uppercase tracking-wider"
        >
          <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
          {t('articles.title')}
        </Link>

        <p className="section-eyebrow mb-3">{article.category}</p>
        <h1 className="font-serif text-[32px] sm:text-[42px] text-[#2C2C2C] leading-tight mb-5">
          {tObj(article.title)}
        </h1>

        <div className="flex items-center gap-4 text-[12px] text-[#7A7A7A] pb-8 mb-8 border-b border-[#E0D8CC]">
          <span className="flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            {article.author}
          </span>
          <span className="w-px h-3.5 bg-[#D4CCBF]" aria-hidden="true" />
          <span className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            {new Date(article.created_at).toLocaleDateString('tr-TR', { year: 'numeric', month: 'long', day: 'numeric' })}
          </span>
        </div>

        {article.excerpt && (
          <p className="font-serif text-[19px] text-[#4A4A4A] leading-[1.7] mb-8 italic">
            {tObj(article.excerpt)}
          </p>
        )}

        <div className="prose-anticca">
          <p className="whitespace-pre-line">{tObj(article.content)}</p>
        </div>
      </main>

      <div className="border-t border-[#E0D8CC] py-10">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 text-center">
          <Link to="/makaleler" className="btn-outline inline-flex">
            <ArrowLeft className="w-4 h-4" aria-hidden="true" />
            Tüm Makaleler
          </Link>
        </div>
      </div>

      <Footer />
    </div>
  );
}
