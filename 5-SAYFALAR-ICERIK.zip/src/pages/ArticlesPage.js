import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { apiClient } from '../lib/apiClient';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '../contexts/LanguageContext';
import { LoadingSpinner } from '../components/ui-custom/LoadingSpinner';

const CATEGORIES = ['yatirim', 'kultur', 'sanat', 'koleksiyon'];

export default function ArticlesPage() {
  const { t, tObj } = useLanguage();
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState('');

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      try {
        const params = category ? `?category=${category}` : '';
        const res = await apiClient.get(`/api/articles${params}`);
        setArticles(res.data.articles || []);
      } catch (err) { if (process.env.NODE_ENV !== "production") console.warn("[Articles]", err.message); }
      setLoading(false);
    };
    return () => { cancelled = true; };
  }, [category]);

  const featured = articles[0];
  const rest = articles.slice(1);

  return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />

      <div className="bg-[#F2EDE4] border-b border-[#E0D8CC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
          <p className="section-eyebrow">ANTICCA</p>
          <h1 className="font-serif text-[36px] lg:text-[48px] text-[#2C2C2C]">{t('articles.title')}</h1>
          <div className="divider-bronze mt-3" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Filter tabs */}
        <div
          className="flex flex-wrap gap-2 mb-10 pb-8 border-b border-[#E0D8CC]"
          role="group"
          aria-label="Kategori filtresi"
        >
          <button
            onClick={() => setCategory('')}
            aria-pressed={!category}
            className={`px-4 py-2 text-[12px] font-semibold uppercase tracking-[0.1em] transition-all duration-200 ${
              !category ? 'bg-[#8B7355] text-white' : 'border border-[#E0D8CC] text-[#4A4A4A] hover:border-[#8B7355] hover:text-[#8B7355]'
            }`}
          >
            {t('articles.allCategories')}
          </button>
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              aria-pressed={category === cat}
              className={`px-4 py-2 text-[12px] font-semibold uppercase tracking-[0.1em] capitalize transition-all duration-200 ${
                category === cat ? 'bg-[#8B7355] text-white' : 'border border-[#E0D8CC] text-[#4A4A4A] hover:border-[#8B7355] hover:text-[#8B7355]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex justify-center py-20"><LoadingSpinner size="lg" /></div>
        ) : articles.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-[#7A7A7A]">{t('common.noResults')}</p>
          </div>
        ) : (
          <>
            {/* Featured article */}
            {!category && featured && (
              <Link
                to={`/makale/${featured.article_id}`}
                className="group grid grid-cols-1 lg:grid-cols-2 gap-0 mb-12 bg-white border border-[#E0D8CC] overflow-hidden hover:shadow-[0_8px_30px_rgba(44,44,44,0.08)] transition-all duration-300"
                aria-label={`Öne çıkan: ${tObj(featured.title)}`}
              >
                {featured.featured_image && (
                  <div className="aspect-[16/10] lg:aspect-auto overflow-hidden bg-[#F2EDE4]">
                    <img
                      src={featured.featured_image}
                      alt={tObj(featured.title)}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
                      loading="lazy"
                    />
                  </div>
                )}
                <div className="p-8 lg:p-10 flex flex-col justify-center">
                  <p className="section-eyebrow mb-3">{featured.category} · Öne Çıkan</p>
                  <h2 className="font-serif text-[26px] lg:text-[32px] text-[#2C2C2C] mb-4 leading-snug group-hover:text-[#8B7355] transition-colors">
                    {tObj(featured.title)}
                  </h2>
                  <p className="text-[13px] text-[#7A7A7A] leading-relaxed line-clamp-3 mb-6">
                    {tObj(featured.excerpt)}
                  </p>
                  <div className="flex items-center gap-3 text-[11px] text-[#7A7A7A]">
                    <span>{featured.author}</span>
                    <span className="w-px h-3 bg-[#D4CCBF]" aria-hidden="true" />
                    <span>{new Date(featured.created_at).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
                  </div>
                </div>
              </Link>
            )}

            {/* Article grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {(category ? articles : rest).map((article, i) => (
                <Link
                  key={article.article_id}
                  to={`/makale/${article.article_id}`}
                  className="group block animate-fadeInUp"
                  style={{ animationDelay: `${i * 0.08}s` }}
                  aria-label={tObj(article.title)}
                >
                  {article.featured_image && (
                    <div className="aspect-[16/10] overflow-hidden mb-4 bg-[#F2EDE4]">
                      <img
                        src={article.featured_image}
                        alt={tObj(article.title)}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.05]"
                        loading="lazy"
                        decoding="async"
                      />
                    </div>
                  )}
                  <p className="section-eyebrow mb-2">{article.category}</p>
                  <h3 className="font-serif text-[20px] text-[#2C2C2C] mb-2.5 group-hover:text-[#8B7355] transition-colors leading-snug line-clamp-2">
                    {tObj(article.title)}
                  </h3>
                  <p className="text-[13px] text-[#7A7A7A] line-clamp-2 leading-relaxed mb-3">
                    {tObj(article.excerpt)}
                  </p>
                  <div className="flex items-center gap-2 text-[11px] text-[#7A7A7A]">
                    <span>{article.author}</span>
                    <span className="w-px h-3 bg-[#D4CCBF]" aria-hidden="true" />
                    <span>{new Date(article.created_at).toLocaleDateString('tr-TR', { day: 'numeric', month: 'long' })}</span>
                  </div>
                </Link>
              ))}
            </div>
          </>
        )}
      </div>

      <Footer />
    </div>
  );
}
