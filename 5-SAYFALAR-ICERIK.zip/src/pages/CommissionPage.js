import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '../contexts/LanguageContext';

export default function CommissionPage() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        <div className="mb-12">
          <p className="section-eyebrow mb-2">ANTICCA</p>
          <h1 className="font-serif text-4xl text-[#2C2C2C]">{t('commissionPage.title')}</h1>
        </div>
        <div className="space-y-8 text-sm text-[#4A4A4A] leading-[1.8]">
          <section>
            <h2 className="font-serif text-xl text-[#2C2C2C] mb-3">Alici Komisyonu</h2>
            <p>ANTICCA uzerinden gerceklestirilen tum alimlarda, satis fiyatinin %5'i oraninda alici komisyonu uygulanir. Bu komisyon, platformun guvenlik, dogrulama ve musteri hizmetleri maliyetlerini kapsamaktadir.</p>
            <div className="mt-4 border border-[#E0D8CC] overflow-hidden">
              <table className="w-full">
                <thead><tr className="bg-[#F5F1EB]"><th className="text-left py-3 px-4 text-xs uppercase tracking-wider text-[#7A7A7A]">Islem Tutari</th><th className="text-left py-3 px-4 text-xs uppercase tracking-wider text-[#7A7A7A]">Komisyon Orani</th></tr></thead>
                <tbody>
                  <tr className="border-t border-[#E0D8CC]"><td className="py-3 px-4">$0 - $50.000</td><td className="py-3 px-4">%5</td></tr>
                  <tr className="border-t border-[#E0D8CC]"><td className="py-3 px-4">$50.001 - $250.000</td><td className="py-3 px-4">%4</td></tr>
                  <tr className="border-t border-[#E0D8CC]"><td className="py-3 px-4">$250.001+</td><td className="py-3 px-4">%3</td></tr>
                </tbody>
              </table>
            </div>
          </section>
          <section>
            <h2 className="font-serif text-xl text-[#2C2C2C] mb-3">Satici Komisyonu</h2>
            <p>Satici komisyonu, urun kategorisine gore degismektedir. Muzayede ve direkt satis islemlerinde ayni komisyon oranlari gecerlidir.</p>
            <div className="mt-4 border border-[#E0D8CC] overflow-hidden">
              <table className="w-full">
                <thead><tr className="bg-[#F5F1EB]"><th className="text-left py-3 px-4 text-xs uppercase tracking-wider text-[#7A7A7A]">Kategori</th><th className="text-left py-3 px-4 text-xs uppercase tracking-wider text-[#7A7A7A]">Komisyon Orani</th></tr></thead>
                <tbody>
                  <tr className="border-t border-[#E0D8CC]"><td className="py-3 px-4">Saatler</td><td className="py-3 px-4">%10</td></tr>
                  <tr className="border-t border-[#E0D8CC]"><td className="py-3 px-4">Sanat Eserleri</td><td className="py-3 px-4">%12</td></tr>
                  <tr className="border-t border-[#E0D8CC]"><td className="py-3 px-4">Mucevher</td><td className="py-3 px-4">%10</td></tr>
                  <tr className="border-t border-[#E0D8CC]"><td className="py-3 px-4">Sikkeler</td><td className="py-3 px-4">%8</td></tr>
                  <tr className="border-t border-[#E0D8CC]"><td className="py-3 px-4">Antikalar</td><td className="py-3 px-4">%12</td></tr>
                  <tr className="border-t border-[#E0D8CC]"><td className="py-3 px-4">Klasik Otomobiller</td><td className="py-3 px-4">%8</td></tr>
                </tbody>
              </table>
            </div>
          </section>
          <section>
            <h2 className="font-serif text-xl text-[#2C2C2C] mb-3">Muzayede Komisyonu</h2>
            <p>Muzayede islemlerinde, yukaridaki alici ve satici komisyonlarina ek olarak herhangi bir ek ucret alinmaz. Muzayede kazanan alici, son teklif tutari uzerinden komisyon odemesini gerceklestirir.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-[#2C2C2C] mb-3">Odeme Zamanlari</h2>
            <p>Satici komisyonu, urunun aliciya teslim edilmesinden ve onay suresinin dolmasindan sonra kesilir. Kalan tutar, satis sonrasi 7-14 is gunu icinde satici hesabina aktarilir.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-[#2C2C2C] mb-3">Seffaflik Taahhudumuz</h2>
            <p>ANTICCA olarak, tum komisyon ve ucretlerimizi seffaf bir sekilde paylasiyoruz. Gizli ucret veya ek maliyet uygulamasi bulunmamaktadir. Herhangi bir sorunuz icin commission@anticca.com adresinden bize ulasabilirsiniz.</p>
          </section>
        </div>
      </div>
      <Footer />
    </div>
  );
}
