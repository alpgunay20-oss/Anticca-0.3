import React, { useState, useEffect } from 'react';
import { apiClient } from '../lib/apiClient';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '../contexts/LanguageContext';
import { ChevronDown } from 'lucide-react';
import { LoadingSpinner } from '../components/ui-custom/LoadingSpinner';


export default function FAQPage() {
  const { t, tObj } = useLanguage();
  const [faqItems, setFaqItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [openIdx, setOpenIdx] = useState(null);

  useEffect(() => {
    let cancelled = false;
    apiClient.get('/api/faq')
      .then(r => { if (!cancelled) setFaqItems(r.data.items || []); })
      .catch(err => { if (process.env.NODE_ENV !== 'production') console.warn('[FAQ]', err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []);

  return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />
      <div className="bg-[#F2EDE4] border-b border-[#E0D8CC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <p className="section-eyebrow">ANTICCA</p>
          <h1 className="font-serif text-[36px] lg:text-[48px] text-[#2C2C2C]">{t('faq.title')}</h1>
          <div className="divider-bronze mt-3" />
        </div>
      </div>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        {loading ? (
          <div className="flex justify-center py-20"><LoadingSpinner size="lg" /></div>
        ) : faqItems.length === 0 ? (
          <p className="text-center text-[#7A7A7A] py-20">{t('common.noResults')}</p>
        ) : (
          <div className="space-y-2">
            {faqItems.map((item, i) => (
              <div key={i} className="bg-white border border-[#E0D8CC]">
                <button
                  onClick={() => setOpenIdx(openIdx === i ? null : i)}
                  className="w-full flex items-center justify-between px-6 py-5 text-left"
                  aria-expanded={openIdx === i}
                  aria-controls={`faq-answer-${i}`}
                >
                  <span className="font-serif text-[17px] text-[#2C2C2C] leading-snug pr-4">
                    {tObj(item.question)}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-[#8B7355] shrink-0 transition-transform duration-300 ${openIdx === i ? 'rotate-180' : ''}`}
                    aria-hidden="true"
                  />
                </button>
                {openIdx === i && (
                  <div
                    id={`faq-answer-${i}`}
                    className="px-6 pb-5 border-t border-[#F0EBE3] animate-fadeIn"
                  >
                    <p className="text-[14px] text-[#4A4A4A] leading-[1.8] pt-4">
                      {tObj(item.answer)}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
