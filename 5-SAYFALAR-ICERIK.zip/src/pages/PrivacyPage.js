import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '../contexts/LanguageContext';

export default function PrivacyPage() {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
        <div className="mb-12">
          <p className="section-eyebrow mb-2">ANTICCA</p>
          <h1 className="font-serif text-4xl text-[#2C2C2C]">{t('privacy.title')}</h1>
        </div>
        <div className="space-y-8 text-sm text-[#4A4A4A] leading-[1.8]">
          <section>
            <h2 className="font-serif text-xl text-[#2C2C2C] mb-3">1. Genel Bilgiler</h2>
            <p>ANTICCA olarak, kisisel verilerinizin korunmasina buyuk onem veriyoruz. Bu gizlilik politikasi, 6698 sayili Kisisel Verilerin Korunmasi Kanunu (KVKK) kapsaminda kisisel verilerinizin nasil toplandigi, islendigi ve korundugunU aciklamaktadir.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-[#2C2C2C] mb-3">2. Toplanan Veriler</h2>
            <p>Platformumuz uzerinden asagidaki kisisel veriler toplanmaktadir: Ad, soyad, e-posta adresi, telefon numarasi, adres bilgileri, odeme bilgileri, IP adresi ve tarayici bilgileri, alisveris gecmisi ve tercihler.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-[#2C2C2C] mb-3">3. Verilerin Kullanim Amaci</h2>
            <p>Toplanan veriler su amaclarla kullanilmaktadir: Hizmet sunumu ve siparis islemleri, musteri iletisimi, guvenlik ve dolandiricilik onleme, yasal yukumlulukler, kisisellestiriIlmis deneyim sunumu.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-[#2C2C2C] mb-3">4. Veri Guvenligi</h2>
            <p>Kisisel verileriniz, 256-bit SSL sifreleme ile korunmaktadir. Tum odeme islemleri PCI-DSS uyumlu alt yapi uzerinden gerceklestirilmektedir. Verilerinize yetkisiz erisimi onlemek icin guncel guvenlik protokolleri uygulanmaktadir.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-[#2C2C2C] mb-3">5. KVKK Kapsamindaki Haklariniz</h2>
            <p>KVKK kapsaminda asagidaki haklara sahipsiniz: Kisisel verilerinizin isleniip islenmedigini ogrenme, islenme amacini ve amacina uygun kullanilip kullanilmadigini ogrenme, yurt icinde veya yurt disinda aktarilma durumunu ogrenme, duzeltilmesini veya silinmesini talep etme.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-[#2C2C2C] mb-3">6. Cerez Politikasi</h2>
            <p>Web sitemiz, deneyiminizi iyilestirmek icin cerezler kullanmaktadir. Zorunlu cerezler, performans cerezleri ve tercih cerezleri kullanilmaktadir. Cerez tercihlerinizi tarayici ayarlariniz uzerinden yonetebilirsiniz.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-[#2C2C2C] mb-3">7. Iletisim</h2>
            <p>Gizlilik politikamiz hakkinda sorulariniz icin privacy@anticca.com adresinden bizimle iletisime gecebilirsiniz.</p>
          </section>
          <p className="text-xs text-[#7A7A7A] mt-12">Son guncelleme: Ocak 2025</p>
        </div>
      </div>
      <Footer />
    </div>
  );
}
