/**
 * AdminPage — Refactored Versiyon
 *
 * Giderilen bulgular:
 * 5.2  Sessiz catch blokları → anlamlı error state eklendi
 * 5.4  Hardcoded Türkçe sekme etiketleri → t() ile çeviri desteği
 * 3.1  SRP: veri çekme useAdminData hook'una taşındı
 * 3.2  OCP: sekme sistemi kayıt haritasıyla yönetiliyor
 * S-01  Bu bileşene yalnızca AdminRoute üzerinden gelinir (App.js'de kontrol edilir)
 */
import React, { useState } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '../contexts/LanguageContext';
import { useAdminData } from '../hooks/useAdminData';
import { BarChart3, Package, Users, ShoppingCart, Store, FileText } from 'lucide-react';

/* ── Sekme kayıt haritası (OCP) ── */
function TabRegistry({ tabs, activeTab, onChange }) {
  return (
    <div className="flex gap-2 mb-8 overflow-x-auto">
      {tabs.map(tb => (
        <button
          key={tb.key}
          onClick={() => onChange(tb.key)}
          className={`flex items-center gap-2 px-4 py-2 text-sm whitespace-nowrap transition-colors ${
            activeTab === tb.key
              ? 'bg-[#8B7355] text-white'
              : 'border border-[#E0D8CC] text-[#4A4A4A] hover:border-[#8B7355]'
          }`}
        >
          {tb.icon} {tb.label}
        </button>
      ))}
    </div>
  );
}

/* ── Genel Bakış ── */
function OverviewTab({ stats }) {
  const { t } = useLanguage();
  const cards = [
    { label: t('admin.products'),  value: stats.total_products,                icon: <Package className="w-5 h-5" /> },
    { label: t('admin.auctions'),  value: stats.active_auctions,               icon: <BarChart3 className="w-5 h-5" /> },
    { label: t('admin.users'),     value: stats.total_users,                   icon: <Users className="w-5 h-5" /> },
    { label: t('admin.orders'),    value: stats.total_orders,                  icon: <ShoppingCart className="w-5 h-5" /> },
    { label: t('admin.stores'),    value: stats.total_stores,                  icon: <Store className="w-5 h-5" /> },
    { label: t('admin.revenue'),   value: `$${stats.total_revenue?.toLocaleString() || 0}`, icon: <FileText className="w-5 h-5" /> },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {cards.map((s, i) => (
        <div key={i} className="bg-white border border-[#E0D8CC] p-4">
          <div className="text-[#8B7355] mb-2">{s.icon}</div>
          <p className="font-mono-data text-2xl text-[#2C2C2C]">{s.value}</p>
          <p className="text-[10px] uppercase tracking-wider text-[#7A7A7A] mt-1">{s.label}</p>
        </div>
      ))}
    </div>
  );
}

/* ── Ürünler ── */
function ProductsTab({ products }) {
  const { t, tObj } = useLanguage();
  return (
    <div className="bg-white border border-[#E0D8CC] overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="bg-[#F5F1EB] text-left">
            {[t('admin.product'), t('admin.category'), t('admin.type'), t('admin.price'), t('admin.status')].map(h => (
              <th key={h} className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {products.map(p => (
            <tr key={p.product_id} className="border-t border-[#E0D8CC]">
              <td className="py-3 px-4 text-sm text-[#2C2C2C]">{tObj(p.title)}</td>
              <td className="py-3 px-4 text-xs text-[#7A7A7A]">{p.category}</td>
              <td className="py-3 px-4 text-xs">
                {p.is_auction
                  ? <span className="text-[#8B7355]">{t('admin.auction')}</span>
                  : t('admin.direct')}
              </td>
              <td className="py-3 px-4 font-mono-data text-sm">
                ${(p.is_auction ? p.current_bid : p.price)?.toLocaleString()}
              </td>
              <td className="py-3 px-4">
                <span className="text-[10px] uppercase tracking-wider bg-[#F5F1EB] text-[#8B7355] px-2 py-0.5">{p.status}</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ── Siparişler ── */
function OrdersTab({ orders }) {
  const { t } = useLanguage();
  return (
    <div className="bg-white border border-[#E0D8CC] overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="bg-[#F5F1EB] text-left">
            {[t('admin.order'), t('admin.amount'), t('admin.payment'), t('admin.status'), t('admin.date')].map(h => (
              <th key={h} className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {orders.map(o => (
            <tr key={o.order_id} className="border-t border-[#E0D8CC]">
              <td className="py-3 px-4 font-mono-data text-xs text-[#4A4A4A]">{o.order_id}</td>
              <td className="py-3 px-4 font-mono-data text-sm">${o.total?.toLocaleString()}</td>
              <td className="py-3 px-4 text-xs">{o.payment_method}</td>
              <td className="py-3 px-4">
                <span className={`text-[10px] uppercase tracking-wider px-2 py-0.5 ${
                  o.status === 'confirmed' ? 'bg-green-50 text-green-700' : 'bg-[#F5F1EB] text-[#8B7355]'
                }`}>{o.status}</span>
              </td>
              <td className="py-3 px-4 text-xs text-[#7A7A7A]">
                {new Date(o.created_at).toLocaleDateString('tr-TR')}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ── Kullanıcılar ── */
function UsersTab({ users }) {
  const { t } = useLanguage();
  return (
    <div className="bg-white border border-[#E0D8CC] overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="bg-[#F5F1EB] text-left">
            {[t('admin.name'), t('admin.email'), t('admin.role'), t('admin.registeredAt')].map(h => (
              <th key={h} className="py-3 px-4 text-[10px] uppercase tracking-wider text-[#7A7A7A]">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {users.map(u => (
            <tr key={u.user_id} className="border-t border-[#E0D8CC]">
              <td className="py-3 px-4 text-sm text-[#2C2C2C]">{u.name}</td>
              <td className="py-3 px-4 text-sm text-[#4A4A4A]">{u.email}</td>
              <td className="py-3 px-4">
                <span className={`text-[10px] uppercase tracking-wider px-2 py-0.5 ${
                  u.role === 'admin' ? 'bg-[#8B7355]/10 text-[#8B7355]' : 'bg-[#F5F1EB] text-[#7A7A7A]'
                }`}>{u.role}</span>
              </td>
              <td className="py-3 px-4 text-xs text-[#7A7A7A]">
                {u.created_at ? new Date(u.created_at).toLocaleDateString('tr-TR') : '-'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ── Ana Bileşen ── */
export default function AdminPage() {
  const { t } = useLanguage();
  const { stats, products, users, orders, loading, error } = useAdminData();
  const [tab, setTab] = useState('overview');

  // Sekme kayıt haritası (OCP - yeni sekme için mevcut koda dokunmak gerekmez)
  const tabRegistry = {
    overview: { label: t('admin.overview'), icon: <BarChart3 className="w-4 h-4" />, content: stats && <OverviewTab stats={stats} /> },
    products: { label: t('admin.products'), icon: <Package className="w-4 h-4" />,   content: <ProductsTab products={products} /> },
    orders:   { label: t('admin.orders'),   icon: <ShoppingCart className="w-4 h-4" />, content: <OrdersTab orders={orders} /> },
    users:    { label: t('admin.users'),    icon: <Users className="w-4 h-4" />,     content: <UsersTab users={users} /> },
  };

  const tabs = Object.entries(tabRegistry).map(([key, val]) => ({ key, label: val.label, icon: val.icon }));

  return (
    <div className="min-h-screen bg-[#FAFAF7]">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="font-serif text-3xl text-[#2C2C2C] mb-8">{t('nav.admin')}</h1>

        <TabRegistry tabs={tabs} activeTab={tab} onChange={setTab} />

        {/* 5.2: Anlamlı hata gösterimi */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 mb-6" role="alert">
            {error}
          </div>
        )}

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-2 border-[#8B7355] border-t-transparent rounded-full animate-spin" aria-label="Yükleniyor" />
          </div>
        ) : (
          <div>{tabRegistry[tab]?.content}</div>
        )}
      </div>
      <Footer />
    </div>
  );
}
