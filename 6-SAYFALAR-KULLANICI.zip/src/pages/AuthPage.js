/**
 * AuthPage — Güvenli Versiyon
 *
 * S-06: Google OAuth URL env değişkenine taşındı (REACT_APP_GOOGLE_AUTH_URL).
 * S-07: Güçlü parola politikası (min 8 karakter, büyük harf, rakam, özel karakter).
 * S-05: Hata mesajları normalize edilmiş; ham backend hataları gösterilmiyor.
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth, validatePassword } from '../contexts/AuthContext';
import { toast } from 'sonner';
import { Eye, EyeOff, ArrowRight } from 'lucide-react';
import { LoadingSpinner } from '../components/ui-custom/LoadingSpinner';

// S-06: Hardcoded URL env değişkenine alındı
const GOOGLE_AUTH_URL = process.env.REACT_APP_GOOGLE_AUTH_URL;

export default function AuthPage() {
  const { t } = useLanguage();
  const { user, login, register } = useAuth();
  const navigate = useNavigate();
  const [isLogin, setIsLogin] = useState(true);
  const [form, setForm] = useState({ name: '', email: '', password: '', phone: '' });
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [passwordStrength, setPasswordStrength] = useState([]);

  useEffect(() => { if (user) navigate('/'); }, [user, navigate]);

  // S-07: Parola gücü geri bildirimi
  const checkPasswordStrength = (pwd) => {
    const checks = [
      { label: 'En az 8 karakter',   ok: pwd.length >= 8 },
      { label: 'Büyük harf',         ok: /[A-Z]/.test(pwd) },
      { label: 'Rakam',              ok: /[0-9]/.test(pwd) },
      { label: 'Özel karakter',      ok: /[^A-Za-z0-9]/.test(pwd) },
    ];
    setPasswordStrength(checks);
  };

  const validate = () => {
    const e = {};
    if (!isLogin && !form.name.trim()) e.name = 'Ad soyad gerekli';
    if (!form.email.trim()) e.email = 'E-posta gerekli';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Geçerli bir e-posta girin';
    if (!form.password) e.password = 'Şifre gerekli';
    else if (!isLogin) {
      try { validatePassword(form.password); }
      catch (err) { e.password = err.message; }
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      if (isLogin) {
        await login(form.email, form.password);
      } else {
        await register(form.name, form.email, form.password, form.phone);
      }
      navigate('/');
    } catch (err) {
      // S-05: normalizeError'dan gelen güvenli mesaj gösterilir
      toast.error(err.message || t('common.error'));
    } finally {
      setLoading(false);
    }
  };

  // S-06: env değişkeninden URL — fallback yoksa butonu devre dışı bırak
  const googleLogin = () => {
    if (!GOOGLE_AUTH_URL) {
      toast.error('Google ile giriş şu an kullanılamıyor.');
      return;
    }
    const redirectUrl = encodeURIComponent(window.location.origin + '/auth/callback');
    window.location.href = `${GOOGLE_AUTH_URL}?redirect_url=${redirectUrl}`;
  };

  const update = (field, val) => {
    setForm(f => ({ ...f, [field]: val }));
    if (field === 'password' && !isLogin) checkPasswordStrength(val);
    if (errors[field]) setErrors(e => ({ ...e, [field]: undefined }));
  };

  const switchMode = (toLogin) => {
    setIsLogin(toLogin);
    setErrors({});
    setPasswordStrength([]);
  };

  return (
    <div className="min-h-screen bg-[#F8F5F0] flex flex-col">
      <nav className="border-b border-[#E0D8CC] bg-white/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <a href="/" className="font-serif text-[22px] tracking-[0.18em] text-[#2C2C2C]">ANTICCA</a>
          <a href="/" className="text-[12px] text-[#7A7A7A] hover:text-[#8B7355] transition-colors">← Ana Sayfa</a>
        </div>
      </nav>

      <div className="flex-1 flex items-center justify-center px-4 py-16">
        <div className="w-full max-w-[420px]">
          <div className="text-center mb-10">
            <h1 className="font-serif text-[32px] text-[#2C2C2C] mb-2">{t('auth.welcome')}</h1>
            <p className="text-[14px] text-[#7A7A7A]">{t('auth.joinText')}</p>
          </div>

          <div className="flex mb-8 border border-[#E0D8CC] bg-white">
            <button
              onClick={() => switchMode(true)}
              className={`flex-1 py-3 text-[12px] font-semibold uppercase tracking-[0.1em] transition-colors ${isLogin ? 'bg-[#8B7355] text-white' : 'text-[#7A7A7A] hover:text-[#4A4A4A]'}`}
            >
              {t('auth.signIn')}
            </button>
            <button
              onClick={() => switchMode(false)}
              className={`flex-1 py-3 text-[12px] font-semibold uppercase tracking-[0.1em] transition-colors ${!isLogin ? 'bg-[#8B7355] text-white' : 'text-[#7A7A7A] hover:text-[#4A4A4A]'}`}
            >
              {t('auth.signUp')}
            </button>
          </div>

          <div className="bg-white border border-[#E0D8CC] p-8 shadow-[0_4px_20px_rgba(44,44,44,0.05)]">
            <button
              onClick={googleLogin}
              type="button"
              disabled={!GOOGLE_AUTH_URL}
              className="w-full flex items-center justify-center gap-3 px-4 py-3 border border-[#E0D8CC] text-[13px] text-[#4A4A4A] hover:bg-[#F8F5F0] hover:border-[#8B7355]/40 transition-all duration-200 mb-6 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <svg className="w-[18px] h-[18px] shrink-0" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              {t('auth.google')}
            </button>

            <div className="flex items-center gap-3 mb-6" role="separator">
              <div className="flex-1 h-px bg-[#E0D8CC]" />
              <span className="text-[11px] text-[#7A7A7A] font-medium uppercase tracking-wider">{t('auth.or')}</span>
              <div className="flex-1 h-px bg-[#E0D8CC]" />
            </div>

            <form onSubmit={handleSubmit} noValidate>
              <div className="space-y-4">
                {!isLogin && (
                  <div>
                    <label htmlFor="auth-name" className="label-base">{t('auth.name')}</label>
                    <input
                      id="auth-name"
                      type="text"
                      value={form.name}
                      onChange={e => update('name', e.target.value)}
                      autoComplete="name"
                      required={!isLogin}
                      aria-invalid={!!errors.name}
                      aria-describedby={errors.name ? 'name-error' : undefined}
                      className={`input-base ${errors.name ? 'border-red-400' : ''}`}
                    />
                    {errors.name && <p id="name-error" className="text-[11px] text-red-500 mt-1" role="alert">{errors.name}</p>}
                  </div>
                )}

                <div>
                  <label htmlFor="auth-email" className="label-base">{t('auth.email')}</label>
                  <input
                    id="auth-email"
                    type="email"
                    value={form.email}
                    onChange={e => update('email', e.target.value)}
                    autoComplete="email"
                    required
                    aria-invalid={!!errors.email}
                    aria-describedby={errors.email ? 'email-error' : undefined}
                    className={`input-base ${errors.email ? 'border-red-400' : ''}`}
                  />
                  {errors.email && <p id="email-error" className="text-[11px] text-red-500 mt-1" role="alert">{errors.email}</p>}
                </div>

                <div>
                  <label htmlFor="auth-password" className="label-base">{t('auth.password')}</label>
                  <div className="relative">
                    <input
                      id="auth-password"
                      type={showPassword ? 'text' : 'password'}
                      value={form.password}
                      onChange={e => update('password', e.target.value)}
                      autoComplete={isLogin ? 'current-password' : 'new-password'}
                      required
                      aria-invalid={!!errors.password}
                      aria-describedby={errors.password ? 'password-error' : 'password-hint'}
                      className={`input-base pr-10 ${errors.password ? 'border-red-400' : ''}`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(v => !v)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#7A7A7A] hover:text-[#4A4A4A] transition-colors"
                      aria-label={showPassword ? 'Şifreyi gizle' : 'Şifreyi göster'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {errors.password && <p id="password-error" className="text-[11px] text-red-500 mt-1" role="alert">{errors.password}</p>}

                  {/* S-07: Parola gücü göstergesi (kayıt ekranında) */}
                  {!isLogin && form.password && (
                    <div id="password-hint" className="mt-2 space-y-1" aria-live="polite">
                      {passwordStrength.map((check, i) => (
                        <p key={i} className={`text-[11px] flex items-center gap-1 ${check.ok ? 'text-green-600' : 'text-[#7A7A7A]'}`}>
                          <span aria-hidden="true">{check.ok ? '✓' : '○'}</span>
                          {check.label}
                        </p>
                      ))}
                    </div>
                  )}
                </div>

                {!isLogin && (
                  <div>
                    <label htmlFor="auth-phone" className="label-base">
                      {t('auth.phone')}{' '}
                      <span className="text-[#7A7A7A] normal-case tracking-normal">(opsiyonel)</span>
                    </label>
                    <input
                      id="auth-phone"
                      type="tel"
                      value={form.phone}
                      onChange={e => update('phone', e.target.value)}
                      autoComplete="tel"
                      className="input-base"
                    />
                  </div>
                )}
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn-primary w-full mt-6"
                aria-label={isLogin ? t('auth.signIn') : t('auth.signUp')}
              >
                {loading ? (
                  <LoadingSpinner size="sm" />
                ) : (
                  <>{isLogin ? t('auth.signIn') : t('auth.signUp')}<ArrowRight className="w-4 h-4" aria-hidden="true" /></>
                )}
              </button>
            </form>
          </div>

          <p className="text-center text-[12px] text-[#7A7A7A] mt-5">
            {isLogin ? t('auth.noAccount') : t('auth.hasAccount')}{' '}
            <button
              onClick={() => switchMode(!isLogin)}
              className="text-[#8B7355] font-medium hover:underline"
            >
              {isLogin ? t('auth.signUp') : t('auth.signIn')}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
