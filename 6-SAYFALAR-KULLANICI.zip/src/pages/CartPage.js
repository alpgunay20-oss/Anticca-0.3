import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { Trash2, ShoppingBag, ArrowRight, Lock } from 'lucide-react';
import { LoadingSpinner } from '../components/ui-custom/LoadingSpinner';

export default function CartPage() {
  const { t, tObj } = useLanguage();
  const { api } = useAuth();
  const { refreshCart } = useCart();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [removing, setRemoving] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api().get('/api/cart');
      setItems(res.data.items || []);
    } catch (err) { if (process.env.NODE_ENV !== "production") console.warn("[Cart]", err.message); }
    setLoading(false);
  }, [api]);

  useEffect(() => { load(); }, [load]);

  const removeItem = async (productId) => {
    setRemoving(productId);
    try {
      await api().delete(`/api/cart/${productId}`);
      setItems(prev => prev.filter(i => i.product_id !== productId));
      refreshCart();
    } catch (err) { if (process.env.NODE_ENV !== "production") console.warn("[Cart]", err.message); }
    setRemoving(null);
  };

  const total = items.reduce((sum, item) => sum + (item.product?.price || 0) * (item.quantity || 1), 0);

  return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />

      <div className="bg-[#F2EDE4] border-b border-[#E0D8CC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <p className="section-eyebrow">ANTICCA</p>
          <h1 className="font-serif text-[32px] lg:text-[40px] text-[#2C2C2C]">{t('cart.title')}</h1>
          <div className="divider-bronze mt-3" />
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {loading ? (
          <div className="flex justify-center py-20">
            <LoadingSpinner size="lg" />
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-24">
            <div className="inline-flex items-center justify-center w-16 h-16 border border-[#E0D8CC] bg-white mb-6">
              <ShoppingBag className="w-7 h-7 text-[#D4CCBF]" aria-hidden="true" />
            </div>
            <p className="font-serif text-[20px] text-[#2C2C2C] mb-2">{t('cart.empty')}</p>
            <p className="text-[13px] text-[#7A7A7A] mb-8">Sepetinize ürün ekleyerek alışverişe başlayın.</p>
            <Link to="/direkt-satis" className="btn-primary inline-flex">
              {t('cart.continueShopping')}
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Items */}
            <div className="lg:col-span-2 space-y-3">
              {items.map(item => (
                <div
                  key={item.cart_item_id}
                  className="bg-white border border-[#E0D8CC] p-4 flex items-center gap-4 transition-opacity duration-200"
                  style={{ opacity: removing === item.product_id ? 0.5 : 1 }}
                >
                  <Link
                    to={`/urun/${item.product_id}`}
                    className="shrink-0 border border-[#E0D8CC] overflow-hidden"
                    tabIndex={removing === item.product_id ? -1 : 0}
                  >
                    <img
                      src={item.product?.images?.[0] || ''}
                      alt={tObj(item.product?.title) || ''}
                      className="w-[80px] h-[80px] object-cover"
                      loading="lazy"
                    />
                  </Link>
                  <div className="flex-1 min-w-0">
                    <Link
                      to={`/urun/${item.product_id}`}
                      className="font-serif text-[15px] text-[#2C2C2C] hover:text-[#8B7355] transition-colors line-clamp-2 leading-snug"
                    >
                      {tObj(item.product?.title)}
                    </Link>
                    <p className="text-[11px] text-[#7A7A7A] mt-1 uppercase tracking-wider">
                      {t(`categories.${item.product?.category}`) || item.product?.category}
                    </p>
                    <p className="font-mono-data text-[14px] text-[#8B7355] mt-2">
                      ${item.product?.price?.toLocaleString('en-US')}
                    </p>
                  </div>
                  <button
                    onClick={() => removeItem(item.product_id)}
                    disabled={removing === item.product_id}
                    className="p-2 text-[#7A7A7A] hover:text-red-500 hover:bg-red-50 transition-colors disabled:opacity-50 shrink-0"
                    aria-label={`${tObj(item.product?.title)} öğesini kaldır`}
                  >
                    {removing === item.product_id ? (
                      <LoadingSpinner size="sm" />
                    ) : (
                      <Trash2 className="w-4 h-4" aria-hidden="true" />
                    )}
                  </button>
                </div>
              ))}
            </div>

            {/* Summary */}
            <div className="lg:col-span-1">
              <div className="bg-white border border-[#E0D8CC] p-6 sticky top-24">
                <h2 className="font-serif text-[18px] text-[#2C2C2C] mb-5">Sipariş Özeti</h2>

                <div className="space-y-3 pb-5 mb-5 border-b border-[#F0EBE3]">
                  <div className="flex justify-between text-[13px]">
                    <span className="text-[#7A7A7A]">Alt toplam</span>
                    <span className="font-mono-data">${total.toLocaleString('en-US')}</span>
                  </div>
                  <div className="flex justify-between text-[13px]">
                    <span className="text-[#7A7A7A]">Kargo</span>
                    <span className="text-[#8B7355] font-medium text-[12px]">Hesaplanacak</span>
                  </div>
                </div>

                <div className="flex justify-between mb-6">
                  <span className="text-[13px] font-semibold text-[#2C2C2C]">{t('cart.total')}</span>
                  <span className="font-mono-data text-[22px] text-[#2C2C2C]">${total.toLocaleString('en-US')}</span>
                </div>

                <Link to="/odeme" className="btn-primary w-full flex justify-center">
                  {t('cart.checkout')}
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </Link>

                <div className="flex items-center gap-2 mt-4 text-[11px] text-[#7A7A7A] justify-center">
                  <Lock className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  <span>256-bit SSL ile güvenli ödeme</span>
                </div>

                <Link
                  to="/direkt-satis"
                  className="block text-center mt-4 text-[12px] text-[#8B7355] hover:underline"
                >
                  {t('cart.continueShopping')}
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
