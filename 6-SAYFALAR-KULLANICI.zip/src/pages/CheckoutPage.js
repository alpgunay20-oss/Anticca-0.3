import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';
import { CheckCircle, CreditCard, Building } from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

export function CheckoutSuccess() {
  const { t } = useLanguage();
  const { api } = useAuth();
  const { refreshCart } = useCart();
  const [searchParams] = useSearchParams();
  const [status, setStatus] = useState('checking');

  useEffect(() => {
    const sessionId = searchParams.get('session_id');
    if (!sessionId) { setStatus('error'); return; }
    const check = async () => {
      try {
        const res = await api().get(`/api/payments/status/${sessionId}`);
        if (res.data.payment_status === 'paid') {
          setStatus('success');
          refreshCart();
        } else {
          setStatus('pending');
        }
      } catch (err) { if (process.env.NODE_ENV !== 'production') console.warn("[Checkout]", err.message); setStatus('error'); }
    };
    check();
    const interval = setInterval(check, 3000);
    return () => clearInterval(interval);
  }, [searchParams, api, refreshCart]);

  return (
    <div className="min-h-screen bg-[#FAFAF7]">
      <Header />
      <div className="max-w-md mx-auto px-4 py-20 text-center">
        {status === 'success' ? (
          <>
            <CheckCircle className="w-16 h-16 text-[#8B7355] mx-auto mb-6" />
            <h1 className="font-serif text-3xl text-[#2C2C2C] mb-3">{t('checkout.success')}</h1>
            <p className="text-sm text-[#7A7A7A] mb-8">{t('checkout.successMessage')}</p>
            <Link to="/" className="inline-block px-6 py-3 bg-[#8B7355] text-white text-sm hover:bg-[#A6926E] transition-colors">
              {t('checkout.backToHome')}
            </Link>
          </>
        ) : status === 'error' ? (
          <><p className="text-[#7A7A7A]">{t('common.error')}</p><Link to="/" className="mt-4 inline-block text-[#8B7355]">{t('checkout.backToHome')}</Link></>
        ) : (
          <div className="w-8 h-8 border-2 border-[#8B7355] border-t-transparent rounded-full animate-spin mx-auto" />
        )}
      </div>
      <Footer />
    </div>
  );
}

export default function CheckoutPage() {
  const { t } = useLanguage();
  const { api } = useAuth();
  const navigate = useNavigate();
  const [method, setMethod] = useState('stripe');
  const [processing, setProcessing] = useState(false);
  const [bankDetails, setBankDetails] = useState(null);

  const handleCheckout = async () => {
    setProcessing(true);
    try {
      const res = await api().post('/api/payments/checkout', {
        payment_method: method,
        origin_url: window.location.origin
      });
      if (method === 'stripe' && res.data.url) {
        window.location.href = res.data.url;
      } else if (method === 'bank_transfer') {
        setBankDetails(res.data.bank_details);
      }
    } catch (e) {
      toast.error(e.response?.data?.detail || t('common.error'));
    }
    setProcessing(false);
  };

  return (
    <div className="min-h-screen bg-[#FAFAF7]">
      <Header />
      <div className="max-w-lg mx-auto px-4 py-12">
        <h1 className="font-serif text-3xl text-[#2C2C2C] mb-10">{t('checkout.title')}</h1>

        {bankDetails ? (
          <div className="bg-white border border-[#E0D8CC] p-8">
            <h2 className="font-serif text-xl text-[#2C2C2C] mb-4">{t('checkout.bankTransfer')}</h2>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between"><span className="text-[#7A7A7A]">Banka</span><span className="text-[#2C2C2C]">{bankDetails.bank}</span></div>
              <div className="flex justify-between"><span className="text-[#7A7A7A]">IBAN</span><span className="font-mono-data text-[#2C2C2C]">{bankDetails.iban}</span></div>
              <div className="flex justify-between"><span className="text-[#7A7A7A]">SWIFT</span><span className="font-mono-data text-[#2C2C2C]">{bankDetails.swift}</span></div>
              <div className="flex justify-between"><span className="text-[#7A7A7A]">Referans</span><span className="font-mono-data text-[#2C2C2C]">{bankDetails.reference}</span></div>
            </div>
            <Link to="/" className="block mt-6 text-center py-3 bg-[#8B7355] text-white text-sm hover:bg-[#A6926E] transition-colors">
              {t('checkout.backToHome')}
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            <button
              onClick={() => setMethod('stripe')}
              className={`w-full flex items-center gap-4 p-5 border transition-colors text-left ${method === 'stripe' ? 'border-[#8B7355] bg-[#F5F1EB]' : 'border-[#E0D8CC] bg-white hover:border-[#8B7355]/50'}`}
            >
              <CreditCard className="w-6 h-6 text-[#8B7355]" />
              <div>
                <p className="text-sm font-medium text-[#2C2C2C]">{t('checkout.stripe')}</p>
                <p className="text-xs text-[#7A7A7A]">Visa, Mastercard, Amex</p>
              </div>
            </button>
            <button
              onClick={() => setMethod('bank_transfer')}
              className={`w-full flex items-center gap-4 p-5 border transition-colors text-left ${method === 'bank_transfer' ? 'border-[#8B7355] bg-[#F5F1EB]' : 'border-[#E0D8CC] bg-white hover:border-[#8B7355]/50'}`}
            >
              <Building className="w-6 h-6 text-[#8B7355]" />
              <div>
                <p className="text-sm font-medium text-[#2C2C2C]">{t('checkout.bankTransfer')}</p>
                <p className="text-xs text-[#7A7A7A]">EFT / Havale</p>
              </div>
            </button>

            <button
              onClick={handleCheckout}
              disabled={processing}
              className="w-full py-3 mt-4 bg-[#8B7355] text-white text-sm tracking-wide hover:bg-[#A6926E] transition-colors disabled:opacity-50"
            >
              {processing ? t('checkout.processing') : t('cart.checkout')}
            </button>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
