/**
 * CheckoutSuccessPage — Memory Leak Düzeltmesi
 *
 * S-10 / Perf-4.2: setInterval success durumunda temizlenmiyordu.
 * Düzeltme: intervalRef kullanılarak success/error/unmount anında temizlenir.
 * Ayrıca `cancelled` flag'i ile unmount sonrası state güncellemesi engellenir.
 */
import React, { useState, useEffect, useRef } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { CheckCircle } from 'lucide-react';

export default function CheckoutSuccessPage() {
  const { t } = useLanguage();
  const { api } = useAuth();
  const { refreshCart } = useCart();
  const [searchParams] = useSearchParams();
  const [status, setStatus] = useState('checking'); // 'checking' | 'success' | 'error'
  const intervalRef = useRef(null);

  useEffect(() => {
    const sessionId = searchParams.get('session_id');
    if (!sessionId) { setStatus('error'); return; }

    let cancelled = false;

    const stopPolling = () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };

    const check = async () => {
      try {
        const res = await api().get(`/api/payments/status/${sessionId}`);
        if (cancelled) return;

        if (res.data.payment_status === 'paid') {
          stopPolling(); // S-10: success'te interval temizlendi
          setStatus('success');
          refreshCart();
        } else if (res.data.payment_status === 'failed') {
          stopPolling();
          setStatus('error');
        }
        // 'pending' durumunda polling devam eder
      } catch (err) { if (process.env.NODE_ENV !== 'production') console.warn("[CheckoutSuccess]", err.message);
        if (!cancelled) {
          stopPolling();
          setStatus('error');
        }
      }
    };

    check(); // İlk kontrol hemen
    intervalRef.current = setInterval(check, 3000);

    return () => {
      cancelled = true;
      stopPolling(); // unmount'ta temizle
    };
  }, [searchParams, api, refreshCart]);

  return (
    <div className="min-h-screen bg-[#FAFAF7]">
      <Header />
      <div className="max-w-md mx-auto px-4 py-20 text-center">
        {status === 'success' ? (
          <>
            <CheckCircle className="w-16 h-16 text-[#8B7355] mx-auto mb-6" aria-hidden="true" />
            <h1 className="font-serif text-3xl text-[#2C2C2C] mb-3">{t('checkout.success')}</h1>
            <p className="text-sm text-[#7A7A7A] mb-8">{t('checkout.successMessage')}</p>
            <Link to="/" className="inline-block px-6 py-3 bg-[#8B7355] text-white text-sm hover:bg-[#A6926E] transition-colors">
              {t('checkout.backToHome')}
            </Link>
          </>
        ) : status === 'error' ? (
          <>
            <p className="text-[#7A7A7A] mb-4">{t('common.error')}</p>
            <Link to="/" className="inline-block text-[#8B7355] text-sm hover:underline">
              {t('checkout.backToHome')}
            </Link>
          </>
        ) : (
          <div
            className="w-8 h-8 border-2 border-[#8B7355] border-t-transparent rounded-full animate-spin mx-auto"
            role="status"
            aria-label="Ödeme durumu kontrol ediliyor"
          />
        )}
      </div>
      <Footer />
    </div>
  );
}
