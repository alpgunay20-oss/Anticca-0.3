import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import ProductCard from '../components/ProductCard';
import { LoadingSpinner } from '../components/ui-custom/LoadingSpinner';
import { TrendingUp, Package, Heart, User } from 'lucide-react';

export default function DashboardPage() {
  const { t, tObj } = useLanguage();
  const { user, api } = useAuth();
  const [tab, setTab] = useState('bids');
  const [bids, setBids] = useState([]);
  const [orders, setOrders] = useState([]);
  const [wishlist, setWishlist] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const [bidsRes, ordersRes, wishRes] = await Promise.all([
          api().get('/api/my-bids'),
          api().get('/api/orders'),
          api().get('/api/wishlist'),
        ]);
        if (cancelled) return;
        setBids(bidsRes.data.bids || []);
        setOrders(ordersRes.data.orders || []);
        setWishlist(wishRes.data.items || []);
      } catch (err) {
        if (cancelled) return;
        setError(err.message || 'Veriler yüklenirken bir hata oluştu.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    load();
    return () => { cancelled = true; };
  }, [api]);

  const tabs = [
    { key: 'bids',     label: t('dashboard.myBids'),   count: bids.length,    icon: <TrendingUp className="w-4 h-4" /> },
    { key: 'orders',   label: t('dashboard.myOrders'), count: orders.length,  icon: <Package className="w-4 h-4" /> },
    { key: 'wishlist', label: t('dashboard.wishlist'),  count: wishlist.length, icon: <Heart className="w-4 h-4" /> },
  ];

  const statusColors = {
    confirmed: 'bg-green-50 text-green-700 border-green-200',
    pending:   'bg-amber-50 text-amber-700 border-amber-200',
    cancelled: 'bg-red-50 text-red-700 border-red-200',
  };

  return (
    <div className="min-h-screen bg-[#F8F5F0]">
      <Header />

      <div className="bg-[#F2EDE4] border-b border-[#E0D8CC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-[#8B7355]/10 border border-[#E0D8CC] flex items-center justify-center">
              <User className="w-5 h-5 text-[#8B7355]" aria-hidden="true" />
            </div>
            <div>
              <h1 className="font-serif text-[28px] lg:text-[36px] text-[#2C2C2C]">
                {t('nav.dashboard')}
              </h1>
              <p className="text-[13px] text-[#7A7A7A] mt-0.5">{user?.email}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Stats */}
        {!loading && (
          <div className="grid grid-cols-3 gap-4 mb-8">
            {tabs.map(tb => (
              <div key={tb.key} className="bg-white border border-[#E0D8CC] p-4 text-center">
                <p className="font-mono-data text-[28px] text-[#2C2C2C]">{tb.count}</p>
                <p className="text-[11px] text-[#7A7A7A] mt-1 uppercase tracking-wider font-medium">{tb.label}</p>
              </div>
            ))}
          </div>
        )}

        {/* Tabs */}
        <div className="border-b border-[#E0D8CC] mb-8" role="tablist" aria-label="Dashboard sekmeleri">
          <div className="flex gap-0">
            {tabs.map(tb => (
              <button
                key={tb.key}
                role="tab"
                aria-selected={tab === tb.key}
                onClick={() => setTab(tb.key)}
                className={`flex items-center gap-2 px-5 pb-3 pt-1 text-[13px] font-medium transition-colors border-b-2 ${
                  tab === tb.key
                    ? 'text-[#8B7355] border-[#8B7355]'
                    : 'text-[#7A7A7A] hover:text-[#4A4A4A] border-transparent'
                }`}
              >
                {tb.icon}
                <span>{tb.label}</span>
                <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-semibold ${
                  tab === tb.key ? 'bg-[#8B7355]/10 text-[#8B7355]' : 'bg-[#F0EBE3] text-[#7A7A7A]'
                }`}>
                  {tb.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 mb-6" role="alert">
            {error}
          </div>
        )}

        {loading ? (
          <div className="flex justify-center py-20"><LoadingSpinner size="lg" /></div>
        ) : (
          <div role="tabpanel" className="animate-fadeIn">
            {/* Bids */}
            {tab === 'bids' && (
              bids.length === 0 ? (
                <div className="text-center py-16">
                  <TrendingUp className="w-8 h-8 text-[#D4CCBF] mx-auto mb-3" aria-hidden="true" />
                  <p className="text-[#7A7A7A]">{t('dashboard.noBids')}</p>
                  <Link to="/muzayedeler" className="mt-3 inline-block text-[#8B7355] text-[13px] hover:underline">
                    Müzayedelere göz at
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  {bids.map(bid => (
                    <div key={bid.bid_id} className="bg-white border border-[#E0D8CC] p-4 flex items-center gap-4 hover:border-[#8B7355]/20 transition-colors">
                      {bid.product?.images?.[0] && (
                        <Link to={`/urun/${bid.product_id}`} className="shrink-0 border border-[#E0D8CC]">
                          <img src={bid.product.images[0]} alt="" className="w-16 h-16 object-cover" loading="lazy" />
                        </Link>
                      )}
                      <div className="flex-1 min-w-0">
                        <Link
                          to={`/urun/${bid.product_id}`}
                          className="font-serif text-[15px] text-[#2C2C2C] hover:text-[#8B7355] line-clamp-1"
                        >
                          {tObj(bid.product?.title)}
                        </Link>
                        <p className="text-[11px] text-[#7A7A7A] mt-1">
                          {new Date(bid.created_at).toLocaleString('tr-TR')}
                        </p>
                      </div>
                      <p className="font-mono-data text-[18px] text-[#2C2C2C] shrink-0">
                        ${bid.amount?.toLocaleString()}
                      </p>
                    </div>
                  ))}
                </div>
              )
            )}

            {/* Orders */}
            {tab === 'orders' && (
              orders.length === 0 ? (
                <div className="text-center py-16">
                  <Package className="w-8 h-8 text-[#D4CCBF] mx-auto mb-3" aria-hidden="true" />
                  <p className="text-[#7A7A7A]">{t('dashboard.noOrders')}</p>
                  <Link to="/direkt-satis" className="mt-3 inline-block text-[#8B7355] text-[13px] hover:underline">
                    Alışverişe başla
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  {orders.map(order => (
                    <div key={order.order_id} className="bg-white border border-[#E0D8CC] p-5 hover:border-[#8B7355]/20 transition-colors">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="text-[10px] font-mono-data text-[#7A7A7A] mb-1 tracking-wider">
                            #{order.order_id}
                          </p>
                          <p className="text-[11px] text-[#7A7A7A]">
                            {new Date(order.created_at).toLocaleString('tr-TR')}
                          </p>
                        </div>
                        <span className={`text-[9px] font-semibold uppercase tracking-wider px-2.5 py-1 border ${statusColors[order.status] || 'bg-[#F5F1EB] text-[#8B7355] border-[#E0D8CC]'}`}>
                          {order.status}
                        </span>
                      </div>
                      <p className="font-mono-data text-[22px] text-[#2C2C2C]">${order.total?.toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              )
            )}

            {/* Wishlist */}
            {tab === 'wishlist' && (
              wishlist.length === 0 ? (
                <div className="text-center py-16">
                  <Heart className="w-8 h-8 text-[#D4CCBF] mx-auto mb-3" aria-hidden="true" />
                  <p className="text-[#7A7A7A]">{t('dashboard.noWishlist')}</p>
                  <Link to="/direkt-satis" className="mt-3 inline-block text-[#8B7355] text-[13px] hover:underline">
                    Ürün keşfet
                  </Link>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                  {wishlist.map(item => (
                    <ProductCard key={item.product_id} product={item.product} />
                  ))}
                </div>
              )
            )}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
