import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { apiClient } from '../lib/apiClient';
import { ArrowRight, Mail, MapPin, Send } from 'lucide-react';


export default function Footer() {
  const { t, language } = useLanguage();
  const [email, setEmail] = useState('');
  const [subStatus, setSubStatus] = useState(null); // null | 'success' | 'error'
  const [subLoading, setSubLoading] = useState(false);

  const handleSubscribe = async (e) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubLoading(true);
    try {
      await apiClient.post('/api/newsletter', { email, language });
      setSubStatus('success');
      setEmail('');
    } catch (err) { if (process.env.NODE_ENV !== 'production') console.warn("[Footer]", err.message);
      setSubStatus('error');
    }
    setSubLoading(false);
    setTimeout(() => setSubStatus(null), 4000);
  };

  return (
    <footer className="bg-[#1E1E1E] text-[#C8BFB2]" role="contentinfo">
      {/* Top stripe */}
      <div className="h-px bg-gradient-to-r from-transparent via-[#8B7355]/60 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12">

          {/* Brand — spans 4 cols */}
          <div className="lg:col-span-4">
            <Link to="/" aria-label="ANTICCA Ana Sayfa">
              <h3 className="font-serif text-[26px] text-white tracking-[0.18em] mb-1">ANTICCA</h3>
              <p className="text-[9px] tracking-[0.3em] text-[#8B7355] uppercase mb-5">Premium Collectibles</p>
            </Link>
            <div className="h-px w-10 bg-[#8B7355]/60 mb-5" />
            <p className="text-[13px] leading-[1.8] text-[#9A9088] max-w-xs">
              {t('footer.description')}
            </p>
            <div className="flex items-center gap-2 mt-5 text-[12px] text-[#7A7A7A]">
              <MapPin className="w-3.5 h-3.5 shrink-0 text-[#8B7355]" aria-hidden="true" />
              <span>Istanbul, Türkiye</span>
            </div>
          </div>

          {/* Quick Links — 2 cols */}
          <div className="lg:col-span-2">
            <h4 className="text-[10px] uppercase tracking-[0.22em] text-[#A6926E] font-semibold mb-5">
              {t('footer.quickLinks')}
            </h4>
            <nav aria-label="Footer Navigasyon" className="space-y-3">
              {[
                { to: '/muzayedeler', label: t('nav.auctions') },
                { to: '/direkt-satis', label: t('nav.directSales') },
                { to: '/magazalar', label: t('nav.stores') },
                { to: '/makaleler', label: t('nav.articles') },
                { to: '/hakkimizda', label: t('nav.about') },
              ].map(link => (
                <Link
                  key={link.to}
                  to={link.to}
                  className="flex items-center gap-1.5 text-[13px] text-[#9A9088] hover:text-white transition-colors group"
                >
                  <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all duration-200 text-[#8B7355]" aria-hidden="true" />
                  {link.label}
                </Link>
              ))}
            </nav>
          </div>

          {/* Legal — 2 cols */}
          <div className="lg:col-span-2">
            <h4 className="text-[10px] uppercase tracking-[0.22em] text-[#A6926E] font-semibold mb-5">
              {t('footer.legal')}
            </h4>
            <nav aria-label="Yasal Bağlantılar" className="space-y-3">
              {[
                { to: '/sss', label: t('nav.faq') },
                { to: '/gizlilik', label: t('nav.privacy') },
                { to: '/komisyon-politikasi', label: t('nav.commission') },
              ].map(link => (
                <Link
                  key={link.to}
                  to={link.to}
                  className="flex items-center gap-1.5 text-[13px] text-[#9A9088] hover:text-white transition-colors group"
                >
                  <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 -translate-x-1 group-hover:translate-x-0 transition-all duration-200 text-[#8B7355]" aria-hidden="true" />
                  {link.label}
                </Link>
              ))}
            </nav>
          </div>

          {/* Newsletter — 4 cols */}
          <div className="lg:col-span-4">
            <h4 className="text-[10px] uppercase tracking-[0.22em] text-[#A6926E] font-semibold mb-5">
              {t('footer.newsletter')}
            </h4>
            <div className="flex items-start gap-3 mb-4">
              <Mail className="w-4 h-4 text-[#8B7355] shrink-0 mt-0.5" aria-hidden="true" />
              <p className="text-[13px] text-[#9A9088] leading-relaxed">{t('footer.newsletterText')}</p>
            </div>
            <form onSubmit={handleSubscribe} className="relative" aria-label="Bülten Aboneliği">
              <label htmlFor="footer-email" className="sr-only">E-posta Adresi</label>
              <input
                id="footer-email"
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder={t('auth.email')}
                required
                className="w-full bg-[#2A2A2A] border border-[#3A3A3A] px-4 py-3 pr-12 text-[13px] text-white placeholder-[#666] focus:outline-none focus:border-[#8B7355] transition-colors"
              />
              <button
                type="submit"
                disabled={subLoading}
                className="absolute right-0 top-0 bottom-0 px-4 text-[#8B7355] hover:text-[#A6926E] transition-colors disabled:opacity-50"
                aria-label="Abone Ol"
              >
                <Send className="w-4 h-4" aria-hidden="true" />
              </button>
            </form>
            {subStatus === 'success' && (
              <p className="text-[12px] mt-2 text-[#8B7355] animate-fadeIn" role="status">
                ✓ Başarıyla abone oldunuz.
              </p>
            )}
            {subStatus === 'error' && (
              <p className="text-[12px] mt-2 text-red-400 animate-fadeIn" role="alert">
                {t('common.error')}
              </p>
            )}
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-14 pt-7 border-t border-[#2E2E2E] flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[12px] text-[#555]">
            &copy; {new Date().getFullYear()} ANTICCA. {t('footer.allRights')}
          </p>
          <div className="flex items-center gap-6 text-[12px] text-[#555]">
            <Link to="/gizlilik" className="hover:text-[#9A9088] transition-colors">
              {t('nav.privacy')}
            </Link>
            <span className="w-px h-3 bg-[#3A3A3A]" aria-hidden="true" />
            <Link to="/komisyon-politikasi" className="hover:text-[#9A9088] transition-colors">
              {t('nav.commission')}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
