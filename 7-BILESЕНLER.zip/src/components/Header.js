import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { Menu, X, ShoppingBag, User, ChevronDown, Globe, LogOut, LayoutDashboard, Shield } from 'lucide-react';

const LANGS = [
  { code: 'tr', label: 'Türkçe', short: 'TR' },
  { code: 'en', label: 'English', short: 'EN' },
  { code: 'it', label: 'Italiano', short: 'IT' },
];

function Dropdown({ isOpen, children, align = 'right' }) {
  if (!isOpen) return null;
  return (
    <div
      className={`absolute ${align === 'right' ? 'right-0' : 'left-0'} top-full mt-2 bg-white border border-[#E0D8CC] shadow-lg z-50 animate-slideDown`}
      style={{ minWidth: '160px' }}
    >
      {children}
    </div>
  );
}

export default function Header() {
  const { t, language, setLanguage } = useLanguage();
  const { user, logout } = useAuth();
  const { cartCount } = useCart();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const [userOpen, setUserOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const headerRef = useRef(null);

  const navLinks = [
    { to: '/muzayedeler', label: t('nav.auctions') },
    { to: '/direkt-satis', label: t('nav.directSales') },
    { to: '/magazalar', label: t('nav.stores') },
    { to: '/makaleler', label: t('nav.articles') },
    { to: '/hakkimizda', label: t('nav.about') },
  ];

  const isActive = (path) => location.pathname === path;

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handler = (e) => {
      if (headerRef.current && !headerRef.current.contains(e.target)) {
        setLangOpen(false);
        setUserOpen(false);
        setMobileOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileOpen(false);
    setLangOpen(false);
    setUserOpen(false);
  }, [location.pathname]);

  const currentLang = LANGS.find(l => l.code === language) || LANGS[0];

  return (
    <header
      ref={headerRef}
      className={`sticky top-0 z-50 glass-header transition-shadow duration-300 ${scrolled ? 'shadow-[0_4px_20px_rgba(44,44,44,0.06)]' : ''}`}
      role="banner"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-[72px]">

          {/* Logo */}
          <Link
            to="/"
            className="flex items-center gap-3 group"
            aria-label="ANTICCA — Ana Sayfa"
          >
            <div className="flex flex-col leading-none">
              <span className="font-serif text-[22px] lg:text-[26px] tracking-[0.18em] text-[#2C2C2C] font-medium group-hover:text-[#8B7355] transition-colors duration-300">
                ANTICCA
              </span>
              <span className="text-[8px] tracking-[0.3em] text-[#8B7355] uppercase font-[DM_Sans] hidden lg:block" style={{letterSpacing:'0.3em'}}>
                Premium Collectibles
              </span>
            </div>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-7" role="navigation" aria-label="Ana Menü">
            {navLinks.map(link => (
              <Link
                key={link.to}
                to={link.to}
                className={`text-[13px] tracking-wide transition-colors duration-200 relative py-1 ${
                  isActive(link.to)
                    ? 'text-[#8B7355] font-medium'
                    : 'text-[#4A4A4A] hover:text-[#8B7355]'
                }`}
              >
                {link.label}
                {isActive(link.to) && (
                  <span className="absolute bottom-0 left-0 w-full h-px bg-[#8B7355]" />
                )}
              </Link>
            ))}
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-1 sm:gap-2">

            {/* Language Switcher */}
            <div className="relative">
              <button
                onClick={() => { setLangOpen(v => !v); setUserOpen(false); }}
                className="flex items-center gap-1.5 px-2.5 py-2 text-[13px] text-[#4A4A4A] hover:text-[#8B7355] transition-colors rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#8B7355]"
                aria-label="Dil Seçimi"
                aria-expanded={langOpen}
                aria-haspopup="listbox"
              >
                <Globe className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span className="hidden sm:inline font-medium">{currentLang.short}</span>
                <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${langOpen ? 'rotate-180' : ''}`} aria-hidden="true" />
              </button>
              <Dropdown isOpen={langOpen}>
                {LANGS.map(l => (
                  <button
                    key={l.code}
                    role="option"
                    aria-selected={language === l.code}
                    onClick={() => { setLanguage(l.code); setLangOpen(false); }}
                    className={`flex items-center justify-between w-full px-4 py-2.5 text-[13px] transition-colors ${
                      language === l.code
                        ? 'bg-[#F5F1EB] text-[#8B7355] font-medium'
                        : 'text-[#4A4A4A] hover:bg-[#F8F5F0]'
                    }`}
                  >
                    <span>{l.label}</span>
                    <span className="text-[10px] text-[#7A7A7A]">{l.short}</span>
                  </button>
                ))}
              </Dropdown>
            </div>

            {/* Cart */}
            <Link
              to="/sepet"
              className="relative p-2 text-[#4A4A4A] hover:text-[#8B7355] transition-colors"
              aria-label={`Sepet${cartCount > 0 ? ` (${cartCount} ürün)` : ''}`}
            >
              <ShoppingBag className="w-[19px] h-[19px]" aria-hidden="true" />
              {cartCount > 0 && (
                <span
                  className="absolute -top-0.5 -right-0.5 w-[18px] h-[18px] bg-[#8B7355] text-white text-[9px] font-bold flex items-center justify-center rounded-full leading-none animate-zoomIn"
                  aria-hidden="true"
                >
                  {cartCount > 9 ? '9+' : cartCount}
                </span>
              )}
            </Link>

            {/* User Menu */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => { setUserOpen(v => !v); setLangOpen(false); }}
                  className="flex items-center gap-1.5 px-2.5 py-2 text-[13px] text-[#4A4A4A] hover:text-[#8B7355] transition-colors"
                  aria-expanded={userOpen}
                  aria-haspopup="menu"
                  aria-label="Kullanıcı Menüsü"
                >
                  <div className="w-7 h-7 rounded-full bg-[#F5F1EB] border border-[#E0D8CC] flex items-center justify-center shrink-0">
                    <span className="text-[11px] font-semibold text-[#8B7355]">
                      {user.name?.[0]?.toUpperCase() || 'U'}
                    </span>
                  </div>
                  <span className="hidden sm:inline max-w-[90px] truncate font-medium">
                    {user.name?.split(' ')[0]}
                  </span>
                  <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${userOpen ? 'rotate-180' : ''}`} aria-hidden="true" />
                </button>
                <Dropdown isOpen={userOpen}>
                  <div className="px-4 py-3 border-b border-[#F5F1EB]">
                    <p className="text-[11px] font-medium text-[#2C2C2C] truncate">{user.name}</p>
                    <p className="text-[11px] text-[#7A7A7A] truncate mt-0.5">{user.email}</p>
                  </div>
                  <Link
                    to="/hesabim"
                    onClick={() => setUserOpen(false)}
                    className="flex items-center gap-2.5 px-4 py-2.5 text-[13px] text-[#4A4A4A] hover:bg-[#F8F5F0] hover:text-[#8B7355] transition-colors"
                  >
                    <LayoutDashboard className="w-3.5 h-3.5" aria-hidden="true" />
                    {t('nav.dashboard')}
                  </Link>
                  {user.role === 'admin' && (
                    <Link
                      to="/admin"
                      onClick={() => setUserOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2.5 text-[13px] text-[#4A4A4A] hover:bg-[#F8F5F0] hover:text-[#8B7355] transition-colors"
                    >
                      <Shield className="w-3.5 h-3.5" aria-hidden="true" />
                      {t('nav.admin')}
                    </Link>
                  )}
                  <button
                    onClick={() => { logout(); setUserOpen(false); }}
                    className="flex items-center gap-2.5 w-full px-4 py-2.5 text-[13px] text-[#4A4A4A] hover:bg-[#F8F5F0] hover:text-red-600 transition-colors border-t border-[#F0EBE3]"
                  >
                    <LogOut className="w-3.5 h-3.5" aria-hidden="true" />
                    {t('nav.logout')}
                  </button>
                </Dropdown>
              </div>
            ) : (
              <Link
                to="/giris"
                className="hidden sm:flex items-center text-[11px] font-semibold tracking-[0.1em] uppercase px-4 py-2 border border-[#8B7355] text-[#8B7355] hover:bg-[#8B7355] hover:text-white transition-all duration-200 ml-1"
              >
                {t('nav.login')}
              </Link>
            )}

            {/* Mobile Menu Toggle */}
            <button
              className="lg:hidden p-2 text-[#4A4A4A] hover:text-[#8B7355] transition-colors ml-1"
              onClick={() => setMobileOpen(v => !v)}
              aria-label={mobileOpen ? 'Menüyü Kapat' : 'Menüyü Aç'}
              aria-expanded={mobileOpen}
            >
              {mobileOpen ? <X className="w-5 h-5" aria-hidden="true" /> : <Menu className="w-5 h-5" aria-hidden="true" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div
          className="lg:hidden border-t border-[#E0D8CC] bg-white animate-slideDown"
          role="navigation"
          aria-label="Mobil Menü"
        >
          <nav className="px-4 py-4 space-y-0.5">
            {navLinks.map(link => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setMobileOpen(false)}
                className={`flex items-center py-3 text-[14px] border-b border-[#F5F1EB] transition-colors ${
                  isActive(link.to) ? 'text-[#8B7355] font-medium' : 'text-[#4A4A4A] hover:text-[#8B7355]'
                }`}
              >
                {link.label}
              </Link>
            ))}
            <Link to="/sss" onClick={() => setMobileOpen(false)} className="flex items-center py-3 text-[14px] text-[#4A4A4A] hover:text-[#8B7355] border-b border-[#F5F1EB]">
              {t('nav.faq')}
            </Link>
            {!user && (
              <Link
                to="/giris"
                onClick={() => setMobileOpen(false)}
                className="flex justify-center mt-4 py-3 text-[12px] font-semibold uppercase tracking-[0.1em] bg-[#8B7355] text-white hover:bg-[#A6926E] transition-colors"
              >
                {t('nav.login')}
              </Link>
            )}
            {/* Language switcher in mobile */}
            <div className="flex gap-2 pt-4 pb-2">
              {LANGS.map(l => (
                <button
                  key={l.code}
                  onClick={() => { setLanguage(l.code); setMobileOpen(false); }}
                  className={`px-3 py-1.5 text-[12px] font-medium border transition-colors ${
                    language === l.code
                      ? 'border-[#8B7355] bg-[#8B7355] text-white'
                      : 'border-[#E0D8CC] text-[#4A4A4A] hover:border-[#8B7355]'
                  }`}
                >
                  {l.short}
                </button>
              ))}
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
