import React, { useState, useEffect, useCallback, memo } from 'react';
import { Link } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';
import { Clock, Eye, TrendingUp } from 'lucide-react';

function formatTimeLeft(endDate) {
  if (!endDate) return '';
  const diff = new Date(endDate) - Date.now();
  if (diff <= 0) return 'Bitti';
  const d = Math.floor(diff / 86400000);
  const h = Math.floor((diff % 86400000) / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  if (d > 0) return `${d}g ${h}s`;
  if (h > 0) return `${h}s ${m}dk`;
  return `${m}dk ${s}sn`;
}

const FALLBACK_IMG = 'https://images.pexels.com/photos/3004909/pexels-photo-3004909.jpeg?auto=compress&cs=tinysrgb&w=400';

const ProductCard = memo(function ProductCard({ product }) {
  const { tObj, t } = useLanguage();
  const [timeLeft, setTimeLeft] = useState('');
  const [imgError, setImgError] = useState(false);

  const updateTimer = useCallback(() => {
    if (product?.is_auction && product?.auction_end) {
      setTimeLeft(formatTimeLeft(product.auction_end));
    }
  }, [product?.is_auction, product?.auction_end]);

  useEffect(() => {
    if (!product?.is_auction) return;
    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [product?.is_auction, updateTimer]);

  if (!product) return null;

  const title = tObj(product.title) || '';
  const img = (!imgError && product.images?.[0]) ? product.images[0] : FALLBACK_IMG;
  const price = product.is_auction ? (product.current_bid || product.starting_bid || 0) : (product.price || 0);
  const isEnding = product.is_auction && product.auction_end && (new Date(product.auction_end) - Date.now()) < 3600000 && timeLeft !== 'Bitti';

  return (
    <Link
      to={`/urun/${product.product_id}`}
      className="group block"
      aria-label={`${title} — ${product.is_auction ? 'Müzayede' : 'Direkt Satış'}`}
    >
      <article className="card-product overflow-hidden">
        {/* Image */}
        <div className="relative aspect-square overflow-hidden bg-[#F2EDE4]">
          <img
            src={img}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.06] will-change-transform"
            loading="lazy"
            decoding="async"
            onError={() => setImgError(true)}
          />

          {/* Gradient overlay on hover */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            {product.is_auction && (
              <div className="live-badge">
                <span className="live-dot" aria-hidden="true" />
                <span className="text-[9px] uppercase tracking-[0.15em] text-[#8B7355] font-semibold">
                  {t('product.auctionLive')}
                </span>
              </div>
            )}
            {product.featured && !product.is_auction && (
              <div className="bg-[#8B7355] px-2.5 py-1">
                <span className="text-[9px] uppercase tracking-[0.15em] text-white font-medium">
                  {t('sections.featured')}
                </span>
              </div>
            )}
          </div>

          {/* Urgent / ending soon */}
          {isEnding && (
            <div className="absolute top-3 right-3 bg-amber-50 border border-amber-200 px-2 py-1">
              <span className="text-[9px] text-amber-700 font-semibold uppercase tracking-wider">Son Saatler</span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4">
          <p className="text-[9px] uppercase tracking-[0.18em] text-[#7A7A7A] mb-1.5 font-medium">
            {t(`categories.${product.category}`) || product.category}
          </p>
          <h3 className="font-serif text-[15px] text-[#2C2C2C] leading-snug mb-3 line-clamp-2">
            {title}
          </h3>

          <div className="flex items-end justify-between">
            <div>
              <p className="text-[9px] uppercase tracking-[0.15em] text-[#7A7A7A] mb-0.5 font-medium">
                {product.is_auction ? t('product.currentBid') : t('product.price')}
              </p>
              <p className="font-mono-data text-[17px] text-[#2C2C2C] leading-none">
                ${price.toLocaleString('en-US')}
              </p>
            </div>

            <div className="flex flex-col items-end gap-1">
              {product.is_auction && timeLeft && (
                <div className={`flex items-center gap-1 ${isEnding ? 'text-amber-600' : 'text-[#7A7A7A]'}`}>
                  <Clock className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  <span className="text-[11px] font-mono-data tabular-nums">{timeLeft}</span>
                </div>
              )}
              {!product.is_auction && product.view_count > 0 && (
                <div className="flex items-center gap-1 text-[#7A7A7A]">
                  <Eye className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  <span className="text-[11px]">{product.view_count.toLocaleString()}</span>
                </div>
              )}
              {product.is_auction && product.bid_count > 0 && (
                <div className="flex items-center gap-1 text-[#7A7A7A]">
                  <TrendingUp className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  <span className="text-[11px]">{product.bid_count} {t('product.bids')}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </article>
    </Link>
  );
});

export default ProductCard;
