import React from 'react';

export function LoadingSpinner({ size = 'md', className = '' }) {
  const sizes = { sm: 'w-5 h-5', md: 'w-8 h-8', lg: 'w-12 h-12' };
  return (
    <div
      className={`${sizes[size]} border-2 border-[#E0D8CC] border-t-[#8B7355] rounded-full animate-spin ${className}`}
      role="status"
      aria-label="Yükleniyor"
    />
  );
}

export function PageLoader() {
  return (
    <div className="min-h-screen bg-[#F8F5F0] flex flex-col">
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <LoadingSpinner size="lg" className="mx-auto mb-4" />
          <p className="text-[12px] uppercase tracking-[0.2em] text-[#8B7355]">Yükleniyor</p>
        </div>
      </div>
    </div>
  );
}

export function ProductCardSkeleton() {
  return (
    <div className="bg-white border border-[#E0D8CC] overflow-hidden" aria-hidden="true">
      <div className="aspect-square skeleton" />
      <div className="p-4">
        <div className="skeleton h-2.5 w-16 mb-2.5 rounded" />
        <div className="skeleton h-4 w-full mb-1.5 rounded" />
        <div className="skeleton h-4 w-3/4 mb-4 rounded" />
        <div className="flex justify-between">
          <div>
            <div className="skeleton h-2 w-12 mb-1.5 rounded" />
            <div className="skeleton h-5 w-20 rounded" />
          </div>
          <div className="skeleton h-4 w-14 rounded" />
        </div>
      </div>
    </div>
  );
}

export function ProductGridSkeleton({ count = 4 }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {Array.from({ length: count }).map((_, i) => (
        <ProductCardSkeleton key={i} />
      ))}
    </div>
  );
}
