"""
ANTICCA — Centralized Configuration
All settings are sourced strictly from environment variables.
Missing required variables raise a startup error, never fall back to insecure defaults.
"""

import os
import secrets
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).parent.parent.parent
load_dotenv(ROOT_DIR / ".env")


class Settings:
    # ── MongoDB ──────────────────────────────────────────────
    MONGO_URL: str = os.environ["MONGO_URL"]
    DB_NAME: str = os.environ["DB_NAME"]

    # ── Security ─────────────────────────────────────────────
    JWT_SECRET: str = os.environ["JWT_SECRET"]
    JWT_ALGORITHM: str = os.environ.get("JWT_ALGORITHM", "HS256")
    JWT_EXPIRY_DAYS: int = int(os.environ.get("JWT_EXPIRY_DAYS", "7"))

    # ── Payment ───────────────────────────────────────────────
    STRIPE_API_KEY: str = os.environ.get("STRIPE_API_KEY", "")

    # ── LLM ──────────────────────────────────────────────────
    EMERGENT_LLM_KEY: str = os.environ.get("EMERGENT_LLM_KEY", "")

    # ── CORS ─────────────────────────────────────────────────
    CORS_ORIGINS: list[str] = [
        o.strip()
        for o in os.environ.get("CORS_ORIGINS", "http://localhost:3000").split(",")
        if o.strip()
    ]

    # ── App ──────────────────────────────────────────────────
    ENVIRONMENT: str = os.environ.get("ENVIRONMENT", "development")
    LOG_LEVEL: str = os.environ.get("LOG_LEVEL", "INFO")

    # ── Admin Bootstrap ──────────────────────────────────────
    ADMIN_EMAIL: str = os.environ.get("ADMIN_EMAIL", "admin@anticca.com")
    ADMIN_PASSWORD: str = os.environ.get("ADMIN_PASSWORD", "")

    def __post_init__(self) -> None:
        if not self.JWT_SECRET or len(self.JWT_SECRET) < 32:
            raise ValueError(
                "JWT_SECRET must be set and at least 32 characters. "
                "Generate one with: python -c \"import secrets; print(secrets.token_hex(64))\""
            )
        if self.ENVIRONMENT == "production" and not self.ADMIN_PASSWORD:
            raise ValueError("ADMIN_PASSWORD must be set in production.")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    s = Settings()
    s.__post_init__()
    return s


settings = get_settings()
