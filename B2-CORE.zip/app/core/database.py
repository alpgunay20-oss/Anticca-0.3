"""
ANTICCA — Database Connection & Index Management
"""

from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)

_client: AsyncIOMotorClient | None = None


async def connect_db() -> None:
    global _client
    _client = AsyncIOMotorClient(
        settings.MONGO_URL,
        maxPoolSize=50,
        minPoolSize=5,
        serverSelectionTimeoutMS=5000,
    )
    # Confirm connectivity
    await _client.admin.command("ping")
    logger.info("MongoDB connected successfully")
    await ensure_indexes()


async def close_db() -> None:
    global _client
    if _client:
        _client.close()
        logger.info("MongoDB connection closed")


def get_db() -> AsyncIOMotorDatabase:
    if _client is None:
        raise RuntimeError("Database not initialized. Call connect_db() first.")
    return _client[settings.DB_NAME]


async def ensure_indexes() -> None:
    """Create all necessary indexes for performance and data integrity."""
    db = get_db()

    # users
    await db.users.create_index("email", unique=True, background=True)
    await db.users.create_index("user_id", unique=True, background=True)

    # user_sessions
    await db.user_sessions.create_index("session_token", unique=True, background=True)
    await db.user_sessions.create_index("user_id", background=True)
    await db.user_sessions.create_index("expires_at", background=True)

    # products
    await db.products.create_index("product_id", unique=True, background=True)
    await db.products.create_index("category", background=True)
    await db.products.create_index("status", background=True)
    await db.products.create_index("is_auction", background=True)
    await db.products.create_index("featured", background=True)
    await db.products.create_index("store_id", background=True)
    await db.products.create_index("created_at", background=True)
    await db.products.create_index("auction_end", background=True)
    await db.products.create_index(
        [("title.en", "text"), ("title.tr", "text"), ("title.it", "text")],
        background=True,
    )

    # bids
    await db.bids.create_index("bid_id", unique=True, background=True)
    await db.bids.create_index("product_id", background=True)
    await db.bids.create_index("user_id", background=True)
    await db.bids.create_index([("product_id", 1), ("amount", -1)], background=True)

    # orders
    await db.orders.create_index("order_id", unique=True, background=True)
    await db.orders.create_index("user_id", background=True)
    await db.orders.create_index("session_id", background=True)
    await db.orders.create_index("created_at", background=True)

    # payment_transactions
    await db.payment_transactions.create_index("transaction_id", unique=True, background=True)
    await db.payment_transactions.create_index("session_id", background=True)
    await db.payment_transactions.create_index("order_id", background=True)

    # cart_items
    await db.cart_items.create_index(
        [("user_id", 1), ("product_id", 1)], unique=True, background=True
    )

    # watchlist
    await db.watchlist.create_index(
        [("user_id", 1), ("product_id", 1)], unique=True, background=True
    )

    # stores
    await db.stores.create_index("store_id", unique=True, background=True)

    # articles
    await db.articles.create_index("article_id", unique=True, background=True)
    await db.articles.create_index("slug", sparse=True, background=True)
    await db.articles.create_index("published", background=True)

    # newsletter
    await db.newsletter.create_index("email", unique=True, background=True)

    # faq
    await db.faq.create_index("faq_id", unique=True, background=True)
    await db.faq.create_index("order", background=True)

    # categories
    await db.categories.create_index("category_id", unique=True, background=True)

    logger.info("All database indexes ensured")
