"""
ANTICCA — Authentication & Security Utilities
"""

import uuid
import httpx
import bcrypt
import jwt

from datetime import datetime, timezone, timedelta
from typing import Optional

from fastapi import Request, HTTPException

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────
# Password hashing
# ─────────────────────────────────────────────────────────────

def hash_password(password: str) -> str:
    """Hash a plain-text password with bcrypt (work factor 12)."""
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(rounds=12)).decode("utf-8")


def verify_password(password: str, hashed: str) -> bool:
    """Constant-time password verification."""
    try:
        return bcrypt.checkpw(password.encode("utf-8"), hashed.encode("utf-8"))
    except (ValueError, TypeError) as exc:
        logger.debug("Password verification error (likely invalid hash format): %s", exc)
        return False


# ─────────────────────────────────────────────────────────────
# Password strength validation
# ─────────────────────────────────────────────────────────────

def validate_password_strength(password: str) -> None:
    """Raise ValueError if password does not meet minimum security requirements."""
    if len(password) < 8:
        raise ValueError("Password must be at least 8 characters long.")
    if not any(c.isupper() for c in password):
        raise ValueError("Password must contain at least one uppercase letter.")
    if not any(c.islower() for c in password):
        raise ValueError("Password must contain at least one lowercase letter.")
    if not any(c.isdigit() for c in password):
        raise ValueError("Password must contain at least one digit.")


# ─────────────────────────────────────────────────────────────
# JWT
# ─────────────────────────────────────────────────────────────

def create_jwt_token(user_id: str, role: str = "user") -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "user_id": user_id,
        "role": role,
        "exp": now + timedelta(days=settings.JWT_EXPIRY_DAYS),
        "iat": now,
        "jti": uuid.uuid4().hex,  # JWT ID for token revocation capability
    }
    return jwt.encode(payload, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)


def decode_jwt_token(token: str) -> dict:
    """Decode and verify a JWT. Raises jwt.* exceptions on failure."""
    return jwt.decode(
        token,
        settings.JWT_SECRET,
        algorithms=[settings.JWT_ALGORITHM],
        options={"require": ["user_id", "role", "exp", "iat"]},
    )


# ─────────────────────────────────────────────────────────────
# ID generation
# ─────────────────────────────────────────────────────────────

def generate_user_id() -> str:
    return f"user_{uuid.uuid4().hex[:16]}"


# ─────────────────────────────────────────────────────────────
# Session helpers
# ─────────────────────────────────────────────────────────────

def _parse_expiry(expires_at) -> datetime:
    """Normalize session expiry to a timezone-aware datetime."""
    if isinstance(expires_at, str):
        expires_at = datetime.fromisoformat(expires_at)
    if isinstance(expires_at, datetime) and expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    return expires_at


async def _resolve_session_token(token: str, db) -> Optional[dict]:
    """Return the user document for a valid, non-expired session token."""
    session = await db.user_sessions.find_one({"session_token": token}, {"_id": 0})
    if not session:
        return None
    if _parse_expiry(session.get("expires_at")) <= datetime.now(timezone.utc):
        return None
    return await db.users.find_one({"user_id": session["user_id"]}, {"_id": 0})


# ─────────────────────────────────────────────────────────────
# Request-level user resolution
# ─────────────────────────────────────────────────────────────

async def get_current_user(request: Request, db) -> dict:
    """
    Resolve the authenticated user from the request.
    Priority: session cookie → Authorization Bearer (session token or JWT).
    Raises HTTP 401 if not authenticated.
    """
    # 1. Session cookie
    session_token = request.cookies.get("session_token")
    if session_token:
        user = await _resolve_session_token(session_token, db)
        if user:
            return user

    # 2. Authorization header
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        token = auth_header[7:].strip()
        if not token:
            raise HTTPException(status_code=401, detail="Invalid token format.")

        # Try session token first
        user = await _resolve_session_token(token, db)
        if user:
            return user

        # Try JWT
        try:
            payload = decode_jwt_token(token)
            user = await db.users.find_one({"user_id": payload["user_id"]}, {"_id": 0})
            if user:
                return user
        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Token has expired.")
        except jwt.InvalidTokenError as e:
            logger.debug("JWT validation failed: %s", e)

    raise HTTPException(status_code=401, detail="Authentication required.")


async def get_optional_user(request: Request, db) -> Optional[dict]:
    """Return the user if authenticated, or None. Does not raise."""
    try:
        return await get_current_user(request, db)
    except HTTPException:
        return None


def require_admin(user: dict) -> None:
    """Raise HTTP 403 if the user is not an admin."""
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Administrator access required.")


# ─────────────────────────────────────────────────────────────
# OAuth session exchange
# ─────────────────────────────────────────────────────────────

_OAUTH_SESSION_URL = (
    "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data"
)

async def exchange_session_id(session_id: str) -> dict:
    """Exchange an Emergent OAuth session_id for user profile data."""
    async with httpx.AsyncClient(timeout=10.0) as client:
        try:
            resp = await client.get(
                _OAUTH_SESSION_URL,
                headers={"X-Session-ID": session_id},
            )
        except httpx.RequestError as exc:
            logger.error("OAuth session exchange network error: %s", exc)
            raise HTTPException(status_code=503, detail="Authentication service unavailable.")

    if resp.status_code == 401:
        raise HTTPException(status_code=401, detail="Invalid OAuth session.")
    if resp.status_code != 200:
        logger.error("OAuth session exchange failed: HTTP %d", resp.status_code)
        raise HTTPException(status_code=502, detail="OAuth service error.")

    return resp.json()
