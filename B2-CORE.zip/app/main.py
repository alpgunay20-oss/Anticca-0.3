"""
ANTICCA — FastAPI Application Entry Point
"""

from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.config import settings
from app.core.database import connect_db, close_db
from app.core.logging import configure_logging, get_logger
from app.core.exceptions import (
    http_exception_handler,
    validation_exception_handler,
    unhandled_exception_handler,
)
from app.middleware.rate_limit import RateLimitMiddleware
from app.middleware.logging import RequestLoggingMiddleware
from app.services.seed import seed_all
from app.api.v1 import api_router

# Configure structured logging before anything else
configure_logging()
logger = get_logger(__name__)


def create_app() -> FastAPI:
    app = FastAPI(
        title="ANTICCA API",
        description="Backend for the ANTICCA luxury collectibles marketplace.",
        version="2.0.0",
        docs_url="/api/docs" if settings.ENVIRONMENT != "production" else None,
        redoc_url="/api/redoc" if settings.ENVIRONMENT != "production" else None,
        openapi_url="/api/openapi.json" if settings.ENVIRONMENT != "production" else None,
    )

    # ── Middleware (order matters: outermost added last) ─────
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
        allow_headers=["Authorization", "Content-Type", "X-Requested-With"],
        expose_headers=["X-Request-ID"],
    )
    app.add_middleware(RateLimitMiddleware)
    app.add_middleware(RequestLoggingMiddleware)

    # ── Exception handlers ───────────────────────────────────
    app.add_exception_handler(StarletteHTTPException, http_exception_handler)
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    app.add_exception_handler(Exception, unhandled_exception_handler)

    # ── Routers ──────────────────────────────────────────────
    app.include_router(api_router)

    # ── Lifecycle ────────────────────────────────────────────
    @app.on_event("startup")
    async def startup():
        logger.info("Starting ANTICCA API (env=%s)", settings.ENVIRONMENT)
        await connect_db()
        await seed_all()
        logger.info("ANTICCA API ready.")

    @app.on_event("shutdown")
    async def shutdown():
        await close_db()
        logger.info("ANTICCA API shut down.")

    # ── Health check ─────────────────────────────────────────
    @app.get("/health", tags=["Health"])
    async def health():
        return {"status": "ok", "environment": settings.ENVIRONMENT}

    return app


app = create_app()
