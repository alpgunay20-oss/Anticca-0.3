"""
ANTICCA — In-Process Rate Limiter Middleware
Uses a sliding-window counter keyed on client IP.
For multi-process deployments, replace with a Redis-backed solution.
"""

import time
from collections import defaultdict, deque
from threading import Lock

from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware

from app.core.logging import get_logger

logger = get_logger(__name__)

# (window_seconds, max_requests)
RATE_LIMIT_RULES: dict[str, tuple[int, int]] = {
    "/api/auth/login": (60, 10),
    "/api/auth/register": (3600, 5),
    "/api/newsletter": (3600, 3),
    "/api/payments/checkout": (60, 5),
    "default": (60, 120),
}


class SlidingWindowRateLimiter:
    def __init__(self) -> None:
        self._windows: dict[str, deque] = defaultdict(deque)
        self._lock = Lock()

    def is_allowed(self, key: str, window_seconds: int, max_requests: int) -> bool:
        now = time.monotonic()
        cutoff = now - window_seconds
        with self._lock:
            dq = self._windows[key]
            while dq and dq[0] < cutoff:
                dq.popleft()
            if len(dq) >= max_requests:
                return False
            dq.append(now)
            return True


_limiter = SlidingWindowRateLimiter()


def _get_client_ip(request: Request) -> str:
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()
    if request.client:
        return request.client.host
    return "unknown"


class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        client_ip = _get_client_ip(request)

        # Find matching rule (exact, then default)
        rule = RATE_LIMIT_RULES.get(path, RATE_LIMIT_RULES["default"])
        window_seconds, max_requests = rule

        key = f"{client_ip}:{path}"
        if not _limiter.is_allowed(key, window_seconds, max_requests):
            logger.warning("Rate limit exceeded: ip=%s path=%s", client_ip, path)
            raise HTTPException(
                status_code=429,
                detail="Too many requests. Please slow down and try again later.",
            )

        return await call_next(request)
