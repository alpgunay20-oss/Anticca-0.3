"""
ANTICCA — Pydantic Request/Response Models
All inputs are strictly validated; no loose types.
"""

import re
from typing import Optional
from pydantic import BaseModel, Field, ConfigDict, field_validator, EmailStr

EMAIL_RE = re.compile(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$")
PHONE_RE = re.compile(r"^\+?[0-9\s\-().]{7,20}$")

ALLOWED_LANGS = {"en", "tr", "it"}
ALLOWED_CATEGORIES = {"watches", "art", "jewelry", "coins", "antiques", "wine", "cars", "memorabilia"}
ALLOWED_CONDITIONS = {"mint", "excellent", "very_good", "good", "fair", "restored", "very_fine"}
ALLOWED_SORT = {"newest", "price_asc", "price_desc", "ending_soon"}
ALLOWED_PAYMENT_METHODS = {"stripe", "bank_transfer"}
ALLOWED_ORDER_STATUSES = {"pending", "confirmed", "processing", "shipped", "completed", "cancelled", "refunded"}
ALLOWED_CURRENCIES = {"USD", "EUR", "TRY"}


def _validate_multilang(v: dict | None, field_name: str = "field") -> dict | None:
    if v is None:
        return v
    if not isinstance(v, dict):
        raise ValueError(f"{field_name} must be a dict.")
    for lang, text in v.items():
        if lang not in ALLOWED_LANGS:
            raise ValueError(f"Unsupported language key '{lang}'. Allowed: {ALLOWED_LANGS}")
        if not isinstance(text, str) or not text.strip():
            raise ValueError(f"{field_name}[{lang}] must be a non-empty string.")
        if len(text) > 10_000:
            raise ValueError(f"{field_name}[{lang}] exceeds 10,000 character limit.")
    return v


# ─────────────────────────────────────────────────────────────
# Auth
# ─────────────────────────────────────────────────────────────

class UserCreate(BaseModel):
    email: str = Field(..., max_length=254)
    password: str = Field(..., min_length=8, max_length=128)
    name: str = Field(..., min_length=1, max_length=100)
    phone: Optional[str] = Field(None, max_length=30)

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        v = v.strip().lower()
        if not EMAIL_RE.match(v):
            raise ValueError("Invalid email address.")
        return v

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Name cannot be empty.")
        return v

    @field_validator("phone")
    @classmethod
    def validate_phone(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        v = v.strip()
        if v and not PHONE_RE.match(v):
            raise ValueError("Invalid phone number format.")
        return v or None


class UserLogin(BaseModel):
    email: str = Field(..., max_length=254)
    password: str = Field(..., min_length=1, max_length=128)

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        return v.strip().lower()


class UserResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    email: str
    name: str
    picture: Optional[str] = None
    phone: Optional[str] = None
    role: str = "user"
    created_at: Optional[str] = None


# ─────────────────────────────────────────────────────────────
# Products
# ─────────────────────────────────────────────────────────────

class ProductCreate(BaseModel):
    title: dict
    description: dict
    category: str = Field(..., max_length=50)
    price: float = Field(..., ge=0)
    currency: str = Field("USD", max_length=3)
    images: list[str] = Field(default_factory=list, max_length=20)
    model_3d_url: Optional[str] = Field(None, max_length=500)
    condition: Optional[str] = Field("excellent", max_length=30)
    provenance: Optional[dict] = None
    provenance_history: Optional[list[dict]] = None
    certification_docs: Optional[list[dict]] = None
    investment_perspective: Optional[dict] = None
    condition_report: Optional[dict] = None
    store_id: Optional[str] = Field(None, max_length=50)
    is_auction: bool = False
    auction_start: Optional[str] = None
    auction_end: Optional[str] = None
    starting_bid: Optional[float] = Field(None, ge=0)
    reserve_price: Optional[float] = Field(None, ge=0)
    min_increment: Optional[float] = Field(None, ge=0)
    featured: bool = False

    @field_validator("category")
    @classmethod
    def validate_category(cls, v: str) -> str:
        if v not in ALLOWED_CATEGORIES:
            raise ValueError(f"Category must be one of: {sorted(ALLOWED_CATEGORIES)}")
        return v

    @field_validator("currency")
    @classmethod
    def validate_currency(cls, v: str) -> str:
        v = v.upper()
        if v not in ALLOWED_CURRENCIES:
            raise ValueError(f"Currency must be one of: {sorted(ALLOWED_CURRENCIES)}")
        return v

    @field_validator("condition")
    @classmethod
    def validate_condition(cls, v: Optional[str]) -> Optional[str]:
        if v and v not in ALLOWED_CONDITIONS:
            raise ValueError(f"Condition must be one of: {sorted(ALLOWED_CONDITIONS)}")
        return v

    @field_validator("title", "description")
    @classmethod
    def validate_multilang_required(cls, v: dict) -> dict:
        return _validate_multilang(v, "field") or {}

    @field_validator("images")
    @classmethod
    def validate_images(cls, v: list) -> list:
        for url in v:
            if not isinstance(url, str) or not url.startswith(("http://", "https://")):
                raise ValueError("Each image must be a valid http/https URL.")
        return v


class ProductUpdate(BaseModel):
    title: Optional[dict] = None
    description: Optional[dict] = None
    category: Optional[str] = Field(None, max_length=50)
    price: Optional[float] = Field(None, ge=0)
    currency: Optional[str] = Field(None, max_length=3)
    images: Optional[list[str]] = None
    model_3d_url: Optional[str] = None
    condition: Optional[str] = None
    provenance: Optional[dict] = None
    provenance_history: Optional[list[dict]] = None
    certification_docs: Optional[list[dict]] = None
    investment_perspective: Optional[dict] = None
    condition_report: Optional[dict] = None
    store_id: Optional[str] = None
    is_auction: Optional[bool] = None
    auction_start: Optional[str] = None
    auction_end: Optional[str] = None
    starting_bid: Optional[float] = Field(None, ge=0)
    reserve_price: Optional[float] = Field(None, ge=0)
    min_increment: Optional[float] = Field(None, ge=0)
    featured: Optional[bool] = None
    status: Optional[str] = None
    approval_status: Optional[str] = None


# ─────────────────────────────────────────────────────────────
# Bids
# ─────────────────────────────────────────────────────────────

class BidCreate(BaseModel):
    amount: float = Field(..., gt=0)
    max_auto_bid: Optional[float] = Field(None, gt=0)


# ─────────────────────────────────────────────────────────────
# Cart
# ─────────────────────────────────────────────────────────────

class CartItemAdd(BaseModel):
    product_id: str = Field(..., min_length=1, max_length=50)
    quantity: int = Field(1, ge=1, le=10)


# ─────────────────────────────────────────────────────────────
# Checkout
# ─────────────────────────────────────────────────────────────

class CheckoutRequest(BaseModel):
    payment_method: str
    origin_url: str = Field(..., max_length=500)

    @field_validator("payment_method")
    @classmethod
    def validate_payment_method(cls, v: str) -> str:
        if v not in ALLOWED_PAYMENT_METHODS:
            raise ValueError(f"Payment method must be one of: {sorted(ALLOWED_PAYMENT_METHODS)}")
        return v

    @field_validator("origin_url")
    @classmethod
    def validate_origin_url(cls, v: str) -> str:
        if not v.startswith(("http://", "https://")):
            raise ValueError("origin_url must start with http:// or https://")
        return v


# ─────────────────────────────────────────────────────────────
# Newsletter
# ─────────────────────────────────────────────────────────────

class NewsletterSubscribe(BaseModel):
    email: str = Field(..., max_length=254)
    language: str = Field("tr", max_length=5)

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        v = v.strip().lower()
        if not EMAIL_RE.match(v):
            raise ValueError("Invalid email address.")
        return v

    @field_validator("language")
    @classmethod
    def validate_language(cls, v: str) -> str:
        if v not in ALLOWED_LANGS:
            return "en"
        return v


# ─────────────────────────────────────────────────────────────
# AI
# ─────────────────────────────────────────────────────────────

class AIDescriptionRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    category: str = Field(..., max_length=50)
    condition: Optional[str] = Field("excellent", max_length=30)
    language: str = Field("tr", max_length=5)

    @field_validator("language")
    @classmethod
    def validate_language(cls, v: str) -> str:
        if v not in ALLOWED_LANGS:
            return "en"
        return v

    @field_validator("category")
    @classmethod
    def validate_category(cls, v: str) -> str:
        if v not in ALLOWED_CATEGORIES:
            raise ValueError(f"Category must be one of: {sorted(ALLOWED_CATEGORIES)}")
        return v


# ─────────────────────────────────────────────────────────────
# Articles
# ─────────────────────────────────────────────────────────────

class ArticleCreate(BaseModel):
    title: dict
    excerpt: dict
    content: dict
    category: str = Field(..., max_length=50)
    author: str = Field(..., min_length=1, max_length=100)
    featured_image: Optional[str] = Field(None, max_length=500)
    published: bool = False
    slug: Optional[str] = Field(None, max_length=200)

    @field_validator("slug")
    @classmethod
    def validate_slug(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        if not re.match(r"^[a-z0-9\-]+$", v):
            raise ValueError("Slug must contain only lowercase letters, digits, and hyphens.")
        return v


# ─────────────────────────────────────────────────────────────
# Stores
# ─────────────────────────────────────────────────────────────

class StoreCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: dict
    logo: Optional[str] = Field(None, max_length=500)
    contact_email: Optional[str] = Field(None, max_length=254)
    address: Optional[str] = Field(None, max_length=300)
    phone: Optional[str] = Field(None, max_length=30)
    website: Optional[str] = Field(None, max_length=300)

    @field_validator("contact_email")
    @classmethod
    def validate_email(cls, v: Optional[str]) -> Optional[str]:
        if v and not EMAIL_RE.match(v.strip().lower()):
            raise ValueError("Invalid contact email.")
        return v.strip().lower() if v else v


class StoreUpdate(BaseModel):
    name: Optional[str] = Field(None, max_length=100)
    description: Optional[dict] = None
    logo: Optional[str] = None
    contact_email: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    website: Optional[str] = None
    verified: Optional[bool] = None


# ─────────────────────────────────────────────────────────────
# Admin
# ─────────────────────────────────────────────────────────────

class OrderStatusUpdate(BaseModel):
    status: str

    @field_validator("status")
    @classmethod
    def validate_status(cls, v: str) -> str:
        if v not in ALLOWED_ORDER_STATUSES:
            raise ValueError(f"Status must be one of: {sorted(ALLOWED_ORDER_STATUSES)}")
        return v
