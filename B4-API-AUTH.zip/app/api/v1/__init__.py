"""
ANTICCA — API v1 Router Aggregator
"""

from fastapi import APIRouter
from app.api.v1 import auth, products, auctions, cart, payments, misc, admin

api_router = APIRouter(prefix="/api")

api_router.include_router(auth.router)
api_router.include_router(products.router)
api_router.include_router(auctions.router)
api_router.include_router(cart.router)
api_router.include_router(payments.router)
api_router.include_router(misc.router)
api_router.include_router(admin.router)
