"""
ANTICCA — Authentication Router
"""

import uuid
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Request, Response, HTTPException

from app.core.database import get_db
from app.core.security import (
    hash_password, verify_password, create_jwt_token,
    generate_user_id, get_current_user, exchange_session_id,
    validate_password_strength,
)
from app.core.logging import get_logger
from app.models.schemas import UserCreate, UserLogin

router = APIRouter(prefix="/auth", tags=["Auth"])
logger = get_logger(__name__)

_SESSION_DAYS = 7
_COOKIE_MAX_AGE = _SESSION_DAYS * 24 * 3600


def _sanitize_user(user: dict) -> dict:
    """Return user doc without sensitive fields."""
    return {k: v for k, v in user.items() if k not in ("password", "_id")}


@router.post("/register")
async def register(user: UserCreate):
    db = get_db()

    # Validate password strength before any DB work
    try:
        validate_password_strength(user.password)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if await db.users.find_one({"email": user.email}):
        raise HTTPException(status_code=409, detail="An account with this email already exists.")

    user_id = generate_user_id()
    doc = {
        "user_id": user_id,
        "email": user.email,
        "password": hash_password(user.password),
        "name": user.name,
        "phone": user.phone,
        "role": "user",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.users.insert_one(doc)
    token = create_jwt_token(user_id)
    return {"token": token, "user": _sanitize_user(doc)}


@router.post("/login")
async def login(creds: UserLogin):
    db = get_db()
    user = await db.users.find_one({"email": creds.email})
    # Constant-time check: always call verify even if user not found
    pw_hash = user.get("password", "") if user else ""
    valid = verify_password(creds.password, pw_hash) if pw_hash else False
    if not user or not valid:
        raise HTTPException(status_code=401, detail="Invalid email or password.")

    token = create_jwt_token(user["user_id"], user.get("role", "user"))
    return {"token": token, "user": _sanitize_user(user)}


@router.get("/session")
async def oauth_session(session_id: str, response: Response):
    db = get_db()
    data = await exchange_session_id(session_id)

    email = data.get("email", "").strip().lower()
    if not email:
        raise HTTPException(status_code=400, detail="OAuth provider did not return an email.")

    user = await db.users.find_one({"email": email})
    now = datetime.now(timezone.utc)

    if not user:
        user_id = generate_user_id()
        user = {
            "user_id": user_id,
            "email": email,
            "name": data.get("name", ""),
            "picture": data.get("picture", ""),
            "role": "user",
            "created_at": now.isoformat(),
        }
        await db.users.insert_one(user)
    else:
        user_id = user["user_id"]
        updates = {
            "name": data.get("name", user.get("name", "")),
            "picture": data.get("picture", user.get("picture", "")),
        }
        await db.users.update_one({"user_id": user_id}, {"$set": updates})
        user = {**user, **updates}

    session_token = data.get("session_token") or uuid.uuid4().hex

    # Remove any stale sessions for this user (keep last 5)
    await db.user_sessions.delete_many({
        "user_id": user["user_id"],
        "expires_at": {"$lt": now.isoformat()},
    })

    await db.user_sessions.insert_one({
        "session_id": f"sess_{uuid.uuid4().hex[:12]}",
        "user_id": user["user_id"],
        "session_token": session_token,
        "expires_at": (now + timedelta(days=_SESSION_DAYS)).isoformat(),
        "created_at": now.isoformat(),
    })

    response.set_cookie(
        key="session_token",
        value=session_token,
        path="/",
        secure=True,
        httponly=True,
        samesite="none",
        max_age=_COOKIE_MAX_AGE,
    )
    return {"user": _sanitize_user(user), "token": session_token}


@router.get("/me")
async def get_me(request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    return _sanitize_user(user)


@router.post("/logout")
async def logout(request: Request, response: Response):
    db = get_db()
    session_token = request.cookies.get("session_token")
    if session_token:
        await db.user_sessions.delete_one({"session_token": session_token})
    response.delete_cookie("session_token", path="/")
    return {"message": "Logged out successfully."}
