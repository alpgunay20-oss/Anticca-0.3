"""
ANTICCA — Auctions & Bids Router
"""

import uuid
from datetime import datetime, timezone, timedelta
from typing import Optional

from fastapi import APIRouter, Request, HTTPException

from app.core.database import get_db
from app.core.security import get_current_user
from app.core.logging import get_logger
from app.models.schemas import BidCreate

router = APIRouter(tags=["Auctions"])
logger = get_logger(__name__)

_ANTI_SNIPE_SECONDS = 300  # 5 minutes


def _parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    dt = datetime.fromisoformat(value)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


@router.get("/auctions")
async def list_auctions(limit: int = 20, skip: int = 0):
    if limit > 100:
        limit = 100
    db = get_db()
    now = datetime.now(timezone.utc).isoformat()
    query = {
        "is_auction": True,
        "status": "active",
        "approval_status": "approved",
        "auction_end": {"$gt": now},
    }
    auctions = (
        await db.products.find(query, {"_id": 0})
        .sort("auction_end", 1)
        .skip(skip)
        .limit(limit)
        .to_list(limit)
    )
    total = await db.products.count_documents(query)
    return {"auctions": auctions, "total": total}


@router.post("/auctions/{product_id}/bid")
async def place_bid(product_id: str, bid: BidCreate, request: Request):
    db = get_db()
    user = await get_current_user(request, db)

    product = await db.products.find_one(
        {"product_id": product_id, "is_auction": True, "status": "active"},
        {"_id": 0},
    )
    if not product:
        raise HTTPException(status_code=404, detail="Active auction not found.")

    now = datetime.now(timezone.utc)

    # Validate auction timing
    auction_end = _parse_dt(product.get("auction_end"))
    auction_start = _parse_dt(product.get("auction_start"))

    if auction_start and auction_start > now:
        raise HTTPException(status_code=400, detail="Auction has not started yet.")
    if auction_end and auction_end <= now:
        raise HTTPException(status_code=400, detail="Auction has already ended.")

    # Bidder cannot bid on their own listing
    if product.get("seller_id") == user["user_id"]:
        raise HTTPException(status_code=400, detail="You cannot bid on your own listing.")

    # Validate bid amount
    current_bid = float(product.get("current_bid") or product.get("starting_bid") or 0)
    min_increment = float(product.get("min_increment") or max(current_bid * 0.02, 100))
    min_valid_bid = current_bid + min_increment

    if bid.amount <= current_bid:
        raise HTTPException(
            status_code=400,
            detail=f"Bid must exceed the current bid of ${current_bid:,.2f}.",
        )
    if bid.amount < min_valid_bid:
        raise HTTPException(
            status_code=400,
            detail=f"Minimum bid increment is ${min_increment:,.2f}. Minimum acceptable bid: ${min_valid_bid:,.2f}.",
        )

    # Anti-sniping: extend auction by 5 min if bid placed in last 5 min
    new_auction_end = None
    if auction_end:
        seconds_remaining = (auction_end - now).total_seconds()
        if seconds_remaining < _ANTI_SNIPE_SECONDS:
            new_auction_end = (auction_end + timedelta(seconds=_ANTI_SNIPE_SECONDS)).isoformat()
            logger.info(
                "Anti-snipe triggered for product %s; extending to %s",
                product_id, new_auction_end,
            )

    # Persist bid
    bid_doc = {
        "bid_id": f"bid_{uuid.uuid4().hex[:12]}",
        "product_id": product_id,
        "user_id": user["user_id"],
        "user_name": user.get("name", "Anonymous"),
        "amount": bid.amount,
        "max_auto_bid": bid.max_auto_bid,
        "created_at": now.isoformat(),
    }
    await db.bids.insert_one(bid_doc)

    # Update product
    product_update: dict = {
        "current_bid": bid.amount,
        "$inc": {"bid_count": 1},
    }
    if new_auction_end:
        product_update["auction_end"] = new_auction_end

    await db.products.update_one(
        {"product_id": product_id},
        {"$set": {k: v for k, v in product_update.items() if k != "$inc"}, **{k: v for k, v in product_update.items() if k == "$inc"}},
    )

    bid_doc.pop("_id", None)
    return bid_doc


@router.get("/auctions/{product_id}/bids")
async def get_bids(product_id: str, limit: int = 50):
    if limit > 200:
        limit = 200
    db = get_db()
    bids = (
        await db.bids.find({"product_id": product_id}, {"_id": 0})
        .sort("created_at", -1)
        .to_list(limit)
    )
    return {"bids": bids, "count": len(bids)}
