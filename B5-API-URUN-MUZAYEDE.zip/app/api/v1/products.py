"""
ANTICCA — Products Router
"""

import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Request, HTTPException

from app.core.database import get_db
from app.core.security import get_current_user, require_admin
from app.core.logging import get_logger
from app.models.schemas import ProductCreate, ProductUpdate, ALLOWED_SORT

router = APIRouter(prefix="/products", tags=["Products"])
logger = get_logger(__name__)

_SORT_MAP = {
    "newest":       ("created_at", -1),
    "price_asc":    ("price", 1),
    "price_desc":   ("price", -1),
    "ending_soon":  ("auction_end", 1),
}


def _build_product_query(
    category: Optional[str] = None,
    is_auction: Optional[bool] = None,
    featured: Optional[bool] = None,
    store_id: Optional[str] = None,
    search: Optional[str] = None,
) -> dict:
    query: dict = {"status": "active", "approval_status": "approved"}
    if category:
        query["category"] = category
    if is_auction is not None:
        query["is_auction"] = is_auction
    if featured is not None:
        query["featured"] = featured
    if store_id:
        query["store_id"] = store_id
    if search:
        # Use MongoDB text search if index is present; fall back to regex
        query["$or"] = [
            {"title.tr": {"$regex": search, "$options": "i"}},
            {"title.en": {"$regex": search, "$options": "i"}},
            {"title.it": {"$regex": search, "$options": "i"}},
        ]
    return query


@router.get("")
async def list_products(
    category: Optional[str] = None,
    is_auction: Optional[bool] = None,
    featured: Optional[bool] = None,
    store_id: Optional[str] = None,
    sort: str = "newest",
    search: Optional[str] = None,
    limit: int = 20,
    skip: int = 0,
):
    if limit > 100:
        limit = 100
    if sort not in ALLOWED_SORT:
        sort = "newest"

    db = get_db()
    query = _build_product_query(category, is_auction, featured, store_id, search)
    sort_key, sort_dir = _SORT_MAP[sort]

    products = (
        await db.products.find(query, {"_id": 0})
        .sort(sort_key, sort_dir)
        .skip(skip)
        .limit(limit)
        .to_list(limit)
    )
    total = await db.products.count_documents(query)
    return {"products": products, "total": total, "limit": limit, "skip": skip}


@router.get("/{product_id}")
async def get_product(product_id: str, request: Request):
    db = get_db()
    product = await db.products.find_one({"product_id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found.")

    # Increment view counter (fire-and-forget; don't block response)
    await db.products.update_one({"product_id": product_id}, {"$inc": {"view_count": 1}})

    bids = []
    if product.get("is_auction"):
        bids = (
            await db.bids.find({"product_id": product_id}, {"_id": 0})
            .sort("created_at", -1)
            .to_list(50)
        )

    store = None
    if product.get("store_id"):
        store = await db.stores.find_one({"store_id": product["store_id"]}, {"_id": 0})

    return {**product, "bids": bids, "store": store}


@router.post("")
async def create_product(product: ProductCreate, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)

    doc = product.model_dump()
    doc["product_id"] = f"prod_{uuid.uuid4().hex[:12]}"
    doc["status"] = "active"
    doc["approval_status"] = "approved"
    doc["created_at"] = datetime.now(timezone.utc).isoformat()
    doc["view_count"] = 0
    if product.is_auction:
        doc["current_bid"] = product.starting_bid
        doc["bid_count"] = 0

    await db.products.insert_one(doc)
    return await db.products.find_one({"product_id": doc["product_id"]}, {"_id": 0})


@router.put("/{product_id}")
async def update_product(product_id: str, update: ProductUpdate, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)

    existing = await db.products.find_one({"product_id": product_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Product not found.")

    update_data = update.model_dump(exclude_none=True)
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update.")

    await db.products.update_one({"product_id": product_id}, {"$set": update_data})
    return await db.products.find_one({"product_id": product_id}, {"_id": 0})


@router.delete("/{product_id}")
async def delete_product(product_id: str, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)

    result = await db.products.delete_one({"product_id": product_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Product not found.")
    return {"message": "Product deleted."}


@router.get("/{product_id}/similar")
async def get_similar_products(product_id: str, limit: int = 4):
    if limit > 20:
        limit = 20
    db = get_db()
    product = await db.products.find_one({"product_id": product_id}, {"_id": 0})
    if not product:
        return {"products": []}

    similar = await (
        db.products.find(
            {
                "category": product["category"],
                "product_id": {"$ne": product_id},
                "status": "active",
                "approval_status": "approved",
            },
            {"_id": 0},
        )
        .limit(limit)
        .to_list(limit)
    )
    return {"products": similar}
