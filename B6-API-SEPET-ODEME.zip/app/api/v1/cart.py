"""
ANTICCA — Cart & Wishlist Router
"""

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Request, HTTPException

from app.core.database import get_db
from app.core.security import get_current_user
from app.core.logging import get_logger
from app.models.schemas import CartItemAdd

router = APIRouter(tags=["Cart & Wishlist"])
logger = get_logger(__name__)


# ─────────────────────────────────────────────────────────────
# Cart
# ─────────────────────────────────────────────────────────────

@router.get("/cart")
async def get_cart(request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    items = await db.cart_items.find({"user_id": user["user_id"]}, {"_id": 0}).to_list(100)

    enriched = []
    for item in items:
        product = await db.products.find_one(
            {"product_id": item["product_id"], "status": "active"},
            {"_id": 0},
        )
        if product:
            # Don't allow auction items in cart
            if not product.get("is_auction"):
                enriched.append({**item, "product": product})
        else:
            # Product no longer active — silently remove from cart
            await db.cart_items.delete_one({"user_id": user["user_id"], "product_id": item["product_id"]})

    return {"items": enriched, "count": len(enriched)}


@router.post("/cart")
async def add_to_cart(item: CartItemAdd, request: Request):
    db = get_db()
    user = await get_current_user(request, db)

    product = await db.products.find_one(
        {"product_id": item.product_id, "status": "active"},
        {"_id": 0},
    )
    if not product:
        raise HTTPException(status_code=404, detail="Product not found or unavailable.")
    if product.get("is_auction"):
        raise HTTPException(status_code=400, detail="Auction items cannot be added to cart. Place a bid instead.")

    existing = await db.cart_items.find_one(
        {"user_id": user["user_id"], "product_id": item.product_id}
    )
    if existing:
        new_qty = min(existing.get("quantity", 1) + item.quantity, 10)
        await db.cart_items.update_one(
            {"user_id": user["user_id"], "product_id": item.product_id},
            {"$set": {"quantity": new_qty}},
        )
    else:
        await db.cart_items.insert_one({
            "cart_item_id": f"ci_{uuid.uuid4().hex[:12]}",
            "user_id": user["user_id"],
            "product_id": item.product_id,
            "quantity": item.quantity,
            "created_at": datetime.now(timezone.utc).isoformat(),
        })

    return {"message": "Item added to cart."}


@router.delete("/cart/{product_id}")
async def remove_from_cart(product_id: str, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    result = await db.cart_items.delete_one(
        {"user_id": user["user_id"], "product_id": product_id}
    )
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Item not in cart.")
    return {"message": "Item removed from cart."}


@router.delete("/cart")
async def clear_cart(request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    await db.cart_items.delete_many({"user_id": user["user_id"]})
    return {"message": "Cart cleared."}


# ─────────────────────────────────────────────────────────────
# Wishlist
# ─────────────────────────────────────────────────────────────

@router.get("/wishlist")
async def get_wishlist(request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    items = await db.watchlist.find({"user_id": user["user_id"]}, {"_id": 0}).to_list(200)

    enriched = []
    for item in items:
        product = await db.products.find_one({"product_id": item["product_id"]}, {"_id": 0})
        if product:
            enriched.append(product)

    return {"items": enriched, "count": len(enriched)}


@router.post("/wishlist/{product_id}")
async def toggle_wishlist(product_id: str, request: Request):
    db = get_db()
    user = await get_current_user(request, db)

    product = await db.products.find_one({"product_id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found.")

    existing = await db.watchlist.find_one(
        {"user_id": user["user_id"], "product_id": product_id}
    )
    if existing:
        await db.watchlist.delete_one({"user_id": user["user_id"], "product_id": product_id})
        return {"action": "removed", "product_id": product_id}

    await db.watchlist.insert_one({
        "user_id": user["user_id"],
        "product_id": product_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
    })
    return {"action": "added", "product_id": product_id}
