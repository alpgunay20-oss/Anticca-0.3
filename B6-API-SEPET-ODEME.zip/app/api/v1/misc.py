"""
ANTICCA — Miscellaneous Routers
Covers: Orders, User Bids, Newsletter, AI Descriptions,
        Stores, Articles, FAQ, I18N, Categories
"""

import uuid
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Request, HTTPException

from app.core.database import get_db
from app.core.security import get_current_user, require_admin
from app.core.config import settings
from app.core.logging import get_logger
from app.models.schemas import (
    NewsletterSubscribe, AIDescriptionRequest,
    ArticleCreate, StoreCreate, StoreUpdate,
)
from app.utils.i18n import translations, CATEGORIES

router = APIRouter(tags=["Misc"])
logger = get_logger(__name__)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ─────────────────────────────────────────────────────────────
# I18N
# ─────────────────────────────────────────────────────────────

@router.get("/translations/{lang}")
async def get_translations(lang: str):
    return translations.get(lang, translations["en"])


@router.get("/categories")
async def get_categories():
    db = get_db()
    cats = await db.categories.find({}, {"_id": 0}).to_list(50)
    return cats


# ─────────────────────────────────────────────────────────────
# Orders
# ─────────────────────────────────────────────────────────────

@router.get("/orders")
async def list_orders(request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    if user.get("role") == "admin":
        query: dict = {}
    else:
        query = {"user_id": user["user_id"]}
    orders = await db.orders.find(query, {"_id": 0}).sort("created_at", -1).to_list(200)
    return {"orders": orders}


@router.get("/orders/{order_id}")
async def get_order(order_id: str, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    order = await db.orders.find_one({"order_id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found.")
    if user.get("role") != "admin" and order["user_id"] != user["user_id"]:
        raise HTTPException(status_code=403, detail="Access denied.")
    return order


# ─────────────────────────────────────────────────────────────
# User Bids
# ─────────────────────────────────────────────────────────────

@router.get("/my-bids")
async def get_my_bids(request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    bids = (
        await db.bids.find({"user_id": user["user_id"]}, {"_id": 0})
        .sort("created_at", -1)
        .to_list(200)
    )
    enriched = []
    for bid in bids:
        product = await db.products.find_one({"product_id": bid["product_id"]}, {"_id": 0})
        if product:
            enriched.append({**bid, "product": product})
    return {"bids": enriched}


# ─────────────────────────────────────────────────────────────
# Newsletter
# ─────────────────────────────────────────────────────────────

@router.post("/newsletter")
async def subscribe_newsletter(sub: NewsletterSubscribe):
    db = get_db()
    if await db.newsletter.find_one({"email": sub.email}):
        return {"message": "You are already subscribed."}
    await db.newsletter.insert_one({
        "email": sub.email,
        "language": sub.language,
        "subscribed_at": _now(),
    })
    return {"message": "Subscribed successfully."}


# ─────────────────────────────────────────────────────────────
# AI Descriptions
# ─────────────────────────────────────────────────────────────

@router.post("/ai/generate-description")
async def generate_description(req: AIDescriptionRequest, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)

    if not settings.EMERGENT_LLM_KEY:
        raise HTTPException(status_code=503, detail="AI service is not configured.")

    try:
        from emergentintegrations.llm.chat import LlmChat, UserMessage
    except ImportError:
        raise HTTPException(status_code=503, detail="LLM library unavailable.")

    lang_map = {"tr": "Turkish", "en": "English", "it": "Italian"}
    lang_name = lang_map.get(req.language, "English")

    try:
        chat = LlmChat(
            api_key=settings.EMERGENT_LLM_KEY,
            session_id=f"desc_{uuid.uuid4().hex[:8]}",
            system_message=(
                f"You are a luxury collectibles expert copywriter. "
                f"Write compelling, prestigious product descriptions for high-net-worth buyers. "
                f"Write in {lang_name}. Keep it under 200 words. "
                f"Be sophisticated, accurate, and authoritative. Do not fabricate provenance."
            ),
        ).with_model("openai", "gpt-4o")

        prompt = (
            f"Write a premium product description for: {req.title}. "
            f"Category: {req.category}. Condition: {req.condition}."
        )
        response = await chat.send_message(UserMessage(text=prompt))
    except Exception as exc:
        logger.error("AI description generation failed: %s", exc)
        raise HTTPException(status_code=502, detail="AI service error. Please try again.")

    return {"description": response, "language": req.language}


# ─────────────────────────────────────────────────────────────
# Stores
# ─────────────────────────────────────────────────────────────

@router.get("/stores")
async def list_stores():
    db = get_db()
    stores = await db.stores.find({}, {"_id": 0}).to_list(100)
    for store in stores:
        sid = store.get("store_id")
        store["product_count"] = await db.products.count_documents(
            {"store_id": sid, "status": "active"}
        )
        store["auction_count"] = await db.products.count_documents(
            {"store_id": sid, "is_auction": True, "status": "active"}
        )
    return {"stores": stores}


@router.get("/stores/{store_id}")
async def get_store(store_id: str):
    db = get_db()
    store = await db.stores.find_one({"store_id": store_id}, {"_id": 0})
    if not store:
        raise HTTPException(status_code=404, detail="Store not found.")
    products = await db.products.find(
        {"store_id": store_id, "status": "active"}, {"_id": 0}
    ).to_list(100)
    return {
        **store,
        "products": products,
        "auction_products": [p for p in products if p.get("is_auction")],
        "direct_products": [p for p in products if not p.get("is_auction")],
    }


@router.post("/stores")
async def create_store(store: StoreCreate, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)

    doc = store.model_dump()
    doc["store_id"] = f"store_{uuid.uuid4().hex[:12]}"
    doc["verified"] = False
    doc["created_at"] = _now()
    await db.stores.insert_one(doc)
    return await db.stores.find_one({"store_id": doc["store_id"]}, {"_id": 0})


@router.put("/stores/{store_id}")
async def update_store(store_id: str, update: StoreUpdate, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)

    if not await db.stores.find_one({"store_id": store_id}):
        raise HTTPException(status_code=404, detail="Store not found.")

    update_data = update.model_dump(exclude_none=True)
    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update.")

    await db.stores.update_one({"store_id": store_id}, {"$set": update_data})
    return await db.stores.find_one({"store_id": store_id}, {"_id": 0})


# ─────────────────────────────────────────────────────────────
# Articles
# ─────────────────────────────────────────────────────────────

@router.get("/articles")
async def list_articles(
    category: Optional[str] = None, limit: int = 20, skip: int = 0
):
    if limit > 100:
        limit = 100
    db = get_db()
    query: dict = {"published": True}
    if category:
        query["category"] = category
    articles = (
        await db.articles.find(query, {"_id": 0})
        .sort("created_at", -1)
        .skip(skip)
        .limit(limit)
        .to_list(limit)
    )
    total = await db.articles.count_documents(query)
    return {"articles": articles, "total": total}


@router.get("/articles/{article_id}")
async def get_article(article_id: str):
    db = get_db()
    article = await db.articles.find_one({"article_id": article_id}, {"_id": 0})
    if not article:
        raise HTTPException(status_code=404, detail="Article not found.")
    return article


@router.post("/articles")
async def create_article(article: ArticleCreate, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)

    doc = article.model_dump()
    doc["article_id"] = f"art_{uuid.uuid4().hex[:12]}"
    doc["created_at"] = _now()
    await db.articles.insert_one(doc)
    return await db.articles.find_one({"article_id": doc["article_id"]}, {"_id": 0})


@router.delete("/articles/{article_id}")
async def delete_article(article_id: str, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)

    result = await db.articles.delete_one({"article_id": article_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Article not found.")
    return {"message": "Article deleted."}


# ─────────────────────────────────────────────────────────────
# FAQ
# ─────────────────────────────────────────────────────────────

@router.get("/faq")
async def list_faq(category: Optional[str] = None):
    db = get_db()
    query: dict = {}
    if category:
        query["category"] = category
    items = await db.faq.find(query, {"_id": 0}).sort("order", 1).to_list(100)
    return {"items": items}
