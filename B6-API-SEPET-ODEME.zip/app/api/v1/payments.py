"""
ANTICCA — Payments Router
Handles Stripe checkout and bank transfer orders.
"""

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Request, HTTPException

from app.core.database import get_db
from app.core.security import get_current_user
from app.core.config import settings
from app.core.logging import get_logger
from app.models.schemas import CheckoutRequest

router = APIRouter(prefix="/payments", tags=["Payments"])
logger = get_logger(__name__)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


async def _build_cart_summary(db, user_id: str) -> tuple[list[dict], float]:
    """Return (items_detail, total). Raises 400 if cart is empty."""
    cart = await db.cart_items.find({"user_id": user_id}, {"_id": 0}).to_list(100)
    if not cart:
        raise HTTPException(status_code=400, detail="Your cart is empty.")

    total = 0.0
    items_detail: list[dict] = []
    for item in cart:
        product = await db.products.find_one(
            {"product_id": item["product_id"], "status": "active"},
            {"_id": 0},
        )
        if not product:
            continue
        qty = max(1, item.get("quantity", 1))
        subtotal = product["price"] * qty
        total += subtotal
        items_detail.append({
            "product_id": product["product_id"],
            "title": product.get("title", {}).get("en", "Item"),
            "price": product["price"],
            "quantity": qty,
            "subtotal": subtotal,
        })

    if not items_detail:
        raise HTTPException(status_code=400, detail="No purchasable items in cart.")

    return items_detail, total


@router.post("/checkout")
async def create_checkout(req: CheckoutRequest, request: Request):
    db = get_db()
    user = await get_current_user(request, db)

    items_detail, total = await _build_cart_summary(db, user["user_id"])
    order_id = f"order_{uuid.uuid4().hex[:12]}"
    txn_id = f"txn_{uuid.uuid4().hex[:12]}"

    if req.payment_method == "stripe":
        if not settings.STRIPE_API_KEY:
            raise HTTPException(status_code=503, detail="Stripe payments are not configured.")

        try:
            from emergentintegrations.payments.stripe.checkout import (
                StripeCheckout, CheckoutSessionRequest,
            )
        except ImportError:
            raise HTTPException(status_code=503, detail="Payment provider library unavailable.")

        success_url = f"{req.origin_url}/checkout/success?session_id={{CHECKOUT_SESSION_ID}}"
        cancel_url = f"{req.origin_url}/cart"
        webhook_url = f"{str(request.base_url).rstrip('/')}/api/webhook/stripe"

        stripe_checkout = StripeCheckout(
            api_key=settings.STRIPE_API_KEY,
            webhook_url=webhook_url,
        )
        checkout_req = CheckoutSessionRequest(
            amount=round(total, 2),
            currency="usd",
            success_url=success_url,
            cancel_url=cancel_url,
            metadata={"order_id": order_id, "user_id": user["user_id"]},
        )

        try:
            session = await stripe_checkout.create_checkout_session(checkout_req)
        except Exception as exc:
            logger.error("Stripe checkout session creation failed: %s", exc)
            raise HTTPException(status_code=502, detail="Payment provider error. Please try again.")

        shared = {
            "order_id": order_id,
            "user_id": user["user_id"],
            "items": items_detail,
            "total": round(total, 2),
            "currency": "USD",
            "payment_method": "stripe",
            "payment_status": "pending",
            "session_id": session.session_id,
            "created_at": _now(),
        }
        await db.orders.insert_one({**shared, "status": "pending"})
        await db.payment_transactions.insert_one({
            **shared, "transaction_id": txn_id,
        })

        logger.info("Stripe checkout created: order=%s session=%s total=%.2f", order_id, session.session_id, total)
        return {"url": session.url, "session_id": session.session_id, "order_id": order_id}

    elif req.payment_method == "bank_transfer":
        shared = {
            "order_id": order_id,
            "user_id": user["user_id"],
            "items": items_detail,
            "total": round(total, 2),
            "currency": "USD",
            "payment_method": "bank_transfer",
            "payment_status": "awaiting_transfer",
            "status": "pending",
            "created_at": _now(),
        }
        await db.orders.insert_one(shared)
        await db.payment_transactions.insert_one({
            **shared, "transaction_id": txn_id,
        })
        await db.cart_items.delete_many({"user_id": user["user_id"]})

        logger.info("Bank transfer order created: order=%s total=%.2f", order_id, total)
        return {
            "order_id": order_id,
            "payment_method": "bank_transfer",
            "bank_details": {
                "bank": "ANTICCA Trust Bank",
                "iban": "TR00 0000 0000 0000 0000 0000 00",
                "swift": "ANTCTRXX",
                "reference": order_id,
                "amount": round(total, 2),
                "currency": "USD",
            },
        }

    # Should not reach here (validated by schema), but safety net
    raise HTTPException(status_code=400, detail="Unsupported payment method.")


@router.get("/status/{session_id}")
async def check_payment_status(session_id: str, request: Request):
    db = get_db()
    user = await get_current_user(request, db)

    if not settings.STRIPE_API_KEY:
        raise HTTPException(status_code=503, detail="Stripe not configured.")

    try:
        from emergentintegrations.payments.stripe.checkout import StripeCheckout
    except ImportError:
        raise HTTPException(status_code=503, detail="Payment provider library unavailable.")

    webhook_url = f"{str(request.base_url).rstrip('/')}/api/webhook/stripe"
    stripe_checkout = StripeCheckout(api_key=settings.STRIPE_API_KEY, webhook_url=webhook_url)

    try:
        status = await stripe_checkout.get_checkout_status(session_id)
    except Exception as exc:
        logger.error("Stripe status check failed: %s", exc)
        raise HTTPException(status_code=502, detail="Payment provider error.")

    if status.payment_status == "paid":
        txn = await db.payment_transactions.find_one({"session_id": session_id}, {"_id": 0})
        if txn and txn.get("payment_status") != "paid":
            # Verify the order belongs to the requesting user
            if txn.get("user_id") != user["user_id"]:
                raise HTTPException(status_code=403, detail="Access denied.")

            await db.payment_transactions.update_one(
                {"session_id": session_id},
                {"$set": {"payment_status": "paid", "paid_at": _now()}},
            )
            await db.orders.update_one(
                {"session_id": session_id},
                {"$set": {"payment_status": "paid", "status": "confirmed", "confirmed_at": _now()}},
            )
            if txn.get("user_id"):
                await db.cart_items.delete_many({"user_id": txn["user_id"]})
            logger.info("Payment confirmed via status poll: session=%s", session_id)

    return {
        "status": status.status,
        "payment_status": status.payment_status,
        "amount_total": status.amount_total,
        "currency": status.currency,
    }


@router.post("/webhook/stripe")
async def stripe_webhook(request: Request):
    if not settings.STRIPE_API_KEY:
        return {"status": "not configured"}

    try:
        from emergentintegrations.payments.stripe.checkout import StripeCheckout
    except ImportError:
        return {"status": "library unavailable"}

    body = await request.body()
    sig = request.headers.get("Stripe-Signature", "")
    db = get_db()
    webhook_url = f"{str(request.base_url).rstrip('/')}/api/webhook/stripe"
    stripe_checkout = StripeCheckout(api_key=settings.STRIPE_API_KEY, webhook_url=webhook_url)

    try:
        event = await stripe_checkout.handle_webhook(body, sig)
        if event.payment_status == "paid":
            await db.payment_transactions.update_one(
                {"session_id": event.session_id},
                {"$set": {"payment_status": "paid", "paid_at": _now()}},
            )
            await db.orders.update_one(
                {"session_id": event.session_id},
                {"$set": {"payment_status": "paid", "status": "confirmed", "confirmed_at": _now()}},
            )
            # Clear cart for user linked to this transaction
            txn = await db.payment_transactions.find_one({"session_id": event.session_id})
            if txn and txn.get("user_id"):
                await db.cart_items.delete_many({"user_id": txn["user_id"]})
            logger.info("Stripe webhook: payment confirmed session=%s", event.session_id)
    except Exception as exc:
        logger.error("Stripe webhook processing error: %s", exc)
        # Always return 200 to Stripe to prevent retries on our logic errors
    return {"status": "ok"}
