"""
ANTICCA — Admin Router
All endpoints require admin role.
"""

from fastapi import APIRouter, Request, HTTPException

from app.core.database import get_db
from app.core.security import get_current_user, require_admin
from app.core.logging import get_logger
from app.models.schemas import OrderStatusUpdate

router = APIRouter(prefix="/admin", tags=["Admin"])
logger = get_logger(__name__)


@router.get("/stats")
async def admin_stats(request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)

    total_products = await db.products.count_documents({})
    active_auctions = await db.products.count_documents({"is_auction": True, "status": "active"})
    total_users = await db.users.count_documents({})
    total_orders = await db.orders.count_documents({})
    total_stores = await db.stores.count_documents({})
    total_articles = await db.articles.count_documents({})

    paid_orders = await db.orders.find(
        {"payment_status": "paid"}, {"_id": 0, "total": 1}
    ).to_list(10_000)
    total_revenue = sum(o.get("total", 0) for o in paid_orders)

    recent_orders = await db.orders.find({}, {"_id": 0}).sort("created_at", -1).limit(10).to_list(10)

    return {
        "total_products": total_products,
        "active_auctions": active_auctions,
        "total_users": total_users,
        "total_orders": total_orders,
        "total_stores": total_stores,
        "total_articles": total_articles,
        "total_revenue": round(total_revenue, 2),
        "recent_orders": recent_orders,
    }


@router.get("/users")
async def admin_users(request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)
    users = await db.users.find({}, {"_id": 0, "password": 0}).to_list(10_000)
    return {"users": users, "total": len(users)}


@router.get("/orders")
async def admin_orders(request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)
    orders = await db.orders.find({}, {"_id": 0}).sort("created_at", -1).to_list(10_000)
    return {"orders": orders, "total": len(orders)}


@router.put("/orders/{order_id}/status")
async def update_order_status(order_id: str, body: OrderStatusUpdate, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)

    result = await db.orders.update_one(
        {"order_id": order_id}, {"$set": {"status": body.status}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Order not found.")
    logger.info("Admin %s updated order %s to status '%s'", user["user_id"], order_id, body.status)
    return {"message": "Order status updated.", "order_id": order_id, "status": body.status}


@router.put("/stores/{store_id}/verify")
async def verify_store(store_id: str, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)

    result = await db.stores.update_one({"store_id": store_id}, {"$set": {"verified": True}})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Store not found.")
    logger.info("Store %s verified by admin %s", store_id, user["user_id"])
    return {"message": "Store verified."}


@router.put("/products/{product_id}/approve")
async def approve_product(product_id: str, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)

    result = await db.products.update_one(
        {"product_id": product_id},
        {"$set": {"approval_status": "approved", "status": "active"}},
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Product not found.")
    logger.info("Product %s approved by admin %s", product_id, user["user_id"])
    return {"message": "Product approved."}


@router.delete("/products/{product_id}")
async def admin_delete_product(product_id: str, request: Request):
    db = get_db()
    user = await get_current_user(request, db)
    require_admin(user)

    result = await db.products.delete_one({"product_id": product_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Product not found.")
    logger.warning("Product %s hard-deleted by admin %s", product_id, user["user_id"])
    return {"message": "Product deleted."}
