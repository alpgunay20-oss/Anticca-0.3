"""
ANTICCA — Database Seed Service
Populates initial data only when collections are empty.
"""

import uuid
from datetime import datetime, timezone, timedelta

from app.core.database import get_db
from app.core.security import hash_password, generate_user_id
from app.core.config import settings
from app.core.logging import get_logger
from app.utils.i18n import CATEGORIES

logger = get_logger(__name__)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _future(days: int) -> str:
    return (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()


def _past(days: int) -> str:
    return (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()


async def seed_all() -> None:
    db = get_db()
    await _seed_categories(db)
    await _seed_stores(db)
    await _seed_products(db)
    await _seed_articles(db)
    await _seed_faq(db)
    await _seed_admin(db)


async def _seed_categories(db) -> None:
    if await db.categories.count_documents({}) > 0:
        return
    for cat in CATEGORIES:
        await db.categories.insert_one({
            "category_id": cat["id"],
            "name": cat["name"],
            "icon": cat["icon"],
        })
    logger.info("Seeded %d categories", len(CATEGORIES))


async def _seed_stores(db) -> None:
    if await db.stores.count_documents({}) > 0:
        return
    stores = [
        {
            "store_id": "store_kronos01",
            "name": "Kronos Antik Saatler",
            "description": {
                "tr": "Turkiye'nin onde gelen antik saat ve luks zaman parcalari uzmani. 30 yillik deneyim.",
                "en": "Turkey's leading antique watch and luxury timepiece specialist. Trusted source with 30 years of expertise.",
                "it": "Lo specialista leader in Turchia per orologi antichi. 30 anni di esperienza.",
            },
            "logo": "https://images.pexels.com/photos/2113994/pexels-photo-2113994.jpeg?auto=compress&cs=tinysrgb&w=200",
            "contact_email": "info@kronosantik.com",
            "address": "Nisantasi, Istanbul",
            "phone": "+90 212 555 0001",
            "website": "https://kronosantik.com",
            "verified": True,
            "created_at": _now(),
        },
        {
            "store_id": "store_galeri02",
            "name": "Galeri Istanbul",
            "description": {
                "tr": "Cagdas ve klasik sanat eserlerinin bulus noktasi.",
                "en": "Meeting point for contemporary and classical art.",
                "it": "Punto d'incontro per l'arte contemporanea e classica.",
            },
            "logo": "https://images.pexels.com/photos/3004909/pexels-photo-3004909.jpeg?auto=compress&cs=tinysrgb&w=200",
            "contact_email": "info@galeriistanbul.com",
            "address": "Beyoglu, Istanbul",
            "phone": "+90 212 555 0002",
            "website": "https://galeriistanbul.com",
            "verified": True,
            "created_at": _now(),
        },
        {
            "store_id": "store_heritage03",
            "name": "Miras Koleksiyonlari",
            "description": {
                "tr": "Nadir sikkeler, antika mobilyalar ve tarihi eserler konusunda uzmanlasmis guvenilir koleksiyon evi.",
                "en": "Trusted collection house specializing in rare coins, antique furniture, and historical artifacts.",
                "it": "Casa di collezioni affidabile specializzata in monete rare e manufatti storici.",
            },
            "logo": "https://images.pexels.com/photos/6044266/pexels-photo-6044266.jpeg?auto=compress&cs=tinysrgb&w=200",
            "contact_email": "info@miraskoleksiyon.com",
            "address": "Kadikoy, Istanbul",
            "phone": "+90 216 555 0003",
            "website": "https://miraskoleksiyon.com",
            "verified": True,
            "created_at": _now(),
        },
    ]
    for s in stores:
        await db.stores.insert_one(s)
    logger.info("Seeded %d stores", len(stores))


async def _seed_products(db) -> None:
    if await db.products.count_documents({}) > 0:
        return

    def _pid() -> str:
        return f"prod_{uuid.uuid4().hex[:12]}"

    products = [
        {
            "product_id": _pid(),
            "title": {"tr": "Patek Philippe Nautilus 5711", "en": "Patek Philippe Nautilus 5711", "it": "Patek Philippe Nautilus 5711"},
            "description": {
                "tr": "Orijinal kutu ve belgeleriyle kusursuz durumda Patek Philippe Nautilus 5711/1A-010.",
                "en": "Pristine condition Patek Philippe Nautilus 5711/1A-010 with original box and papers.",
                "it": "Patek Philippe Nautilus 5711/1A-010 in condizioni perfette con scatola e documenti originali.",
            },
            "category": "watches", "price": 185000.00, "currency": "USD",
            "images": ["https://images.pexels.com/photos/16886383/pexels-photo-16886383.jpeg?auto=compress&cs=tinysrgb&w=800"],
            "condition": "excellent",
            "provenance": {"tr": "Ozel Avrupa koleksiyonu, 2019'da edinildi", "en": "Private European collection, acquired 2019", "it": "Collezione privata europea, acquisito nel 2019"},
            "investment_perspective": {"tr": "Son 5 yilda %45 deger artisi.", "en": "45% value appreciation in last 5 years.", "it": "Apprezzamento del 45% negli ultimi 5 anni."},
            "is_auction": False, "status": "active", "approval_status": "approved",
            "featured": True, "store_id": "store_kronos01", "created_at": _now(), "view_count": 0,
        },
        {
            "product_id": _pid(),
            "title": {"tr": "1955 Mercedes-Benz 300SL Gullwing", "en": "1955 Mercedes-Benz 300SL Gullwing", "it": "1955 Mercedes-Benz 300SL Gullwing"},
            "description": {
                "tr": "Eslesen numaralar, tamamen restore edilmis 300SL Gullwing.",
                "en": "Matching numbers, fully restored 300SL Gullwing in Silver Blue Metallic.",
                "it": "Numeri corrispondenti, 300SL Gullwing completamente restaurata.",
            },
            "category": "cars", "price": 1450000.00, "currency": "USD",
            "images": ["https://images.pexels.com/photos/16560119/pexels-photo-16560119.jpeg?auto=compress&cs=tinysrgb&w=800"],
            "condition": "restored",
            "provenance": {"tr": "Ozel Alman koleksiyonu", "en": "Private German collection", "it": "Collezione privata tedesca"},
            "investment_perspective": {"tr": "Klasik otomobil piyasasinda istikrarli deger artisi.", "en": "Stable value appreciation in classic car market.", "it": "Stabile apprezzamento nel mercato auto classiche."},
            "is_auction": True,
            "auction_start": _now(), "auction_end": _future(7),
            "starting_bid": 1200000.00, "reserve_price": 1400000.00,
            "current_bid": 1250000.00, "bid_count": 3, "min_increment": 25000.00,
            "status": "active", "approval_status": "approved", "featured": True,
            "store_id": "store_heritage03", "created_at": _now(), "view_count": 0,
        },
        {
            "product_id": _pid(),
            "title": {"tr": "Banksy - Balonlu Kiz (Imzali Baski)", "en": "Banksy - Girl with Balloon (Signed Print)", "it": "Banksy - Ragazza con Palloncino (Stampa Firmata)"},
            "description": {
                "tr": "Dogrulanmis Banksy serigrafi baskisi, 150 adetlik edisyon.",
                "en": "Authenticated Banksy screen print, edition of 150, with Pest Control certificate.",
                "it": "Serigrafia autenticata di Banksy, edizione di 150.",
            },
            "category": "art", "price": 420000.00, "currency": "USD",
            "images": ["https://images.pexels.com/photos/4046718/pexels-photo-4046718.jpeg?auto=compress&cs=tinysrgb&w=800"],
            "condition": "mint",
            "provenance": {"tr": "Londra'daki ozel koleksiyondan", "en": "From private London collection", "it": "Da collezione privata londinese"},
            "is_auction": True,
            "auction_start": _now(), "auction_end": _future(5),
            "starting_bid": 350000.00, "reserve_price": 400000.00,
            "current_bid": 380000.00, "bid_count": 8, "min_increment": 10000.00,
            "status": "active", "approval_status": "approved", "featured": True,
            "store_id": "store_galeri02", "created_at": _now(), "view_count": 0,
        },
        {
            "product_id": _pid(),
            "title": {"tr": "1794 Akan Sacli Gumus Dolar", "en": "1794 Flowing Hair Silver Dollar", "it": "1794 Dollaro d'Argento Flowing Hair"},
            "description": {
                "tr": "ABD Darphanesi tarafindan basilan ilk gumus dolarlardan biri. PCGS VF-35.",
                "en": "One of the first silver dollars struck by the United States Mint. PCGS graded VF-35.",
                "it": "Uno dei primi dollari d'argento coniati dalla Zecca degli Stati Uniti. PCGS VF-35.",
            },
            "category": "coins", "price": 5200000.00, "currency": "USD",
            "images": ["https://images.pexels.com/photos/30895543/pexels-photo-30895543.jpeg?auto=compress&cs=tinysrgb&w=800"],
            "condition": "very_fine",
            "provenance": {"tr": "ABD'deki ozel koleksiyondan", "en": "From private US collection", "it": "Da collezione privata USA"},
            "investment_perspective": {"tr": "Nadir sikke piyasasinda en yuksek deger artis potansiyeli.", "en": "Highest appreciation potential in rare coin market.", "it": "Massimo potenziale nel mercato delle monete rare."},
            "is_auction": False, "status": "active", "approval_status": "approved",
            "featured": True, "store_id": "store_heritage03", "created_at": _now(), "view_count": 0,
        },
        {
            "product_id": _pid(),
            "title": {"tr": "Cartier Art Deco Elmas Bileklik", "en": "Cartier Art Deco Diamond Bracelet", "it": "Bracciale Cartier Art Deco con Diamanti"},
            "description": {
                "tr": "Yaklasik 1925 Cartier platin ve elmas Art Deco bileklik. Toplam 18.5 karat.",
                "en": "Circa 1925 Cartier platinum and diamond Art Deco bracelet. Total diamond weight 18.5 carats.",
                "it": "Bracciale Art Deco Cartier in platino e diamanti, circa 1925. 18,5 carati.",
            },
            "category": "jewelry", "price": 890000.00, "currency": "USD",
            "images": ["https://images.pexels.com/photos/16886383/pexels-photo-16886383.jpeg?auto=compress&cs=tinysrgb&w=800"],
            "condition": "excellent",
            "provenance": {"tr": "Isvicreli ozel koleksiyoncudan", "en": "From Swiss private collector", "it": "Da collezionista privato svizzero"},
            "is_auction": True,
            "auction_start": _now(), "auction_end": _future(3),
            "starting_bid": 750000.00, "reserve_price": 850000.00,
            "current_bid": 810000.00, "bid_count": 12, "min_increment": 15000.00,
            "status": "active", "approval_status": "approved", "featured": True,
            "store_id": "store_kronos01", "created_at": _now(), "view_count": 0,
        },
        {
            "product_id": _pid(),
            "title": {"tr": "18. Yuzyil Ming Hanedani Vazosu", "en": "18th Century Ming Dynasty Vase", "it": "Vaso della Dinastia Ming del XVIII Secolo"},
            "description": {
                "tr": "El boyamasi mavi-beyaz dekorasyonlu nadide Ming Hanedani porselen vazo.",
                "en": "Exquisite Ming Dynasty porcelain vase with hand-painted blue and white decoration.",
                "it": "Squisito vaso in porcellana della Dinastia Ming con decorazione dipinta a mano.",
            },
            "category": "antiques", "price": 320000.00, "currency": "USD",
            "images": ["https://images.pexels.com/photos/4046718/pexels-photo-4046718.jpeg?auto=compress&cs=tinysrgb&w=800"],
            "condition": "good",
            "provenance": {"tr": "Ingiliz ozel mulkunden", "en": "From English private estate", "it": "Da proprieta privata inglese"},
            "is_auction": False, "status": "active", "approval_status": "approved",
            "featured": False, "store_id": "store_heritage03", "created_at": _now(), "view_count": 0,
        },
        {
            "product_id": _pid(),
            "title": {"tr": "Rolex Daytona Paul Newman 6239", "en": "Rolex Daytona Paul Newman 6239", "it": "Rolex Daytona Paul Newman 6239"},
            "description": {
                "tr": "Orijinal Paul Newman kadranli Rolex Daytona 6239. Koleksiyoncularin en cok aranan modeli.",
                "en": "Rolex Daytona 6239 with original Paul Newman dial.",
                "it": "Rolex Daytona 6239 con quadrante Paul Newman originale.",
            },
            "category": "watches", "price": 350000.00, "currency": "USD",
            "images": ["https://images.pexels.com/photos/2113994/pexels-photo-2113994.jpeg?auto=compress&cs=tinysrgb&w=800"],
            "condition": "excellent",
            "provenance": {"tr": "Italyan ozel koleksiyondan", "en": "From Italian private collection", "it": "Da collezione privata italiana"},
            "is_auction": True,
            "auction_start": _now(), "auction_end": _future(4),
            "starting_bid": 280000.00, "reserve_price": 330000.00,
            "current_bid": 305000.00, "bid_count": 6, "min_increment": 5000.00,
            "status": "active", "approval_status": "approved", "featured": False,
            "store_id": "store_kronos01", "created_at": _now(), "view_count": 0,
        },
        {
            "product_id": _pid(),
            "title": {"tr": "Osmanli Donemi Altin Kupe Seti", "en": "Ottoman Era Gold Earring Set", "it": "Set di Orecchini in Oro dell'Era Ottomana"},
            "description": {
                "tr": "18. yuzyil Osmanli donemi altin kupe seti. Muze kalitesinde.",
                "en": "18th century Ottoman era gold earring set. Museum quality.",
                "it": "Set di orecchini in oro del XVIII secolo. Qualita museale.",
            },
            "category": "jewelry", "price": 75000.00, "currency": "USD",
            "images": ["https://images.pexels.com/photos/6044266/pexels-photo-6044266.jpeg?auto=compress&cs=tinysrgb&w=800"],
            "condition": "good",
            "provenance": {"tr": "Istanbul'daki ozel koleksiyondan", "en": "From private Istanbul collection", "it": "Da collezione privata di Istanbul"},
            "is_auction": False, "status": "active", "approval_status": "approved",
            "featured": False, "store_id": "store_galeri02", "created_at": _now(), "view_count": 0,
        },
    ]
    for p in products:
        await db.products.insert_one(p)
    logger.info("Seeded %d products", len(products))


async def _seed_articles(db) -> None:
    if await db.articles.count_documents({}) > 0:
        return
    articles = [
        {
            "article_id": "art_invest01",
            "title": {"tr": "Yatirim Olarak Koleksiyon Saatler: 2025 Rehberi", "en": "Collectible Watches as Investment: 2025 Guide", "it": "Orologi da Collezione come Investimento: Guida 2025"},
            "excerpt": {"tr": "Koleksiyon saatlerinin degerinin neden arttigi hakkinda kapsamli bir rehber.", "en": "A comprehensive guide on why collectible watches appreciate.", "it": "Una guida completa sul perche gli orologi si apprezzano."},
            "content": {"tr": "Koleksiyon saatleri, son on yilda en yuksek getiri saglayan varlik siniflarindan biri olmustur.", "en": "Collectible watches have been one of the highest-returning asset classes over the past decade.", "it": "Gli orologi da collezione sono stati una delle classi di attivi con il rendimento piu alto."},
            "category": "yatirim", "author": "Dr. Ahmet Yilmaz",
            "featured_image": "https://images.pexels.com/photos/2113994/pexels-photo-2113994.jpeg?auto=compress&cs=tinysrgb&w=800",
            "published": True, "slug": "yatirim-olarak-koleksiyon-saatler-2025", "created_at": _now(),
        },
        {
            "article_id": "art_ottoman02",
            "title": {"tr": "Osmanli Donemi Antikalarinin Yukselen Degeri", "en": "The Rising Value of Ottoman Period Antiques", "it": "Il Valore Crescente delle Antichita Ottomane"},
            "excerpt": {"tr": "Uluslararasi piyasalarda Osmanli donemi eserlerine olan talebin artisi.", "en": "The increasing demand for Ottoman period artifacts in international markets.", "it": "La crescente domanda di manufatti ottomani nei mercati internazionali."},
            "content": {"tr": "Osmanli Imparatorlugu'nun alti yuzyillik tarihinden kalan eserler, uluslararasi muzayede evlerinde giderek artan bir ilgiyle karsilanmaktadir.", "en": "Artifacts from the Ottoman Empire are meeting increasing interest at international auction houses.", "it": "I manufatti dell'Impero Ottomano stanno incontrando un crescente interesse."},
            "category": "kultur", "author": "Prof. Zeynep Kaya",
            "featured_image": "https://images.pexels.com/photos/20967/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=800",
            "published": True, "slug": "osmanli-donemi-antikalarinin-yukselen-degeri", "created_at": _past(3),
        },
        {
            "article_id": "art_contemp03",
            "title": {"tr": "Cagdas Sanat Piyasasi: 2025 Trendleri", "en": "Contemporary Art Market: 2025 Trends", "it": "Mercato dell'Arte Contemporanea: Tendenze 2025"},
            "excerpt": {"tr": "Dijital sanat, NFT sonrasi donem ve fiziksel eserlerin yeniden yukselisi.", "en": "Digital art, post-NFT era and the re-rise of physical works.", "it": "Arte digitale e la rinascita delle opere fisiche."},
            "content": {"tr": "2025 yili, cagdas sanat piyasasi icin onemli donusumlerin yasandigi bir donem olmaktadir.", "en": "2025 is a period of significant transformations for the contemporary art market.", "it": "Il 2025 e un periodo di significative trasformazioni."},
            "category": "sanat", "author": "Elif Demir",
            "featured_image": "https://images.pexels.com/photos/3004909/pexels-photo-3004909.jpeg?auto=compress&cs=tinysrgb&w=800",
            "published": True, "slug": "cagdas-sanat-piyasasi-2025-trendleri", "created_at": _past(7),
        },
        {
            "article_id": "art_coins04",
            "title": {"tr": "Nadir Sikkelerin Buyuleyici Tarihi", "en": "The Fascinating History of Rare Coins", "it": "L'Affascinante Storia delle Monete Rare"},
            "excerpt": {"tr": "Antik caglardan gunumuze, sikkelerin tarihi yolculugu.", "en": "The historical journey of coins from ancient times to today.", "it": "Il viaggio storico delle monete dall'antichita."},
            "content": {"tr": "Sikke koleksiyonculugu, insanlik tarihinin en eski hobilerinden biridir.", "en": "Coin collecting is one of the oldest hobbies in human history.", "it": "Il collezionismo di monete e uno degli hobby piu antichi."},
            "category": "koleksiyon", "author": "Mehmet Ozturk",
            "featured_image": "https://images.pexels.com/photos/30895543/pexels-photo-30895543.jpeg?auto=compress&cs=tinysrgb&w=800",
            "published": True, "slug": "nadir-sikkelerin-buyuleyici-tarihi", "created_at": _past(14),
        },
    ]
    for a in articles:
        await db.articles.insert_one(a)
    logger.info("Seeded %d articles", len(articles))


async def _seed_faq(db) -> None:
    if await db.faq.count_documents({}) > 0:
        return
    faq_items = [
        {"faq_id": "faq_01", "question": {"tr": "ANTICCA'da nasil alis yapabilirim?", "en": "How can I purchase on ANTICCA?", "it": "Come posso acquistare su ANTICCA?"}, "answer": {"tr": "Hesap olusturun, direkt satis urunlerini sepete ekleyin veya muzayedeye teklif verin.", "en": "Create an account, add direct products to cart or bid on auctions.", "it": "Crea un account, aggiungi prodotti al carrello o fai offerte."}, "category": "genel", "order": 1},
        {"faq_id": "faq_02", "question": {"tr": "Muzayede sistemi nasil calisiyor?", "en": "How does the auction system work?", "it": "Come funziona il sistema d'asta?"}, "answer": {"tr": "Muzayedeler belirlenmis sure boyunca aktif kalir. Anti-sniping ozelligi son dakika tekliflerinde sureyi uzatir.", "en": "Auctions remain active for a set period. Anti-sniping extends time for last-minute bids.", "it": "Le aste rimangono attive per un periodo prestabilito. L'anti-sniping estende il tempo."}, "category": "muzayede", "order": 2},
        {"faq_id": "faq_03", "question": {"tr": "Hangi odeme yontemlerini kabul ediyorsunuz?", "en": "What payment methods do you accept?", "it": "Quali metodi di pagamento accettate?"}, "answer": {"tr": "Stripe uluslararasi kart, banka havalesi.", "en": "Stripe international card, bank transfer.", "it": "Stripe carta internazionale, bonifico bancario."}, "category": "odeme", "order": 3},
        {"faq_id": "faq_04", "question": {"tr": "Komisyon orani nedir?", "en": "What is the commission rate?", "it": "Qual e la percentuale di commissione?"}, "answer": {"tr": "Alici komisyonu %5, satici komisyonu %8-15.", "en": "Buyer commission 5%, seller commission 8-15%.", "it": "Commissione acquirente 5%, venditore 8-15%."}, "category": "odeme", "order": 4},
        {"faq_id": "faq_05", "question": {"tr": "Urun iadesi mumkun mu?", "en": "Is product return possible?", "it": "E possibile il reso del prodotto?"}, "answer": {"tr": "Direkt satislarda 14 gun iade, muzayedelerde iade yoktur.", "en": "Direct sales: 14 days return. Auctions: non-returnable.", "it": "Vendite dirette: 14 giorni. Aste: non rimborsabile."}, "category": "iade", "order": 5},
        {"faq_id": "faq_06", "question": {"tr": "Urunlerin gercekligi nasil dogrulaniyor?", "en": "How is product authenticity verified?", "it": "Come viene verificata l'autenticita?"}, "answer": {"tr": "Tum urunler alan uzmanlarimiz tarafindan titizlikle incelenir.", "en": "All products are meticulously examined by our field experts.", "it": "Tutti i prodotti sono esaminati dai nostri esperti."}, "category": "guvenlik", "order": 6},
        {"faq_id": "faq_07", "question": {"tr": "Kargo ve sigorta nasil yapiliyor?", "en": "How is shipping and insurance handled?", "it": "Come vengono gestiti spedizione e assicurazione?"}, "answer": {"tr": "Tum urunler ozel ambalajlanarak sigortali ve takipli kargo ile gonderilir.", "en": "All products are specially packaged with insurance and tracking.", "it": "Tutti i prodotti sono imballati con assicurazione e tracciamento."}, "category": "kargo", "order": 7},
        {"faq_id": "faq_08", "question": {"tr": "Magaza olarak nasil basvurabilirim?", "en": "How can I apply as a store?", "it": "Come posso candidarmi come negozio?"}, "answer": {"tr": "basvuru@anticca.com adresine detayli bilgilerinizi gonderin.", "en": "Send your details to apply@anticca.com.", "it": "Inviate i vostri dati a apply@anticca.com."}, "category": "magaza", "order": 8},
    ]
    for f in faq_items:
        await db.faq.insert_one(f)
    logger.info("Seeded %d FAQ items", len(faq_items))


async def _seed_admin(db) -> None:
    admin_email = settings.ADMIN_EMAIL
    if await db.users.find_one({"email": admin_email}):
        return

    raw_pw = settings.ADMIN_PASSWORD
    if not raw_pw:
        import secrets
        raw_pw = secrets.token_urlsafe(20)
        logger.warning(
            "ADMIN_PASSWORD not set. Generated temporary password: %s — CHANGE THIS IMMEDIATELY.",
            raw_pw,
        )

    await db.users.insert_one({
        "user_id": generate_user_id(),
        "email": admin_email,
        "password": hash_password(raw_pw),
        "name": "ANTICCA Admin",
        "role": "admin",
        "created_at": _now(),
    })
    logger.info("Admin user created: %s", admin_email)
